'use strict';
// Tela principal do caixa / gerente.

const S = {
  usuario: null, view: 'inicio', cardapio: { categorias: [], produtos: [], adicionais: [] }, cfg: {},
  formas: [], bairros: [], motoboys: [], caixa: { aberto: false }, licenca: null,
  pedido: null, carrinho: [], voltar: 'mesas', catSel: null, busca: '', conectado: true,
  abaCaixa: 'caixa', abaCad: 'produtos', rel: { de: hojeISO(), ate: hojeISO() }, areaSel: '', pend: { chamadas: [], aprovacoes: [] },
  filtroPedidos: { de: hojeISO(), ate: hojeISO(), tipo: '', status: '', q: '' }, abaConfig: 'geral',
};
const raiz = $('#raiz');
const NIVEL = { garcom: 1, caixa: 2, gerente: 3 };
const pode = (perfil) => NIVEL[S.usuario?.perfil] >= NIVEL[perfil];
const estacaoImpressao = () => {
  try { const v = localStorage.getItem('mp_estacao'); return v == null ? ['localhost', '127.0.0.1'].includes(location.hostname) : v === '1'; }
  catch { return true; }
};
const nomesTipo = { mesa: 'Mesa', balcao: (window.PRODUTO?.termos?.balcao) || 'Balcão', delivery: 'Delivery', ...((window.PRODUTO?.termos?.tipos) || {}) };

window.aoDeslogar = () => { S.usuario = null; iniciar(); };
// 3.9.2: um e-mail = uma conta. Se o e-mail deste computador já é de outra conta, o gerente entra nela (os dados vêm de lá)
function avisoEmailEmUso(e, id) {
  if (!e || !e.email) return '';
  return html`<div class="card pad alerta-card" style="margin-bottom:14px;box-shadow:none" id="${id}"><div class="row wrap" style="gap:12px;align-items:center"><div style="flex:1;min-width:240px">
    <b>${e.conta_movida ? 'Sua conta foi aberta em outro computador' : 'Este e-mail já tem outra conta'}</b>
    <div class="small">${e.conta_movida ? `A conta ${e.email} agora está em outro computador. Para usar ela aqui de novo, entre com o e-mail e a senha: os dados vêm do outro computador.`
      : `O e-mail ${e.email} já é de uma conta criada antes (no site ou em outro computador). Entre nela para ficar com uma conta só. Atenção: os dados deste computador são trocados pelos dados dessa conta.`}</div></div>
    <button class="btn primary" data-entrar-conta="${e.email}">Entrar na minha conta</button></div></div>`;
}
document.addEventListener('click', (ev) => {
  const b = ev.target && ev.target.closest && ev.target.closest('[data-entrar-conta]'); if (!b) return;
  ev.preventDefault();
  telaRegistro(raiz, { licenca: S.licenca || {}, nome: (S.cfg && S.cfg.nome_estabelecimento) || '' }, () => location.reload(), 'entrar', b.dataset.entrarConta || '', { voltar: () => location.reload() });
});
window.aoBloquearLicenca = async () => {
  if (document.querySelector('.login')) return;
  const st = await GET('/api/licenca').catch(() => null);
  if (st && st.bloqueado) telaAtivacao(raiz, st, () => iniciar());
};

async function iniciar() {
  const info = await GET('/api/info').catch(() => null);
  if (info?.registro_pendente) return telaRegistro(raiz, info, () => iniciar());
  if (info?.licenca?.bloqueado) return telaAtivacao(raiz, info.licenca, () => iniciar());
  S.licenca = info?.licenca || null; S.nuvem = !!info?.nuvem;
  const s = Sessao.get();
  if (!s) return telaLogin(raiz, { dica: info?.pin_padrao ? '👋 <b>Primeiro acesso?</b> Digite o PIN do gerente: <b>1234</b>. Depois troque em Cadastros › Equipe.' : '', titulo: 'Caixa', subtitulo: info?.nome || 'Controle de mesas, balcão e delivery', aviso: textoTeste(info?.licenca), licenca: info?.licenca, suporte: info?.licenca?.vendedor_whatsapp || '', aoEntrar: () => iniciar() });
  try { S.usuario = await GET('/api/me'); } catch { return; }
  if (S.usuario.perfil === 'garcom' && R.garcom !== false && R.garcom) { location.href = '/garcom'; return; }
  if (S.usuario.perfil === 'entregador') { location.href = '/entregador'; return; }
  montarApp();
}

// ---------------- Estrutura ----------------
// ---- Produto desta compilação (injetado pelo servidor em window.PRODUTO) ----
const ARTE_HERO_PADRAO = '<svg viewBox="0 0 320 300" fill="none"><circle cx="190" cy="155" r="127" stroke="#adc2ea" opacity=".15"/><circle cx="190" cy="155" r="96" stroke="#adc2ea" opacity=".13"/><g transform="rotate(-24 190 155)"><rect x="111" y="70" width="145" height="170" rx="48" fill="#385581" stroke="#738db6"/><rect x="151" y="47" width="66" height="15" rx="7" fill="#b0c3ec"/><rect x="151" y="248" width="66" height="15" rx="7" fill="#b0c3ec"/><circle cx="184" cy="127" r="35" fill="#f1f4fc"/><circle cx="184" cy="127" r="26" stroke="#bbcbed"/><circle cx="184" cy="127" r="18" stroke="#bbcbed"/><path d="M136 104v44m-5-44v14q5 8 10 0v-14M231 105v43m-5-43q-7 23 5 22" stroke="#cfdbf2" stroke-width="2" stroke-linecap="round"/><circle cx="182" cy="194" r="18" stroke="#cfdbf2"/><circle cx="182" cy="194" r="11" stroke="#cfdbf2"/><path d="m205 174 10-12 10 12-10 12Z" fill="#ffab91"/><circle cx="144" cy="186" r="5" fill="#8ea6cf"/></g></svg>';
const PR = window.PRODUTO || { slug: 'restaurante', nome: 'MesaPronta', recursos: {}, termos: {}, textos: {}, menu: [], atalhos_inicio: [] };
const R = PR.recursos || {}, T = PR.termos || {}, TX = PR.textos || {};
const MENU_BASE = [
  { id: 'inicio', nome: 'Início', ic: '◉', perfil: 'caixa', tecla: 'F1' },
  { id: 'mesas', nome: 'Mesas', ic: '▦', perfil: 'caixa', tecla: 'F2', flag: 'mesas' },
  { id: 'balcao', nome: T.balcao || 'Balcão', ic: '⌂', perfil: 'caixa', tecla: 'F3', flag: 'balcao' },
  { id: 'delivery', nome: 'Delivery', ic: '➜', perfil: 'caixa', tecla: 'F4', flag: 'delivery' },
  { id: 'pdv', nome: T.pdv || 'Fechar contas', ic: '⚡', perfil: 'caixa', tecla: 'F5', flag: 'pdv' },
  { id: 'cozinha', nome: 'Cozinha', ic: '♨', perfil: 'caixa', link: '/cozinha', flag: 'cozinha' },
  { id: 'pedidos', nome: T.menu_pedidos || T.pedidos || 'Pedidos', ic: '≣', perfil: 'caixa', tecla: 'F6' },
  { id: 'caixa', nome: 'Caixa', ic: '$', perfil: 'caixa', tecla: 'F7' },
  { id: 'estoque', nome: 'Estoque', ic: '▣', perfil: 'caixa', flag: 'estoque' },
  { id: 'relatorios', nome: 'Relatórios', ic: '▤', perfil: 'gerente', tecla: 'F9' },
  { id: 'financeiro', nome: 'Financeiro', ic: '$', perfil: 'gerente' },
  { id: 'fiscal', nome: 'Notas fiscais', ic: '🧾', perfil: 'gerente', flag: 'nota_fiscal', icone: 'ticket' },
  { id: 'cadastros', nome: 'Cadastros', ic: '☰', perfil: 'gerente' },
  { id: 'config', nome: 'Configurações', ic: '⚙', perfil: 'gerente' },
  { id: 'cardapio-online', nome: 'Cardápio online', ic: '🌐', perfil: 'gerente', flag: 'delivery', icone: 'online' },
  { id: 'qrcodes', nome: 'QR Codes', ic: '▩', perfil: 'caixa', link: '/qrcodes', flag: 'qrcodes' },
  { id: 'aulas', nome: 'Aulas em vídeo', ic: '▶', perfil: 'caixa', flag: 'aulas' },
  { id: 'ajuda', nome: 'Ajuda', ic: '?', perfil: 'caixa' },
];
if (R.nota_fiscal == null) R.nota_fiscal = PR.slug === 'restaurante';   // NFC-e: módulo pago, só no MesaPronta por enquanto
if (R.qrcodes == null) R.qrcodes = !!(R.garcom || R.cozinha || R.cardapio_qr || R.visor || R.quadro || R.agenda);
R.aulas = !!(PR.aulas && PR.aulas.lista && PR.aulas.lista.length);   // aulas em vídeo (YouTube): só no produto que tem
const MENU = [];
// itens do produto podem se ancorar em itens da base OU em outros itens do produto (ex.: agenda depois de veiculos)
const empilhar = (ancora, chave) => { for (const pm of (PR.menu || []).filter(x => x[chave] === ancora.id && !MENU.includes(x))) { if (chave === 'antes') { empilhar(pm, 'antes'); MENU.push(pm); empilhar(pm, 'depois'); } else { empilhar(pm, 'antes'); MENU.push(pm); empilhar(pm, 'depois'); } } };
for (const m of MENU_BASE) {
  empilhar(m, 'antes');
  if (!m.flag || R[m.flag] !== false) MENU.push(m);
  empilhar(m, 'depois');
}
for (const pm of (PR.menu || []).filter(x => !MENU.includes(x))) MENU.push(pm);
const ATALHOS = (PR.atalhos_inicio && PR.atalhos_inicio.length) ? PR.atalhos_inicio : [['balcao', 'Nova venda', 'Agilidade no atendimento'], ['pdv', 'Fechar contas', 'Tudo certo para receber'], ['estoque', 'Estoque', 'O que falta'], ['relatorios', 'Relatórios', 'Como foi o dia']];
const AT1 = ATALHOS[0];


// Ícones vetoriais próprios, disponíveis mesmo sem internet.
const MP_PATHS = { suporte:'M4 11a8 8 0 0 1 16 0v5a2 2 0 0 1-2 2h-2v-6h4M4 11h4v6H6a2 2 0 0 1-2-2v-4m8 10a3 3 0 0 0 3-3',
 inicio:'M3 10 12 3l9 7v10H3Z M9 20v-7h6v7', mesas:'M4 7h16v10H4Z M7 3v4m10-4v4M7 17v4m10-4v4',
 balcao:'M3 10h18M5 10v10h14V10M4 4h16l1 6H3Z M9 14h6', delivery:'M3 6h11v12H3Z M14 10h4l3 4v4h-7 M7 21a2 2 0 1 0 0-4 2 2 0 0 0 0 4m11 0a2 2 0 1 0 0-4 2 2 0 0 0 0 4',
 pdv:'M3 5h18v14H3Z M3 10h18M7 15h4', aulas:'M3 5h18v14H3Z M10 9l5 3-5 3Z', cozinha:'M5 14h14M3 18h18M6 14a6 6 0 0 1 12 0M12 5V3',
 pedidos:'M6 3h12v18l-3-2-3 2-3-2-3 2Z M9 8h6m-6 4h6', caixa:'M4 7h16v13H4Z M6 7V3h12v4M8 12h8m-8 4h3',
 estoque:'m3 7 9-4 9 4v11l-9 4-9-4Z M3 7l9 5 9-5M12 12v10M7 5l10 5', relatorios:'M4 20h17M7 16V9m6 7V4m6 12v-5',
 cadastros:'M4 4h6v6H4Z M14 4h6v6h-6Z M4 14h6v6H4Z M17 14v6m-3-3h6', config:'M4 7h16M4 17h16M8 4v6m8 4v6',
 qrcodes:'M3 3h6v6H3Z M15 3h6v6h-6Z M3 15h6v6H3Z M15 15h3v3h3v3h-6Z', ajuda:'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20M9 8a3 3 0 1 1 5 2c-2 1-2 2-2 3M12 17h.01',
 agenda:'M4 5h16v16H4Z M4 10h16M8 3v4m8-4v4M8 14h3v3H8Z', fila:'M4 6h16M4 12h10M4 18h7M18 15l3 3-3 3', quadro:'M3 4h18v12H3Z M8 21h8M12 16v5', comissoes:'M19 5 5 19M7 9a2 2 0 1 0 0-4 2 2 0 0 0 0 4m10 10a2 2 0 1 0 0-4 2 2 0 0 0 0 4', veiculos:'M3 13l2-5h14l2 5v6H3Z M6 19v2m12-2v2M7 15h.01M17 15h.01', os:'M14 3 21 10 10 21 3 14ZM14 7l3 3', pets:'M12 21c-4 0-6-2-6-5 0-2 2-4 6-4s6 2 6 4c0 3-2 5-6 5M7 9a2 2 0 1 0 0-4 2 2 0 0 0 0 4m10 0a2 2 0 1 0 0-4 2 2 0 0 0 0 4M4 13a2 2 0 1 0 0-4 2 2 0 0 0 0 4m16 0a2 2 0 1 0 0-4 2 2 0 0 0 0 4', hotel:'M3 21V8l9-5 9 5v13M9 21v-6h6v6M12 11h.01', taxi:'M5 17h14M6 17l1-5h10l1 5M8 12l1-4h6l1 4M7 20a1 1 0 1 0 0-2 1 1 0 0 0 0 2m10 0a1 1 0 1 0 0-2 1 1 0 0 0 0 2', lembretes:'M12 8v4l3 3M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0',
 online:'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18', financeiro:'M3 6h18v12H3Z M3 10h18M7 15h3m5 0h2', busca:'M10 17a7 7 0 1 0 0-14 7 7 0 0 0 0 14m5-2 6 6', seta:'M5 12h14m-6-6 6 6-6 6', sino:'M5 17h14l-2-4V9a5 5 0 0 0-10 0v4ZM10 21h4', sol:'M12 16a4 4 0 1 0 0-8 4 4 0 0 0 0 8M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1 1m12 12 1 1M5 19l1-1M18 6l1-1', calendario:'M4 5h16v16H4Z M4 10h16M8 3v4m8-4v4', ticket:'M4 5h16v5a2 2 0 0 0 0 4v5H4v-5a2 2 0 0 0 0-4Z M13 8v8'
};
function mpIcon(id) { return `<svg class="mp-icon" aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round"><path d="${MP_PATHS[id] || MP_PATHS.inicio}"/></svg>`; }
function mpBusca() {
 let focoAnterior=document.activeElement;
 modal({titulo:'Para onde vamos?',corpo:'<label class="campo">Buscar uma tela<input id="mp-cmd" type="text" placeholder="Mesas, delivery, estoque…" autocomplete="off"></label><div class="mp-command-list" id="mp-results"></div>',aoAbrir:(f,fechar)=>{
  const input=$('#mp-cmd',f), results=$('#mp-results',f);
  const draw=()=>{const q=input.value.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();const itens=MENU.filter(m=>pode(m.perfil)&&m.nome.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().includes(q));results.innerHTML=itens.map(m=>`<button data-go="${m.id}">${mpIcon(m.icone || m.id)}<span>${esc(m.nome)}</span><span class="nav-key">${m.tecla||'↗'}</span></button>`).join('')||'<div class="vazio">Nenhuma tela encontrada. Tente outro nome.</div>';};
  draw();input.addEventListener('input',draw);input.addEventListener('keydown',e=>{if(e.key==='ArrowDown'){e.preventDefault();results.querySelector('button')?.focus();}if(e.key==='Enter'){e.preventDefault();e.stopPropagation();results.querySelector('button')?.click();}});
  results.addEventListener('keydown',e=>{const bs=[...results.querySelectorAll('button')];const i=bs.indexOf(document.activeElement);if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();bs[(i+(e.key==='ArrowDown'?1:bs.length-1))%bs.length]?.focus();}});
  results.onclick=e=>{const b=e.target.closest('[data-go]');if(!b)return;const m=MENU.find(x=>x.id===b.dataset.go);fechar();if(m.link)window.open(m.link,'_blank');else ir(m.id);};setTimeout(()=>input.focus(),30);
 }}).then(()=>{if(focoAnterior?.isConnected)focoAnterior.focus();});
}

async function montarApp() {
  raiz.innerHTML = `<div class="app">
    <aside class="lateral">
      <div class="logo">Mesa<span>Pronta</span></div>
      <div class="topo-acoes">
        <button class="btn" id="btn-notif" title="Notificações" aria-label="Notificações">${mpIcon('sino')}<span class="bolinha hidden" id="notif-n"></span></button>
        <button class="btn" id="btn-tema" title="Tema claro/escuro" aria-label="Alternar tema">${mpIcon('sol')}</button>
        <button class="btn" id="btn-atalhos" title="Atalhos de teclado (?)" aria-label="Atalhos de teclado">${mpIcon('ajuda')}</button>
      </div>
      <div id="lic-aviso"></div>
      <div id="menu"></div>
      <div class="rodape">
        <div id="status-cx" class="status-cx"></div>
        <div id="conexao" class="conexao"></div>
        <div><b>${esc(S.usuario.nome)}</b> <span class="muted small">(${esc(S.usuario.perfil)})</span></div>
        <button class="btn sm" id="sair">Sair</button>
      </div>
    </aside>
    <div class="workspace"><header class="mp-topbar"><div class="mp-place">${mpIcon('balcao')}<div><span id="mp-estabelecimento">MesaPronta</span><small>${TX.topo_sub || 'Seu negócio, em sintonia'}</small></div></div><button class="mp-search" id="mp-search" aria-label="Buscar telas">${mpIcon('busca')} Buscar no MesaPronta <kbd>Ctrl K</kbd></button><a class="btn ok sm mp-suporte" id="mp-suporte" href="#" target="_blank" rel="noopener" title="Falar com o suporte pelo WhatsApp" hidden>💬 Suporte</a><button class="btn ghost sm mp-focus" id="mp-focus" title="Reduzir os elementos de apresentação do início" aria-pressed="false">Modo foco</button><button class="btn ghost sm mp-notif-cel" id="mp-notif-cel" aria-label="Avisos">${mpIcon('sino')}<span class="bolinha hidden" id="notif-n2"></span></button><span class="mp-avatar clicavel" title="${esc(S.usuario.nome)}">${esc(S.usuario.nome.slice(0,2).toUpperCase())}</span></header><main class="principal" id="conteudo"></main></div><button class="mp-aula-fab" id="mp-aula" hidden title="Assistir a aula em vídeo desta tela"><span class="fab-ic">▶</span><span class="fab-txt">Aula desta tela</span></button>
  </div><nav class="mob-nav" id="mob-nav" aria-label="Navegação"></nav>`;
  if (!MP_PATHS.menu) MP_PATHS.menu = 'M4 7h16M4 12h16M4 17h16';
  $('#mp-notif-cel').onclick = abrirNotificacoes;
  $('#mp-search').onclick = mpBusca;
  const foco=()=>{let ativo=false;try{ativo=localStorage.getItem('mp_foco')==='1';}catch{}document.body.classList.toggle('mp-focus-mode',ativo);$('#mp-focus').setAttribute('aria-pressed',String(ativo));$('#mp-focus').textContent=ativo?'Sair do foco':'Modo foco';};foco();
  $('#mp-focus').onclick=()=>{try{localStorage.setItem('mp_foco',document.body.classList.contains('mp-focus-mode')?'0':'1');}catch{}foco();};
  $('#sair').onclick = async () => { try { await POST('/api/logout'); } catch {} Sessao.limpar(); location.reload(); };
  $('#btn-tema').onclick = () => Tema.alternar();
  $('#btn-notif').onclick = abrirNotificacoes;
  $('#btn-atalhos').onclick = mostrarAtalhos;
  $('#menu').addEventListener('click', (e) => {
    const b = e.target.closest('[data-v]'); if (!b) return;
    const m = MENU.find(x => x.id === b.dataset.v);
    if (m.link) return window.open(m.link, '_blank');
    ir(m.id);
  });
  document.addEventListener('keydown', atalhoTeclado);
  await carregarBase();
  $('#mp-estabelecimento').textContent = S.cfg.nome_estabelecimento || 'MesaPronta';
  conectarEventos({
    conectado: () => { S.conectado = true; const el = $('#conexao'); if (el) el.textContent = ''; },
    desconectado: () => { S.conectado = false; const el = $('#conexao'); if (el) el.textContent = '● Reconectando...'; },
    pedidos: adiar(() => { atualizarAoVivo(); carregarPendencias(); }),
    cozinha: () => { if (S.view === 'inicio') render(); },
    caixa: adiar(async () => { await carregarCaixa(); if (['caixa', 'inicio'].includes(S.view)) render(); }),
    espera: adiar(() => { if (['mesas', 'inicio'].includes(S.view)) render(); }),
    agenda: adiar(() => { if (['agenda', 'inicio', 'quadro'].includes(S.view) && !document.querySelector('.modal')) render(); }),
    quadro: adiar(() => { if (['quadro', 'inicio'].includes(S.view) && !document.querySelector('.modal')) render(); }),
    painel: () => {},
    cadastros: adiar(async (d) => { S.cardapio = await GET('/api/cardapio'); if (S.view === 'editor') desenharProdutos(); else if (!d.silencioso && ['cadastros', 'estoque'].includes(S.view)) render(); }),
    config: adiar(async () => { S.cfg = await GET('/api/config'); S.licenca = (await GET('/api/licenca').catch(() => null)); avisoLicenca(); observarLicenca(); }),
    aviso: (d) => { toast(d.mensagem, 'alerta'); if (d.som) bip(2); },
    pronto: (d) => { toast(d.mensagem, 'ok'); },
    notificacao: (d) => {
      bip(d.tipo === 'online' ? 4 : 3, d.tipo === 'aprovacao' ? 660 : d.tipo === 'online' ? 990 : 880); if (d.tipo === 'online' && S.view === 'delivery') render();
      toast(d.mensagem, 'alerta', { tempo: 12000, acao: { texto: 'Ver', fn: abrirNotificacoes } });
      carregarPendencias();
    },
    imprimir: (d) => { if (estacaoImpressao()) imprimirTexto(d.texto); },
  });
  avisoLicenca(); observarLicenca(); limparTourAntigo();
  ir(pode('caixa') ? 'inicio' : (MENU.find(m => pode(m.perfil) && !m.link)?.id || 'ajuda'));
}

async function carregarBase() {
  const [card, cfg, formas, bairros, motoboys] = await Promise.all([
    GET('/api/cardapio'), GET('/api/config'), GET('/api/cad/formas_pagamento'), GET('/api/cad/bairros'), GET('/api/cad/motoboys')]);
  Object.assign(S, { cardapio: card, cfg, formas, bairros, motoboys });
  if (!S.catSel && card.categorias[0]) S.catSel = card.categorias[0].id;
  await carregarCaixa();
  await carregarPendencias();
}
async function carregarCaixa() {
  S.caixa = await GET('/api/caixa/atual');
  const el = $('#status-cx');
  if (el) { el.className = 'status-cx ' + (S.caixa.aberto ? 'aberto' : ''); el.innerHTML = `<i></i> Caixa ${S.caixa.aberto ? 'aberto' : 'fechado'}`; }
}
async function carregarPendencias() {
  try { S.pend = await GET('/api/pendencias'); } catch { return; }
  const n = nPend();
  const b = $('#notif-n');
  if (b) { b.textContent = n; b.classList.toggle('hidden', !n); }
  const b2 = $('#notif-n2'); if (b2) { b2.textContent = n; b2.classList.toggle('hidden', !n); }
  desenharNavMobile();
  if ($('.notif-painel')) desenharNotificacoes();
}
function nPend() { return S.pend ? S.pend.chamadas.length + S.pend.aprovacoes.length + (S.pend.online?.length || 0) + (window.SALAO ? SALAO.nPend() : 0) : 0; }
// pedido online esperando: lembra com som a cada 30 s até alguém aceitar
setInterval(() => { if (S.usuario && S.pend?.online?.length && pode('caixa')) { bip(2, 990); } }, 30000);
async function aceitarOnline(id) { await tentar(() => POST(`/api/online/${id}/aceitar`), 'Pedido aceito e enviado à cozinha ✓'); carregarPendencias(); if (['delivery', 'inicio'].includes(S.view)) render(); }
async function recusarOnline(id) {
  const m = await modal({ titulo: 'Recusar pedido online', corpo: '<div class="stack"><p class="muted" style="margin:0">O cliente vê o motivo na tela de acompanhamento.</p><div class="chips" id="rc-m">' + ['Fechado agora', 'Não entregamos nesse endereço', 'Produto em falta', 'Muito movimento'].map(t => `<button class="chip" data-m="${esc(t)}">${esc(t)}</button>`).join('') + '</div><label class="campo">Motivo<input id="rc-t" placeholder="Escreva o motivo"></label></div>',
    aoAbrir: (f) => $('#rc-m', f).onclick = (e) => { const b = e.target.closest('[data-m]'); if (b) $('#rc-t', f).value = b.dataset.m; },
    botoes: [{ texto: 'Voltar' }, { texto: 'Recusar pedido', classe: 'danger', acao: (f) => $('#rc-t', f).value.trim() || 'Recusado pelo restaurante' }] });
  if (!m) return;
  await tentar(() => POST(`/api/online/${id}/recusar`, { motivo: m }), 'Pedido recusado'); carregarPendencias(); if (['delivery', 'inicio'].includes(S.view)) render();
}
function cartaoOnline(o) { return html`<div class="notif online"><div class="t">🌐 Pedido online #${o.numero} — ${o.cliente_nome}</div>
  <div class="small muted">${o.retirada ? '🏃 Retirada' : '🛵 ' + (o.bairro || 'Entrega')} · ${brl(o.subtotal + o.taxa_entrega - (o.desconto || 0))} · há ${minutosDesde(o.desde)} min</div>
  <div class="acoes"><button class="btn sm ok" data-on-aceitar="${o.pedido_id}">✓ Aceitar</button><button class="btn sm" data-on-ver="${o.pedido_id}">Ver pedido</button><button class="btn sm danger" data-on-recusar="${o.pedido_id}">Recusar</button></div></div>`; }
async function cliqueOnline(e) {
  const a = e.target.closest('[data-on-aceitar]'); if (a) { e.stopPropagation(); await aceitarOnline(a.dataset.onAceitar); return true; }
  const r = e.target.closest('[data-on-recusar]'); if (r) { e.stopPropagation(); await recusarOnline(r.dataset.onRecusar); return true; }
  const v = e.target.closest('[data-on-ver]'); if (v) { e.stopPropagation(); $('.notif-painel')?.remove(); abrirEditor(await GET('/api/pedidos/' + v.dataset.onVer), 'delivery'); return true; }
  return false;
}
// WhatsApp do suporte (vem do vendedor embutido; o campo antigo "suporte_whatsapp" das configurações ainda vale como sobrescrita)
function linkSuporte(assunto) {
  const lic = S.licenca || {}; const zap = S.cfg.suporte_whatsapp || lic.vendedor_whatsapp;
  return zap ? linkWhatsApp(zap, assunto || `Olá! Preciso de ajuda com o MesaPronta (${S.cfg.nome_estabelecimento || ''}, código ${lic.codigo_maquina || ''}).`) : '';
}
function telefoneSuporte() { const z = S.cfg.suporte_whatsapp || (S.licenca || {}).vendedor_whatsapp || ''; const d = z.replace(/\D/g, ''); return d.length >= 12 ? `(${d.slice(2, 4)}) ${d.slice(4, d.length - 4)}-${d.slice(-4)}` : z; }
// O produto pode imprimir o pedido de outro jeito (ex.: OS em folha A4). Devolve true se cuidou da impressão.
// todos os botões de imprimir do caixa: mesma impressora; "pelo navegador" (ou nenhuma configurada) abre a janela de impressão aqui
const imprimirTextos = (r) => { if (r && r.textos && r.textos.length) imprimirTexto(r.textos.join('\n\n\n')); return r; };
const imprimirAqui = (url, corpo) => POST(url, { ...(corpo || {}), aqui: true }).then(imprimirTextos);
function imprimirPedido(p, tipo) {
  if (window.PRODUTO_IMPRIMIR && window.PRODUTO_IMPRIMIR(p, tipo)) return Promise.resolve(true);
  return tentar(() => imprimirAqui(`/api/pedidos/${p.id}/imprimir`, { tipo }), tipo === 'cupom' ? 'Enviado para impressão' : 'Conferência enviada para impressão');
}
function avisoLicenca() {
  const el = $('#lic-aviso'); if (!el || !S.licenca) return;
  const l = S.licenca, up = l.atualizacao;
  let h = '';
  if (l.estado === 'teste') {
    const n = Number(l.dias_restantes);
    h += `<div class="lic-aviso ${n <= 2 ? 'bloq' : ''}" data-ir-lic><b>${n <= 0 ? 'Teste termina HOJE' : n === 1 ? 'Teste termina amanhã' : `Teste: ${n} dias restantes`}</b><br>${n <= 2 ? 'Peça sua chave de ativação' : 'Clique para ativar'}</div>`;
    if (linkCompra(l)) h += `<a class="lic-comprar" href="${esc(linkCompra(l))}" target="_blank" rel="noopener" data-comprar>🛒 Comprar agora</a>`;
  } else if (l.estado === 'ativada' && l.dias_para_expirar != null && l.dias_para_expirar <= 15) {
    h += `<div class="lic-aviso ${l.dias_para_expirar <= 3 ? 'bloq' : ''}" data-ir-lic><b>Licença vence ${l.dias_para_expirar <= 0 ? 'hoje' : 'em ' + l.dias_para_expirar + ' dia(s)'}</b><br>Renove com ${esc(l.vendedor_nome || 'o vendedor')}</div>`;
  } else if (l.estado !== 'ativada') h += `<div class="lic-aviso bloq" data-ir-lic>Sistema bloqueado — clique para ativar</div>`;
  if (up?.disponivel) h += `<div class="lic-aviso upd ${up.importante ? 'bloq' : ''}" data-ir-lic>⬆ <b>Nova versão ${esc(up.versao)}</b><br>Clique para baixar</div>`;
  el.innerHTML = h;
  el.querySelectorAll('[data-ir-lic]').forEach(x => x.onclick = () => { S.abaConfig = 'licenca'; ir('config'); });
  avisarAtualizacao(up);
}
// Mostra uma vez por versão nova o aviso "tem atualização"
function avisarAtualizacao(up) {
  if (up?.automatica) return;   // MesaPronta no computador: atualiza sozinho
  if (!up?.disponivel || document.querySelector('.modal-fundo')) return;
  let visto = ''; try { visto = localStorage.getItem('mp_upd_visto') || ''; } catch {}
  if (visto === up.versao) return;
  try { localStorage.setItem('mp_upd_visto', up.versao); } catch {}
  modal({ titulo: `Nova versão ${up.versao} disponível`, corpo: `<div class="stack"><p>Você está usando a versão <b>${esc(S.licenca?.versao_instalada || '')}</b>.${up.importante ? ' <b>Esta atualização é importante.</b>' : ''}</p>${up.mensagem ? `<div class="card pad" style="background:var(--surface-2);box-shadow:none;white-space:pre-wrap">${esc(up.mensagem)}</div>` : ''}<p class="muted small">Como atualizar: baixe o novo MesaPronta.exe e abra. Ele atualiza sozinho e mantém suas vendas, cadastros e configurações.</p></div>`,
    botoes: [{ texto: 'Depois' }, ...(up.download ? [{ texto: '⬇ Baixar agora', classe: 'primary', padrao: true, acao: () => { window.open(up.download, '_blank'); return true; } }] : [])] });
}

function desenharMenu() {
  $('#menu').innerHTML = MENU.filter(m => pode(m.perfil)).map(m =>
    `${m.id==='inicio'?'<div class="nav-group">OPERAÇÃO</div>':m.id==='pedidos'?'<div class="nav-group">GESTÃO</div>':m.id===(MENU.find(x=>x.id==='cardapio-online'&&pode(x.perfil))?'cardapio-online':'qrcodes')?'<div class="nav-group">CONEXÕES</div>':''}<button class="nav ${S.view === m.id || (S.view === 'editor' && S.voltar === m.id) ? 'on' : ''}" data-v="${m.id}" ${S.view===m.id?'aria-current="page"':''}><span class="ic">${mpIcon(m.icone || m.id)}</span>${m.nome}<span class="nav-key">${m.tecla || (m.link?'↗':'')}</span></button>`).join('')
    + (linkSuporte() ? `<a class="nav nav-suporte" href="${esc(linkSuporte())}" target="_blank" rel="noopener"><span class="ic">${mpIcon('suporte')}</span>Falar com o suporte<span class="nav-key">↗</span></a>` : '');
  const sup = $('#mp-suporte'); if (sup) { if (linkSuporte()) { sup.href = linkSuporte(); sup.hidden = false; } else sup.hidden = true; }
  desenharNavMobile();
}
async function ir(view) {
  if ($('#conteudo')) $('#conteudo').dataset.view = view;
  document.documentElement.classList.remove('ver-pedido');
  document.documentElement.dataset.view = view;
  if (view === 'assistente' && !pode('gerente')) return;
  if (!pode((MENU.find(m => m.id === view) || { perfil: 'caixa' }).perfil)) return;
  S.view = view;
  desenharMenu();
  botaoAulaDaTela();
  await render();
  dicaPrimeiraVez();
}
async function render() {
  const c = $('#conteudo');
  if (!c) return;
  c.onclick = null;
  try {
    const v = { inicio: vInicio, mesas: vMesas, balcao: vBalcao, delivery: vDelivery, pdv: vPDV, editor: vEditor, pedidos: vPedidos, caixa: vCaixa, estoque: vEstoque, relatorios: vRelatorios, cadastros: vCadastros, config: vConfig, ajuda: vAjuda, aulas: vAulas, assistente: vAssistente, ...(window.PRODUTO_VIEWS || {}) }[S.view];
    if (v) await v(c);
    inserirAvisoCardapio(c);
    inserirAvisoLocalizacao(c);
    inserirDicaAula(c);
  } catch (e) { if (!e.silencioso) toast(e.message, 'erro'); }
}
window.addEventListener('unhandledrejection', (ev) => { if (ev.reason && ev.reason.silencioso) ev.preventDefault(); });
async function atualizarAoVivo() {
  if (S.view === 'editor' && S.pedido) {
    try { S.pedido = await GET('/api/pedidos/' + S.pedido.id); } catch { return; }
    if (['fechado', 'cancelado'].includes(S.pedido.status) && S.pedido.tipo === 'mesa') { ir(S.voltar); return; }
    desenharPedido();
  } else if ((['mesas', 'balcao', 'delivery', 'inicio', 'pedidos', 'pdv'].includes(S.view) || (S.view === 'caixa' && S.abaCaixa !== 'fiado')) && !document.querySelector('.modal')) render();
}

// ---------------- Atalhos ----------------
function atalhoTeclado(e) {
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); if (!$('.modal-fundo')) mpBusca(); return; }
  const m = MENU.find(x => x.tecla === e.key);
  if (m && pode(m.perfil)) { e.preventDefault(); ir(m.id); return; }
  if (document.querySelector('.modal-fundo')) return;
  const digitando = ['INPUT', 'TEXTAREA', 'SELECT'].includes(e.target.tagName);
  if (e.key === 'F8' && S.view === 'editor') { e.preventDefault(); $('#receber')?.click(); }
  if (e.key === 'F10' && S.view === 'editor') { e.preventDefault(); $('#enviar')?.click(); }
  if (e.key === 'Escape' && S.view === 'editor' && !digitando) sairDoEditor();
  if (e.key === '?' && !digitando) mostrarAtalhos();
  if (e.key === 'n' && !digitando && S.view === 'balcao') $('#nova')?.click();
  if (e.key === 'n' && !digitando && S.view === 'delivery') $('#novo')?.click();
  if (e.key === 'n' && !digitando && (window.PRODUTO_TECLA_N || {})[S.view]) $((window.PRODUTO_TECLA_N || {})[S.view])?.click();
  if (e.key === '/' && !digitando && S.view === 'editor') { e.preventDefault(); $('#busca')?.focus(); }
}
function mostrarAtalhos() {
  const l = [...MENU.filter(m => m.tecla && pode(m.perfil)).map(m => [m.tecla, m.nome]), ['N', window.PRODUTO_TECLA_N_TEXTO || (R.delivery ? 'Nova venda / novo delivery' : (T.novo_pedido || 'Nova venda'))],
    ['/', `Buscar ${(T.produto || 'produto').toLowerCase()}`], ['Enter', 'Adiciona o 1º item da busca (Shift+Enter: sem perguntar)'], ['F10', R.cozinha ? 'Enviar para a cozinha' : (T.enviar || 'Lançar')], ['F8', 'Receber pagamento'], ['Esc', 'Voltar / fechar'], ['?', 'Esta ajuda']];
  modal({ titulo: 'Atalhos de teclado', corpo: `<div class="atalhos-lista">${l.map(([k, t]) => `<kbd>${k}</kbd><span>${esc(t)}</span>`).join('')}</div>`, botoes: [{ texto: 'Fechar', classe: 'primary', padrao: true }] });
}

// ---------------- Notificações ----------------
function abrirNotificacoes() {
  if ($('.notif-painel')) { $('.notif-painel').remove(); return; }
  const p = document.createElement('div');
  p.className = 'notif-painel';
  p.innerHTML = `<div class="cab"><h2>Notificações</h2><span class="spacer"></span><button class="btn ghost sm" id="notif-fechar">✕</button></div><div class="corpo" id="notif-corpo"></div>`;
  document.body.appendChild(p);
  $('#notif-fechar').onclick = () => p.remove();
  desenharNotificacoes();
  carregarPendencias();
}
function desenharNotificacoes() {
  const c = $('#notif-corpo'); if (!c) return;
  const { chamadas, aprovacoes } = S.pend, online = S.pend.online || [], extra = window.SALAO ? SALAO.notifs() : '';
  if (!chamadas.length && !aprovacoes.length && !online.length && !extra.trim()) { c.innerHTML = '<div class="vazio">Nenhuma pendência 👌</div>'; return; }
  c.innerHTML = html`${raw(extra)}${online.map(cartaoOnline)}${aprovacoes.map(a => html`<div class="notif aprovacao"><div class="t">Mesa ${a.mesa_nome} pediu pelo celular</div>
      <div class="small muted">${a.itens} item(ns) · ${brl(a.total)} · há ${minutosDesde(a.desde)} min</div>
      <div class="acoes"><button class="btn sm primary" data-ap="${a.pedido_id}">Ver e aprovar</button></div></div>`)}
    ${chamadas.map(ch => html`<div class="notif ${ch.tipo}"><div class="t">${ch.tipo === 'conta' ? '💳 Mesa ' + ch.mesa_nome + ' pediu a conta' : '🙋 Mesa ' + ch.mesa_nome + ' chama o garçom'}</div>
      <div class="small muted">há ${minutosDesde(ch.criado_em)} min${ch.texto ? ' · ' + ch.texto : ''}</div>
      <div class="acoes"><button class="btn sm ok" data-at="${ch.id}">Atendido</button><button class="btn sm" data-mesa-ir="${ch.mesa_id}">Abrir mesa</button></div></div>`)}`.s;
  c.onclick = async (e) => {
    if (await cliqueOnline(e)) return;
    const at = e.target.closest('[data-at]');
    if (at) { await tentar(() => POST(`/api/chamadas/${at.dataset.at}/atender`)); carregarPendencias(); }
    const ap = e.target.closest('[data-ap]');
    if (ap) { $('.notif-painel')?.remove(); abrirEditor(await GET('/api/pedidos/' + ap.dataset.ap), 'mesas'); }
    const mi = e.target.closest('[data-mesa-ir]');
    if (mi) { $('.notif-painel')?.remove(); const m = (await GET('/api/mesas')).find(x => x.id === Number(mi.dataset.mesaIr)); if (m?.pedido) abrirEditor(await GET('/api/pedidos/' + m.pedido.id), 'mesas'); else { toast(`A mesa ${m?.nome || ''} ainda não tem comanda — abra pelo mapa`, 'info'); ir('mesas'); } }
  };
}

// ---------------- Início ----------------
async function vInicio(c) {
  const PI = window.PRODUTO_INICIO || {};
  const [d, dp] = await Promise.all([GET('/api/inicio'), PI.dados ? PI.dados() : Promise.resolve(null)]);
  const ticket = d.vendas.n ? Math.round(d.vendas.t / d.vendas.n) : 0;
  const delta = (atual, ant) => ant ? html`<div class="delta ${atual >= ant ? 'up' : 'down'}">${atual >= ant ? '▲' : '▼'} ${Math.abs(Math.round((atual - ant) / ant * 100))}% vs ${ant === d.ontem ? 'ontem' : 'semana passada'}</div>` : '';
  const horas = Array.from({ length: 24 }, (_, h) => d.porHora.find(x => Number(x.hora) === h)?.total || 0);
  const hIni = Math.max(0, Math.min(8, horas.findIndex(v => v > 0) < 0 ? 8 : horas.findIndex(v => v > 0)));
  const hFim = Math.max(hIni + 10, new Date().getHours() + 1);
  const maxH = Math.max(1, ...horas);
  const passos = [
    ['nome', 'Dar o nome do seu estabelecimento', () => { S.abaConfig = 'geral'; ir('config'); }],
    ['pins', 'Trocar os PINs de exemplo dos usuários', () => { S.abaCad = 'usuarios'; ir('cadastros'); }],
    ['produtos', TX.passo_produtos || 'Cadastrar seus produtos (ou importar de planilha)', () => { S.abaCad = 'produtos'; ir('cadastros'); }],
    ...(S.nuvem ? [] : [['impressora', 'Configurar a impressora', () => { S.abaConfig = 'impressora'; ir('config'); }]]),
    ['pix', 'Cadastrar a chave Pix para o QR na tela', () => { S.abaConfig = 'pix'; ir('config'); }],
    ...(TEM_TOUR() ? [['teste', 'Fazer um pedido de teste', () => Tour.iniciar()]] : []),
    ...((S.nuvem || R.garcom) ? [['celular', R.garcom ? 'Abrir no celular do garçom' : 'Abrir no celular da equipe', () => { try { localStorage.setItem('mp_celular_visto', '1'); } catch {} S.abaConfig = 'rede'; ir('config'); }]] : []),
    ...(S.nuvem ? [] : [['licenca', 'Ativar a licença', () => { S.abaConfig = 'licenca'; ir('config'); }]]),
  ];
  d.primeirosPassos.teste = S.cfg.pedido_teste_ok === '1';
  try { d.primeirosPassos.celular = localStorage.getItem('mp_celular_visto') === '1'; } catch { d.primeirosPassos.celular = false; }
  const feitos = passos.filter(p => d.primeirosPassos[p[0]]).length;
  const abertosTotal = d.abertos.reduce((s, x) => s + x.total, 0);
  const comece = mostrarComece(d);
  const bannerAssist = !comece && S.cfg.configurado !== '1' && pode('gerente') ? html`<div class="card pad row wrap mp-setup" style="margin-bottom:14px;background:var(--accent-soft);border-color:transparent;gap:12px"><div style="flex:1;min-width:240px"><b>🧭 ${TX.assist_titulo || 'Configure o ' + PR.nome + ' do jeito do seu negócio'}</b><div class="small muted">${TX.assist_sub || 'Produtos, equipe e senhas, impressora, Pix e celulares — passo a passo, em uns 10 minutos.'}</div></div><button class="btn primary lg" id="ir-assist">${Number(S.cfg.assist_passo) > 1 ? 'Continuar configuração (passo ' + S.cfg.assist_passo + ')' : 'Começar configuração'}</button><button class="btn ghost sm" id="pular-assist" title="Não mostrar mais">✕</button></div>` : '';
  const att = d.nuvem && d.nuvem.atualizacao && d.nuvem.atualizacao.pronta && pode('gerente') ? html`<div class="card pad row wrap faixa-att"><span>⬆ <b>Versão ${d.nuvem.atualizacao.versao} pronta.</b> <span class="muted">O sistema se atualiza sozinho quando ninguém estiver usando (leva uns segundos e mantém tudo).</span></span><span class="spacer"></span><button class="btn sm primary" id="att-agora">Atualizar agora</button></div>` : '';
  c.innerHTML = html`${att}${raw(comece ? cardComece(d) : '')}${raw(faixaTeste())}${raw(cardAdicionaisPendentes())}${raw(pode('gerente') ? avisoEmailEmUso(S.licenca && S.licenca.email_em_uso, 'email-em-uso') : '')}<div class="mp-heading"><div><span class="mp-page-label">Visão geral</span><h1>${new Date().getHours()<12?'Bom dia':new Date().getHours()<18?'Boa tarde':'Boa noite'}, ${S.usuario.nome.split(' ')[0]}.</h1><p>${TX.inicio_sub || 'Seu negócio em movimento. Tudo sob controle.'}</p></div><div class="mp-date">${raw(mpIcon('calendario'))}${new Date().toLocaleDateString('pt-BR',{day:'numeric',month:'long',year:'numeric'})}</div></div>
    <section class="mp-hero"><div class="mp-hero-text"><div class="eyebrow">${TX.hero_eyebrow || 'DA CASA, PARA CADA CLIENTE'}</div><h2>${raw(TX.hero_titulo || 'Um bom atendimento<br>começa por aqui.')}</h2><p>${R.mesas ? `${d.mesasTotal-d.mesasOcupadas} mesas livres para a próxima boa experiência.` : (TX.hero_sub || 'Seu negócio em movimento. Tudo sob controle.')}</p><div class="row">${R.mesas ? html`<button class="btn" data-ir="mesas">Ver minhas mesas ${raw(mpIcon('seta'))}</button>` : html`<button class="btn" data-ir="${AT1[0]}">${AT1[1]} ${raw(mpIcon('seta'))}</button>`}${R.balcao ? html`<button class="btn secondary" data-ir="balcao">${R.mesas ? 'Venda no balcão' : (T.novo_pedido || 'Nova venda')}</button>` : ''}</div></div><div class="mp-art" aria-hidden="true">${raw(window.PRODUTO_ARTE_HERO || ARTE_HERO_PADRAO)}</div></section>
    <div class="mp-shortcuts">${ATALHOS.map(([id,t,sub])=>html`<button class="mp-shortcut" data-ir="${id}">${raw(mpIcon(MP_PATHS[id] ? id : 'inicio'))}<span><b>${t}</b><small>${sub}</small></span></button>`)}</div>
    <div class="cab"><h2>O ritmo de hoje</h2><span class="muted">${dataBR(d.hoje)} · ${d.vendas.n} venda(s) hoje</span><span class="spacer"></span>
      ${!d.caixaAberto ? html`<button class="btn primary" id="abrir-cx">Abrir caixa</button>` : html`<span class="badge ok">Caixa aberto</span>`}
      ${R.espera && R.mesas ? html`<button class="btn" id="btn-espera">+ Fila de espera</button>` : ''}${raw(PI.botoes ? PI.botoes(d) : '')}</div>
    <div class="kpis">
      <div class="card kpi"><div class="r">${raw(mpIcon('relatorios'))} Faturamento hoje</div><div class="v num">${brl(d.vendas.t)}</div>${delta(d.vendas.t, d.ontem)}</div>
      <div class="card kpi"><div class="r">${raw(mpIcon('ticket'))} Ticket médio</div><div class="v num">${brl(ticket)}</div><div class="delta muted">${d.vendas.n} venda(s)</div></div>
      <div class="card kpi"><div class="r">${raw(mpIcon('pdv'))} Em aberto</div><div class="v num">${brl(abertosTotal)}</div><div class="delta muted">${d.abertos.map(x => { const n = nomesTipo[x.tipo] || x.tipo; return `${x.n} ${n.length <= 3 ? n : n.toLowerCase()}`; }).join(' · ') || 'nada em aberto'}</div></div>
      ${R.mesas ? html`<div class="card kpi"><div class="r">${raw(mpIcon('mesas'))} Mesas</div><div class="v num">${d.mesasOcupadas}<span class="muted" style="font-size:16px">/${d.mesasTotal}</span></div><div class="delta muted">ocupadas${d.espera ? ` · ${d.espera} na fila` : ''}</div></div>` : ''}
      ${R.cozinha ? html`<div class="card kpi ${d.cozinha.atrasados ? 'alerta-card vermelho' : ''}"><div class="r">${raw(mpIcon('cozinha'))} Cozinha</div><div class="v num">${d.cozinha.pendentes}</div><div class="delta muted">${d.cozinha.atrasados ? `${d.cozinha.atrasados} atrasado(s)` : 'em preparo'}${d.cozinha.tempo_medio ? ` · média ${d.cozinha.tempo_medio} min` : ''}</div></div>` : ''}
      ${R.delivery ? html`<div class="card kpi"><div class="r">${raw(mpIcon('delivery'))} Delivery em rota</div><div class="v num">${d.emRota}</div><div class="delta muted">saíram para entrega</div></div>` : ''}
      ${raw(PI.kpis ? PI.kpis(d, dp) : '')}
    </div>
    ${bannerAssist}<div class="inicio-grid">${raw(PI.cards ? PI.cards(d, dp) : '')}
      <div class="card col8"><h3>Vendas por hora <span class="spacer"></span><span class="muted small">hoje</span></h3>
        <div class="grafico-horas">${Array.from({ length: hFim - hIni }, (_, i) => hIni + i).map(h => html`<div class="col" title="${h}h — ${brl(horas[h])}"><div class="b ${horas[h] ? '' : 'vazia'}" style="height:${Math.max(2, Math.round(horas[h] / maxH * 100))}%"></div><span class="h">${h}h</span></div>`)}</div></div>
      <div class="card"><h3>Mais vendidos hoje</h3><div class="lista-simples">${d.top.length ? d.top.map((t, i) => html`<div class="l"><b class="muted">${i + 1}.</b><span class="spacer">${t.nome}</span><span class="badge">${t.qtd}x</span><span class="num">${brl(t.total)}</span></div>`) : html`<div class="vazio">Ainda sem vendas hoje</div>`}</div></div>
      ${(d.chamadas.length || d.aprovacoes.length || d.online?.length) ? html`<div class="card col6 alerta-card"><h3>Precisa de atenção <span class="spacer"></span><button class="btn sm" id="ver-notif">Ver todas</button></h3><div class="lista-simples">
        ${(d.online || []).map(o => html`<div class="l">🌐 Pedido online #${o.numero} — ${o.cliente_nome} · ${brl(o.subtotal + o.taxa_entrega)}<span class="spacer"></span><button class="btn sm ok" data-on-aceitar="${o.pedido_id}">Aceitar</button><button class="btn sm" data-on-ver="${o.pedido_id}">Ver</button></div>`)}
        ${d.aprovacoes.map(a => html`<div class="l">⏳ Mesa ${a.mesa_nome}: ${a.itens} item(ns) pelo celular aguardando aprovação<span class="spacer"></span><button class="btn sm primary" data-ap="${a.pedido_id}">Aprovar</button></div>`)}
        ${d.chamadas.map(ch => html`<div class="l">${ch.tipo === 'conta' ? '💳' : '🙋'} Mesa ${ch.mesa_nome} ${ch.tipo === 'conta' ? 'pediu a conta' : 'chama o garçom'} (há ${minutosDesde(ch.criado_em)} min)<span class="spacer"></span><button class="btn sm" data-at="${ch.id}">Atendido</button></div>`)}
      </div></div>` : ''}
      ${(d.estoqueBaixo.length || d.esgotados.length) ? html`<div class="card col6 alerta-card"><h3>Estoque <span class="spacer"></span><button class="btn sm" data-ir="estoque">Ver estoque</button></h3><div class="lista-simples">
        ${d.esgotados.map(e => html`<div class="l"><span class="tag-esgotado">ESGOTADO</span> ${e.nome}</div>`)}
        ${d.estoqueBaixo.map(e => html`<div class="l">⚠ ${e.nome}<span class="spacer"></span><span class="num">${e.estoque} ${e.unidade && e.unidade !== 'un' ? e.unidade : 'un.'} (mín. ${e.estoque_minimo})</span></div>`)}
      </div></div>` : ''}
      ${feitos < passos.length ? html`<div class="card col6"><h3>Primeiros passos <span class="spacer"></span><span class="muted small">${feitos}/${passos.length}</span></h3>
        <div style="padding:0 16px"><div class="progresso"><i style="width:${Math.round(feitos / passos.length * 100)}%"></i></div></div>
        <div class="passos" style="margin-top:10px">${passos.map((p, i) => html`<div class="passo ${d.primeirosPassos[p[0]] ? 'ok' : ''}" data-passo="${i}"><span class="ck">${d.primeirosPassos[p[0]] ? '✓' : ''}</span><span>${p[1]}</span></div>`)}</div></div>` : ''}
      ${d.reservasHoje.length ? html`<div class="card col6"><h3>Reservas de hoje <span class="spacer"></span><button class="btn sm" data-ir="mesas">Ver mesas</button></h3><div class="lista-simples">${d.reservasHoje.map(r => html`<div class="l"><b>${r.hora}</b><span class="spacer">${r.nome} · ${r.pessoas} pessoas${r.mesa_nome ? ' · mesa ' + r.mesa_nome : ''}</span></div>`)}</div></div>` : ''}
      ${d.contas && (d.contas.vencidas.n || d.contas.hoje.n || d.contas.semana.n) ? html`<div class="card col6 fin-inicio ${d.contas.vencidas.n ? 'alerta-card vermelho' : d.contas.hoje.n ? 'alerta-card' : ''}"><h3>Contas a pagar <span class="spacer"></span><button class="btn sm" data-ir="financeiro">Ver contas</button></h3><div class="lista-simples">
        ${d.contas.vencidas.n ? html`<div class="l">⚠ <span class="spacer"><b>${d.contas.vencidas.n}</b> vencida(s)</span><b class="num">${brl(d.contas.vencidas.v)}</b></div>` : ''}
        ${d.contas.hoje.n ? html`<div class="l">⏰ <span class="spacer"><b>${d.contas.hoje.n}</b> vence(m) hoje</span><b class="num">${brl(d.contas.hoje.v)}</b></div>` : ''}
        ${d.contas.semana.n ? html`<div class="l">📅 <span class="spacer">${d.contas.semana.n} nos próximos 7 dias</span><b class="num">${brl(d.contas.semana.v)}</b></div>` : ''}
      </div></div>` : ''}
      ${raw(window.FIN_INICIO ? FIN_INICIO(d) : '')}
      ${d.fiadoAberto.v ? html`<div class="card col6"><h3>Fiado em aberto <span class="spacer"></span><button class="btn sm" id="ir-fiado">Ver</button></h3><div class="lista-simples"><div class="l"><span class="spacer">${d.fiadoAberto.n} cliente(s) devendo</span><b class="num">${brl(d.fiadoAberto.v)}</b></div></div></div>` : ''}
      ${d.porTipo.length > 1 || R.mesas ? html`<div class="card col6"><h3>Hoje por tipo</h3><div class="lista-simples">${d.porTipo.length ? d.porTipo.map(t => html`<div class="l"><span class="spacer">${nomesTipo[t.tipo] || t.tipo}</span><span class="badge">${t.n}</span><span class="num">${brl(t.total)}</span></div>`) : html`<div class="vazio">Sem vendas ainda</div>`}</div></div>` : ''}
    </div>`;
  if (PI.depois) PI.depois(c, d, dp);
  const on = (id, fn) => { const b = $('#' + id); if (b) b.onclick = fn; };
  on('abrir-cx', async () => { if (await abrirCaixaModal()) render(); });
  on('att-agora', async () => { if (!await confirmar('Atualizar agora', 'O sistema fecha por alguns segundos, se atualiza e volta sozinho. As telas abertas reconectam.', 'Atualizar agora')) return; await tentar(() => POST('/api/nuvem/atualizar'), 'Atualizando… a tela volta em alguns segundos'); });
  on('btn-espera', () => novaEspera().then(() => ir('mesas')));
  on('ver-notif', abrirNotificacoes);
  on('ir-fiado', () => { S.abaCaixa = 'fiado'; ir('caixa'); });
  on('ir-assist', () => { S.passoAssist = null; ir('assistente'); });
  on('pular-assist', async () => { await PUT('/api/config', { configurado: '1' }); S.cfg = await GET('/api/config'); render(); });
  c.onclick = async (e) => {
    if (await cliqueOnline(e)) return;
    const cm = e.target.closest('[data-comece]'); if (cm) return acaoComece(cm.dataset.comece);
    const ps = e.target.closest('[data-passo]'); if (ps) return passos[Number(ps.dataset.passo)][2]();
    const ap = e.target.closest('[data-ap]'); if (ap) return abrirEditor(await GET('/api/pedidos/' + ap.dataset.ap), 'mesas');
    const at = e.target.closest('[data-at]'); if (at) { await tentar(() => POST(`/api/chamadas/${at.dataset.at}/atender`)); carregarPendencias(); return render(); }
    const irv = e.target.closest('[data-ir]'); if (irv) ir(irv.dataset.ir);
    if (e.target.closest('[data-copiar-cod]')) navigator.clipboard?.writeText(S.licenca.codigo_maquina).then(() => toast('Código copiado', 'ok'));
    if (e.target.closest('[data-ir-licenca]')) { S.abaConfig = 'licenca'; ir('config'); }
  };
}

// ---------------- Mesas + fila de espera ----------------
async function vMesas(c) {
  const [mesas, espera, reservas] = await Promise.all([GET('/api/mesas'), GET('/api/espera'), GET('/api/reservas?proximas=1')]);
  const resHoje = reservas.filter(r => r.status === 'reservada');
  const areas = [...new Set(mesas.map(m => m.area || 'Geral'))];
  if (areas.length === 1) S.areaSel = '';
  const vis = S.areaSel ? mesas.filter(m => (m.area || 'Geral') === S.areaSel) : mesas;
  const ocup = mesas.filter(m => m.pedido);
  const total = ocup.reduce((s, m) => s + (m.pedido.total || 0), 0);
  const fila = espera.filter(e => ['esperando', 'chamado'].includes(e.status));
  c.innerHTML = html`<div class="cab"><div><span class="mp-page-label">Salão & atendimento</span><h1>Mapa de mesas</h1></div>
      <span class="badge">${ocup.length}/${mesas.length} ocupada(s)</span><span class="badge accent num">${brl(total)} em aberto</span>
      <span class="spacer"></span>
      <button class="btn" id="transf-mapa" title="Mudar a conta de mesa ou juntar duas mesas numa conta só">⇄ Transferir / juntar mesas</button>
      <div class="legenda"><span><i></i>Livre</span><span><i class="o"></i>Ocupada</span><span><i class="c"></i>Pediu a conta</span></div></div>
    ${areas.length > 1 ? html`<div class="areas"><button class="chip ${!S.areaSel ? 'on' : ''}" data-area="">Todas</button>${areas.map(a => html`<button class="chip ${S.areaSel === a ? 'on' : ''}" data-area="${a}">${a}</button>`)}</div>` : ''}
    <div class="mp-mesa-toolbar"><input type="text" id="mp-mesa-search" aria-label="Buscar mesa" placeholder="Buscar mesa pelo nome…"><div class="chips" aria-label="Filtrar mesas por situação"><button class="chip on" data-mp-status="">Todas</button><button class="chip" data-mp-status="livre">Livres · ${mesas.length-ocup.length}</button><button class="chip" data-mp-status="ocupada">Ocupadas · ${ocup.length}</button><button class="chip" data-mp-status="conta">Conta pedida</button></div></div>
    <div class="layout-mesas">
    <div class="mesas">${vis.map(m => {
      const p = m.pedido;
      const cls = [p ? (p.status === 'conta' ? 'conta' : 'ocupada') : '', m.chamadas.length ? 'chamando' : ''].join(' ');
      return html`<button class="mesa ${cls}" data-mesa="${m.id}" data-mp-name="${m.nome}" data-mp-state="${p ? p.status === 'conta' ? 'conta' : 'ocupada' : 'livre'}">
        <span class="nome">${m.nome}</span>
        ${p ? html`<span class="info">${hora(p.aberto_em)} · ${minutosDesde(p.aberto_em)} min${p.garcom_nome ? ' · ' + p.garcom_nome : ''}</span>
          <span class="valor num">${brl(p.total)}</span>
          ${p.status === 'conta' ? html`<span class="tag badge info">Conta</span>` : p.aguardando ? html`<span class="tag badge warn">${p.aguardando} p/ aprovar</span>` : p.pendentes ? html`<span class="tag badge warn">${p.pendentes} na cozinha</span>` : p.prontos ? html`<span class="tag badge ok">${p.prontos} pronto(s)</span>` : ''}`
          : html`<span class="info">Livre</span><span class="lug">${m.lugares} lugares</span>`}
        ${m.chamadas.length ? html`<span class="icones">${m.chamadas.map(ch => ch === 'conta' ? '💳' : '🙋')}</span>` : ''}
      </button>`;
    })}${mesas.length ? '' : html`<div class="vazio">Nenhuma mesa cadastrada. Vá em Cadastros → Mesas.</div>`}</div>
    <div class="card espera-painel">${raw(window.SALAO ? SALAO.reservasPendentes(reservas) : '')}<h3>Fila de espera <span class="badge">${fila.length}</span><span class="spacer"></span><button class="btn sm primary" id="nova-espera">+ Adicionar</button></h3>
      ${fila.length ? fila.map(e => html`<div class="espera-item ${e.status}"><div class="row"><span class="n">${e.nome}</span><span class="badge">${e.pessoas} 👥</span><span class="spacer"></span><span class="small muted">${minutosDesde(e.criado_em)} min</span></div>
        ${e.obs ? html`<div class="small muted">${e.obs}</div>` : ''}
        <div class="acoes">${e.status === 'esperando' ? html`<button class="btn sm" data-esp="${e.id}" data-st="chamado">📣 Chamar</button>` : html`<span class="badge warn">Chamado ${hora(e.chamado_em)}</span>`}${raw(window.SALAO ? SALAO.filaItem(e) : '')}
          ${e.telefone ? html`<a class="btn sm" target="_blank" href="${linkWhatsApp(e.telefone, `Olá ${e.nome}! Sua mesa no ${S.cfg.nome_estabelecimento} está pronta. Pode vir! 😊`)}">WhatsApp</a>` : ''}
          <button class="btn sm ok" data-esp="${e.id}" data-st="sentado">Sentar</button><button class="btn sm ghost danger" data-esp="${e.id}" data-st="desistiu">✕</button></div></div>`)
        : html`<div class="vazio small">Ninguém esperando.<br>Quando lotar, anote aqui quem chegou.</div>`}
      <h3 style="border-top:1px solid var(--line)">Reservas <span class="badge">${resHoje.length}</span><span class="spacer"></span><button class="btn sm" id="nova-reserva">+ Reservar</button></h3>
      ${resHoje.length ? resHoje.slice(0, 12).map(r => html`<div class="espera-item"><div class="row"><span class="n">${r.nome}</span><span class="badge">${r.pessoas} 👥</span><span class="spacer"></span><b>${r.data === hojeISO() ? '' : dataBR(r.data).slice(0, 5) + ' '}${r.hora}</b></div>
        <div class="small muted">${r.mesa_nome ? 'Mesa ' + r.mesa_nome : 'sem mesa definida'}${r.obs ? ' · ' + r.obs : ''}${r.telefone ? ' · ' + r.telefone : ''}</div>
        <div class="acoes"><button class="btn sm ok" data-res="${r.id}" data-st="chegou">Chegou → sentar</button>${r.telefone ? html`<a class="btn sm" target="_blank" href="${linkWhatsApp(r.telefone, `Olá ${r.nome}! Confirmando sua reserva no ${S.cfg.nome_estabelecimento} para ${r.pessoas} pessoa(s) às ${r.hora}${r.data !== hojeISO() ? ' do dia ' + dataBR(r.data) : ''}. Até logo!`)}">WhatsApp</a>` : ''}<button class="btn sm ghost danger" data-res="${r.id}" data-st="cancelada">✕</button></div></div>`)
        : html`<div class="vazio small">Nenhuma reserva.</div>`}
    </div></div>`;
  let mpStatus=S.mpMesaStatus||'';
  const buscaMesa=$('#mp-mesa-search');buscaMesa.value=S.mpMesaBusca||'';
  const filtrarMesas=()=>{S.mpMesaBusca=buscaMesa.value;S.mpMesaStatus=mpStatus;const q=buscaMesa.value.toLocaleLowerCase('pt-BR');let n=0;$$('[data-mp-state]',c).forEach(el=>{const mostrar=el.dataset.mpName.toLocaleLowerCase('pt-BR').includes(q)&&(!mpStatus||(mpStatus==='ocupada'?el.dataset.mpState!=='livre':el.dataset.mpState===mpStatus));el.hidden=!mostrar;if(mostrar)n++;});$$('[data-mp-status]',c).forEach(el=>el.classList.toggle('on',el.dataset.mpStatus===mpStatus));let empty=$('#mp-no-mesas');if(!empty){empty=document.createElement('div');empty.id='mp-no-mesas';empty.className='vazio';empty.textContent='Nenhuma mesa com esses filtros.';$('.layout-mesas .mesas').appendChild(empty);}empty.hidden=n>0;};
  buscaMesa.addEventListener('input',filtrarMesas);$$('[data-mp-status]',c).forEach(b=>b.onclick=()=>{mpStatus=b.dataset.mpStatus;filtrarMesas();});filtrarMesas();
  $('#nova-espera').onclick = () => novaEspera().then(() => render());
  $('#nova-reserva').onclick = () => novaReserva(mesas).then(() => render());
  c.onclick = async (e) => {
    const a = e.target.closest('[data-area]'); if (a) { S.areaSel = a.dataset.area; return render(); }
    const rs = e.target.closest('[data-res]');
    if (rs) {
      const r = resHoje.find(x => x.id === Number(rs.dataset.res));
      let mesa_id = r.mesa_id;
      if (rs.dataset.st === 'chegou' && (!mesa_id || mesas.find(m => m.id === mesa_id)?.pedido)) {
        const livres = mesas.filter(m => !m.pedido);
        mesa_id = await modal({ titulo: 'Sentar em qual mesa?', corpo: `<div class="mesas" style="grid-template-columns:repeat(auto-fill,minmax(90px,1fr))">${livres.map(m => `<button class="mesa" style="min-height:70px" data-d="${m.id}"><span class="nome" style="font-size:20px">${esc(m.nome)}</span><span class="lug">${m.lugares} lugares</span></button>`).join('') || '<div class="vazio">Nenhuma mesa livre</div>'}</div>`,
          aoAbrir: (f, fechar) => f.addEventListener('click', (ev) => { const b = ev.target.closest('[data-d]'); if (b) fechar(Number(b.dataset.d)); }) });
        if (!mesa_id) return;
      }
      const out = await tentar(() => PATCH('/api/reservas/' + r.id, { status: rs.dataset.st, mesa_id }));
      if (out.pedido) return abrirEditor(out.pedido, 'mesas');
      return render();
    }
    const es = e.target.closest('[data-esp]');
    if (es) {
      const st = es.dataset.st;
      let mesa_id = null;
      if (st === 'sentado') {
        const livres = mesas.filter(m => !m.pedido);
        mesa_id = await modal({ titulo: 'Sentar em qual mesa?', corpo: `<div class="mesas" style="grid-template-columns:repeat(auto-fill,minmax(90px,1fr))">${livres.map(m => `<button class="mesa" style="min-height:70px" data-d="${m.id}"><span class="nome" style="font-size:20px">${esc(m.nome)}</span><span class="lug">${m.lugares} lugares</span></button>`).join('') || '<div class="vazio">Nenhuma mesa livre</div>'}</div>`,
          aoAbrir: (f, fechar) => f.addEventListener('click', (ev) => { const b = ev.target.closest('[data-d]'); if (b) fechar(Number(b.dataset.d)); }) });
        if (!mesa_id) return;
      }
      const r = await tentar(() => PATCH('/api/espera/' + es.dataset.esp, { status: st, mesa_id }));
      if (r.pedido) return abrirEditor(r.pedido, 'mesas');
      return render();
    }
    if (e.target.closest('#transf-mapa')) return transferirNoMapa(mesas);
    const b = e.target.closest('[data-mesa]'); if (!b) return;
    const m = mesas.find(x => x.id === Number(b.dataset.mesa));
    if (m?.pedido) return abrirEditor(await GET('/api/pedidos/' + m.pedido.id), 'mesas');
    return abrirMesaLivre(m, 'mesas');
  };
}
// mesa livre: pede confirmação antes de ocupar
async function abrirMesaLivre(m, voltar) {
  const pessoas = await modal({ titulo: `Abrir a mesa ${m?.nome || ''}?`, corpo: `<div class="stack"><p class="muted">A mesa só fica ocupada depois que você confirmar.</p>
      <div class="rotulo">QUANTAS PESSOAS?</div><div class="stepper lg" id="ab-pes"><button type="button" class="btn" data-d="-1">−</button><b id="ab-n">${Math.min(m?.lugares || 2, 2)}</b><button type="button" class="btn" data-d="1">+</button><span class="muted small" style="margin-left:8px">(${m?.lugares || 4} lugares)</span></div></div>`,
    botoes: [{ texto: 'Cancelar' }, { texto: '✓ Abrir mesa', classe: 'primary', padrao: true, acao: (f) => Number($('#ab-n', f).textContent) }],
    aoAbrir: (f) => { $('#ab-pes', f).addEventListener('click', (ev) => { const d = ev.target.closest('[data-d]'); if (!d) return; const n = $('#ab-n', f); n.textContent = Math.max(1, Number(n.textContent) + Number(d.dataset.d)); }); } });
  if (!pessoas) return;
  const p = await tentar(() => POST(`/api/mesas/${m.id}/abrir`, { pessoas }));
  abrirEditor(p, voltar);
}
async function transferirNoMapa(mesas) {
  const ocupadas = mesas.filter(m => m.pedido);
  if (!ocupadas.length) return toast('Nenhuma mesa ocupada para transferir', 'erro');
  const origem = await modal({ titulo: '⇄ Transferir / juntar mesas', corpo: `<div class="stack"><p class="muted">1º) Escolha a mesa <b>de onde</b> saem os itens. No próximo passo você escolhe o destino: uma mesa livre (transferir) ou ocupada (juntar as contas).</p>
      <div class="mesas" style="grid-template-columns:repeat(auto-fill,minmax(100px,1fr))">${ocupadas.map(m => `<button class="mesa ocupada" style="min-height:76px" data-o="${m.id}"><span class="nome" style="font-size:20px">${esc(m.nome)}</span><span class="valor num">${brl(m.pedido.total)}</span></button>`).join('')}</div></div>`,
    aoAbrir: (f, fechar) => f.addEventListener('click', (ev) => { const b = ev.target.closest('[data-o]'); if (b) fechar(Number(b.dataset.o)); }) });
  if (!origem) return;
  const m = ocupadas.find(x => x.id === origem);
  const p = await GET('/api/pedidos/' + m.pedido.id);
  await transferir(p, true);
}
function novaReserva(mesas) {
  return modal({ titulo: 'Nova reserva', corpo: `<div class="stack"><div class="grid2"><label class="campo">Nome<input type="text" id="r-nome"></label><label class="campo">Pessoas<input type="number" id="r-pes" value="2" min="1"></label></div>
    <div class="grid3"><label class="campo">Data<input type="date" id="r-data" value="${hojeISO()}"></label><label class="campo">Hora<input type="time" id="r-hora" value="20:00"></label><label class="campo">Mesa (opcional)<select id="r-mesa"><option value="">—</option>${mesas.map(m => `<option value="${m.id}">${esc(m.nome)} (${m.lugares})</option>`).join('')}</select></label></div>
    <div class="grid2"><label class="campo">WhatsApp<input type="tel" id="r-tel"></label><label class="campo">Observação<input type="text" id="r-obs" placeholder="Aniversário, cadeirão..."></label></div></div>`,
    botoes: [{ texto: 'Cancelar' }, { texto: 'Reservar', classe: 'primary', padrao: true, acao: (f) => POST('/api/reservas', { nome: $('#r-nome', f).value, pessoas: $('#r-pes', f).value, data: $('#r-data', f).value, hora: $('#r-hora', f).value, mesa_id: $('#r-mesa', f).value || null, telefone: $('#r-tel', f).value, obs: $('#r-obs', f).value }) }] });
}
function novaEspera() {
  return modal({ titulo: 'Fila de espera', corpo: `<div class="stack"><div class="grid2"><label class="campo">Nome<input type="text" id="e-nome"></label><label class="campo">Pessoas<input type="number" id="e-pes" value="2" min="1"></label></div>
    <div class="grid2"><label class="campo">WhatsApp (opcional)<input type="tel" id="e-tel"></label><label class="campo">Observação<input type="text" id="e-obs" placeholder="Ex.: perto da janela"></label></div></div>`,
    botoes: [{ texto: 'Cancelar' }, { texto: 'Adicionar à fila', classe: 'primary', padrao: true, acao: (f) => POST('/api/espera', { nome: $('#e-nome', f).value, pessoas: $('#e-pes', f).value, telefone: $('#e-tel', f).value, obs: $('#e-obs', f).value }) }] })
    .then(r => (r && window.SALAO ? SALAO.aposEspera(r) : r));   // link/QR da fila para o cliente
}

// ---------------- Balcão ----------------
async function vBalcao(c) {
  const tiposBalcao = ['balcao', ...(PR.tipos_pedido || []).filter(t => !['mesa', 'delivery', 'balcao'].includes(t) && !(window.PRODUTO_TIPOS_FORA_BALCAO || []).includes(t))];
  const [todos, painel] = await Promise.all([GET('/api/pedidos?tipo=' + tiposBalcao.join(',') + '&ativos=1'), GET('/api/painel').catch(() => ({ prontos: [] }))]);
  const comandas = todos.filter(p => p.comanda);
  const lista = todos.filter(p => !p.comanda && p.origem !== 'totem');
  const prontoIds = new Set(painel.prontos.map(x => x.id));
  const linha = (p) => html`<tr class="click" data-p="${p.id}"><td><b>${p.comanda ? 'C' + p.comanda : '#' + p.numero}</b></td><td>${p.cliente_nome || '—'}${p.garcom_nome ? html` <span class="muted small">· ${p.garcom_nome}</span>` : ''}</td><td>${hora(p.aberto_em)} · ${minutosDesde(p.aberto_em)} min</td><td>${p.qtd_itens}</td>
        <td class="r num">${brl(p.total)}</td><td class="r num">${brl(p.pago)}</td><td class="r">${prontoIds.has(p.id) ? html`<button class="btn sm ok" data-entregar="${p.id}">✓ Pronto — entregar</button>` : p.pago >= p.total && p.total ? html`<span class="badge ok">Pago</span>` : html`<span class="badge warn">Em aberto</span>`}</td></tr>`;
  c.innerHTML = html`<div class="cab"><h1>${R.comandas ? 'Balcão e comandas' : (T.balcao || 'Venda rápida')}</h1><span class="spacer"></span>
      ${R.comandas ? html`<form class="row" id="f-comanda" style="gap:6px"><input type="text" inputmode="numeric" id="comanda-num" placeholder="Nº da comanda" style="width:150px"><button class="btn" type="submit">Abrir comanda</button></form>` : ''}
      <button class="btn primary lg" id="nova">+ ${T.novo_pedido || 'Nova venda'} <kbd style="margin-left:6px">N</kbd></button></div>
    ${raw(window.SALAO ? SALAO.balcao(todos.filter(p => p.origem === 'totem')) : '')}
    ${R.mesas ? html`<div class="card pad" style="margin-bottom:14px;padding:12px 16px"><b>O que é o Balcão?</b> <span class="muted">É a venda sem mesa: cliente pede no balcão e leva, retira ou come em pé (lanchonete, pastelaria, açaí). Já a <b>comanda numerada</b> é o cartão que o cliente recebe na entrada (bares, choperias): tudo vai sendo lançado nela e paga na saída. Mesas de verdade ficam na aba Mesas; entregas, em Delivery.</span></div>` : html`<div class="card pad" style="margin-bottom:14px;padding:12px 16px"><span class="muted">${TX.balcao_dica || 'Venda avulsa no balcão: escolha os itens, receba e pronto. Dá para colocar o nome do cliente para aparecer no histórico dele.'}</span></div>`}
    ${comandas.length ? html`<h3 style="margin:4px 0 8px">Comandas abertas (${comandas.length})</h3><div class="card" style="margin-bottom:16px"><table class="tab"><thead><tr><th>Comanda</th><th>Cliente</th><th>Aberta</th><th>Itens</th><th class="r">Total</th><th class="r">Pago</th><th></th></tr></thead><tbody>${comandas.map(linha)}</tbody></table></div>` : ''}
    ${lista.length ? html`<h3 style="margin:4px 0 8px">${R.mesas ? 'Vendas de balcão' : (T.pedidos || 'Vendas') + ' em aberto'}</h3><div class="card"><table class="tab"><thead><tr><th>Nº</th><th>Cliente</th><th>Aberto</th><th>Itens</th><th class="r">Total</th><th class="r">Pago</th><th></th></tr></thead><tbody>${lista.map(linha)}</tbody></table></div>` : comandas.length ? '' : html`<div class="card vazio">Nenhuma venda em aberto. Clique em <b>${T.novo_pedido || 'Nova venda'}</b>${R.comandas ? ', ou digite um número de comanda (cartão) para bares' : ''}.</div>`}
    <p class="muted small" style="margin-top:12px">${R.painel_senhas ? html`Painel de senhas para o cliente (TV): <a href="/painel" target="_blank">abrir /painel</a>. ` : ''}${R.visor ? html`Visor do cliente no caixa: <a href="/visor" target="_blank">abrir /visor</a>.` : ''}</p>`;
  $('#nova').onclick = async () => abrirEditor(await tentar(() => POST('/api/pedidos', { tipo: PR.tipo_balcao || 'balcao' })), 'balcao');
  if ($('#f-comanda')) $('#f-comanda').onsubmit = async (e) => { e.preventDefault(); const n = $('#comanda-num').value.trim(); if (!n) return; abrirEditor(await tentar(() => POST('/api/comandas/abrir', { numero: n })), 'balcao'); };
  c.onclick = async (e) => {
    const en = e.target.closest('[data-entregar]'); if (en) { e.stopPropagation(); await tentar(() => POST(`/api/pedidos/${en.dataset.entregar}/entregar`), 'Entregue'); return render(); }
    const tr = e.target.closest('[data-p]'); if (tr) abrirEditor(await GET('/api/pedidos/' + tr.dataset.p), 'balcao');
  };
}

// ---------------- Delivery ----------------
const DSTATUS = [
  { id: 'recebido', nome: 'Recebido', cls: '' }, { id: 'preparo', nome: 'Em preparo', cls: 'warn' },
  { id: 'saiu', nome: 'Saiu para entrega', cls: 'info' }, { id: 'entregue', nome: 'Entregue', cls: 'ok' },
];
function msgWhatsDelivery(p, status) {
  const nome = S.cfg.nome_estabelecimento;
  const itens = (p.itens || []).filter(i => !i.cancelado).map(i => `${i.qtd}x ${i.nome}`).join(', ');
  if (status === 'saiu') return `Olá ${p.cliente_nome}! Seu pedido #${p.numero} do ${nome} saiu para entrega 🛵${p.motoboy_nome ? ' com ' + p.motoboy_nome : ''}. Previsão: ${S.cfg.tempo_entrega_min || 45} min.${p.troco_para ? ` Troco para ${brl(p.troco_para)}.` : ''}`;
  if (status === 'preparo') return `Olá ${p.cliente_nome}! Recebemos seu pedido #${p.numero} no ${nome} e já estamos preparando 👨‍🍳 Total: ${brl(p.total)}.`;
  return `*${nome}* — Pedido #${p.numero}\n${itens}\nTotal: ${brl(p.total)}${p.endereco ? '\nEntrega: ' + p.endereco : ''}`;
}
async function vDelivery(c) {
  const ativos = await GET('/api/pedidos?tipo=delivery&ativos=1');
  if (window.ENT) S.motoboys = await GET('/api/cad/motoboys').catch(() => S.motoboys);   // entregador novo (Equipe) já aparece em "Quem vai entregar?"
  const novosOnline = ativos.filter(p => p.delivery_status === 'online');
  const detalhesOnline = await Promise.all(novosOnline.map(p => GET('/api/pedidos/' + p.id).catch(() => null)));
  const PAG = { pix: '⚡ Pix', cartao: '💳 Cartão na entrega', dinheiro: '💵 Dinheiro' };
  const hojeLista = await GET(`/api/pedidos?tipo=delivery&de=${hojeISO()}&ate=${hojeISO()}`);
  const entreguesHoje = hojeLista.filter(p => p.delivery_status === 'entregue' && p.status !== 'cancelado').slice(0, 30);
  const col = (st) => {
    const ps = st.id === 'entregue' ? entreguesHoje : ativos.filter(p => (p.delivery_status || 'recebido') === st.id);
    const prox = DSTATUS[DSTATUS.findIndex(x => x.id === st.id) + 1];
    return html`<div class="coluna"><h3>${st.nome} <span class="badge ${st.cls}">${ps.length}</span></h3>
      ${ps.map(p => { const min = minutosDesde(p.aberto_em); const atras = st.id !== 'entregue' && min > Number(S.cfg.tempo_entrega_min || 45); return html`<div class="ped" data-p="${p.id}" style="${atras ? 'border-color:var(--danger)' : ''}">
        <div class="t"><span>#${p.numero} ${p.cliente_nome || ''}</span><span class="num">${brl(p.total)}</span></div>
        ${p.origem === 'online' ? html`<div class="row small wrap" style="gap:4px;margin:2px 0"><span class="badge accent">🌐 Online</span>${p.retirada ? html`<span class="badge warn">🏃 Retirada</span>` : ''}${p.pagamento_online ? html`<span class="badge">${PAG[p.pagamento_online] || p.pagamento_online}</span>` : ''}</div>` : ''}
        <div class="small muted">${p.bairro || ''} · ${hora(p.aberto_em)} · <span style="${atras ? 'color:var(--danger);font-weight:700' : ''}">${min} min</span>${p.agendado_para ? html` · <b>⏰ ${p.agendado_para}</b>` : ''}</div>
        <div class="row small wrap" style="margin-top:6px">
          ${p.pago >= p.total && p.total > 0 ? html`<span class="badge ok">Pago</span>` : html`<span class="badge danger">A receber</span>`}
          ${window.ENT ? raw(ENT.selos(p)) : p.motoboy_nome ? html`<span class="badge">🛵 ${p.motoboy_nome}</span>` : ''}
          <span class="spacer"></span>
          ${prox ? html`<button class="btn sm" data-avancar="${p.id}" data-st="${prox.id}">${prox.nome} →</button>` : ''}
        </div></div>`; })}
    </div>`;
  };
  c.innerHTML = html`<div class="cab"><h1>Delivery</h1><span class="muted">${ativos.length - novosOnline.length} em andamento</span><span class="spacer"></span>${pode('gerente') && R.delivery ? html`<button class="btn" data-ir-online>🌐 Cardápio online</button>` : ''}<button class="btn primary lg" id="novo">+ Novo delivery <kbd style="margin-left:6px">N</kbd></button></div>
    ${detalhesOnline.filter(Boolean).length ? html`<div class="online-novos"><h2>🌐 Pedidos online esperando você <span class="badge danger">${detalhesOnline.filter(Boolean).length}</span></h2><div class="online-grid">${detalhesOnline.filter(Boolean).map(p => { const vivos = p.itens.filter(i => !i.cancelado); const tot = vivos.reduce((s, i) => s + (i.preco_unit + i.adicionais_total) * i.qtd, 0) + p.taxa_entrega - (p.desconto || 0); return html`<div class="card online-ped">
      <div class="row"><b>#${p.numero} · ${p.cliente_nome}</b><span class="spacer"></span><span class="muted small">há ${minutosDesde(p.aberto_em)} min</span></div>
      <div class="small">${p.retirada ? html`<span class="badge warn">🏃 Retirar no local</span>` : html`🛵 ${p.endereco}${p.bairro ? ' — ' + p.bairro : ''}`}</div>
      <div class="small muted">${p.cliente_telefone || ''} · ${PAG[p.pagamento_online] || ''}${p.troco_para ? ' · troco p/ ' + brl(p.troco_para) : ''}${p.cupom_codigo ? ` · 🎟 Cupom ${p.cupom_codigo} −${brl(p.desconto_cupom)}` : ''}${p.desconto_fidel ? ` · ⭐ Fidelidade −${brl(p.desconto_fidel)}` : ''}</div>
      <div class="itens">${vivos.map(i => html`<div class="item"><span class="q">${i.qtd}x</span><span class="n">${i.nome}<small>${detalheItem(i)}</small></span><span class="v num">${brl((i.preco_unit + i.adicionais_total) * i.qtd)}</span></div>`)}</div>
      ${p.obs ? html`<div class="small">📝 ${p.obs}</div>` : ''}
      <div class="row" style="margin-top:4px"><span class="muted small">${p.taxa_entrega ? 'Entrega ' + brl(p.taxa_entrega) : ''}</span><span class="spacer"></span><b class="num" style="font-size:18px">${brl(tot)}</b></div>
      <div class="row"><button class="btn ok block" data-on-aceitar="${p.id}">✓ Aceitar e mandar para a cozinha</button><button class="btn danger" data-on-recusar="${p.id}">Recusar</button></div></div>`; })}</div></div>` : ''}
    <div class="quadro">${DSTATUS.map(col)}</div>`;
  $('#novo').onclick = novoDelivery;
  c.onclick = async (e) => {
    if (await cliqueOnline(e)) return;
    if (e.target.closest('[data-ir-online]')) return ir('cardapio-online');
    const av = e.target.closest('[data-avancar]');
    if (av) {
      e.stopPropagation();
      const body = { delivery_status: av.dataset.st };
      const p = ativos.find(x => x.id === Number(av.dataset.avancar));
      if (av.dataset.st === 'saiu') {
        if (!p.motoboy_id && S.motoboys.length) { const mb = await escolherMotoboy(); if (mb === null) return; body.motoboy_id = mb; }
        const novo = await tentar(() => PATCH('/api/pedidos/' + p.id, body));
        if (p.cliente_telefone) toast('Avisar o cliente?', 'ok', { tempo: 8000, acao: { texto: 'WhatsApp', fn: () => window.open(linkWhatsApp(p.cliente_telefone, msgWhatsDelivery(novo, 'saiu'))) } });
      } else await tentar(() => PATCH('/api/pedidos/' + p.id, body));
      return render();
    }
    const card = e.target.closest('[data-p]');
    if (card) abrirEditor(await GET('/api/pedidos/' + card.dataset.p), 'delivery');
  };
}
function escolherMotoboy(atual) {
  return modal({
    titulo: 'Quem vai entregar?',
    corpo: `<div class="stack">${S.motoboys.map(m => `<button class="btn lg block ${m.id === atual ? 'primary' : ''}" data-mb="${m.id}">${esc(m.nome)}</button>`).join('')}<button class="btn block" data-mb="">Sem entregador</button></div>`,
    aoAbrir: (f, fechar) => f.addEventListener('click', (e) => { const b = e.target.closest('[data-mb]'); if (b) fechar(b.dataset.mb ? Number(b.dataset.mb) : 0); }),
  });
}
async function novoDelivery() {
  let cliente = {}, repetir = null;
  const opcoesBairro = S.bairros.map(b => `<option value="${b.id}">${esc(b.nome)} — ${brl(b.taxa)}</option>`).join('');
  const KM = window.ENT && ENT.ligado(S.cfg);   // frete por distância (entrega.js)
  const r = await modal({
    titulo: 'Novo delivery', largo: true,
    corpo: `<div class="stack">
      <label class="campo">Telefone ou nome do cliente<input type="tel" id="d-tel" placeholder="Digite para buscar clientes já cadastrados" autocomplete="off"></label>
      <div id="d-sug" class="stack" style="gap:6px"></div>
      <div id="d-hist"></div>
      <div class="grid2"><label class="campo">Nome<input type="text" id="d-nome"></label><label class="campo">Bairro${KM ? ENT.campoBairro(opcoesBairro, S.bairros) : `<select id="d-bairro"><option value="">— escolha —</option>${opcoesBairro}</select>`}</label></div>
      <div class="grid3"><label class="campo" style="grid-column: span 2">Endereço<input type="text" id="d-end" placeholder="Rua / avenida"></label><label class="campo">Número<input type="text" id="d-num"></label></div>
      <div class="grid2"><label class="campo">Complemento<input type="text" id="d-comp"></label><label class="campo">Ponto de referência<input type="text" id="d-ref"></label></div>
      <div class="grid3"><label class="campo">Troco para (R$)<input type="text" inputmode="decimal" id="d-troco" placeholder="vazio = não precisa"></label>
        <label class="campo">Agendar para (opcional)<input type="text" id="d-agd" placeholder="Ex.: 19:30 ou amanhã 12h"></label>
        <label class="campo">Observação<input type="text" id="d-obs"></label></div>
      ${KM ? ENT.campoTaxa() : ''}
    </div>`,
    botoes: [{ texto: 'Cancelar' }, {
      texto: 'Criar e lançar itens', classe: 'primary', padrao: true, acao: (f) => {
        const v = (id) => $(id, f).value.trim();
        if (!v('#d-nome')) throw new Error('Informe o nome do cliente');
        if (!v('#d-bairro') && S.bairros.length && !KM) throw new Error('Escolha o bairro');
        const fr = KM ? ENT.lerCaixa(f) : null;
        return { cliente: { id: cliente.id, telefone: v('#d-tel'), nome: v('#d-nome'), bairro_id: v('#d-bairro') || null, endereco: v('#d-end'), numero: v('#d-num'), complemento: v('#d-comp'), referencia: v('#d-ref'), ...(fr ? { bairro: fr.bairro } : {}) },
          troco_para: paraCentavos(v('#d-troco')), obs: v('#d-obs'), agendado_para: v('#d-agd'), ...(fr ? { taxa_entrega: fr.taxa_entrega, frete: fr.frete } : {}) };
      },
    }],
    aoAbrir: (f) => {
      const buscar = adiar(async () => {
        const q = $('#d-tel', f).value.trim();
        if (q.length < 3) { $('#d-sug', f).innerHTML = ''; return; }
        const lista = await GET('/api/clientes/busca?q=' + encodeURIComponent(q)).catch(() => []);
        $('#d-sug', f).innerHTML = lista.map((cl, i) => `<button class="btn" style="justify-content:flex-start" data-cl="${i}">
          <b>${esc(cl.nome || 'Sem nome')}</b> <span class="muted">${esc(cl.telefone || '')} · ${esc([cl.endereco, cl.numero].filter(Boolean).join(', '))} ${cl.bairro_nome ? '· ' + esc(cl.bairro_nome) : ''}${cl.pedidos ? ` · ${cl.pedidos} pedido(s)` : ''}</span></button>`).join('');
        $('#d-sug', f).onclick = async (e) => {
          const b = e.target.closest('[data-cl]'); if (!b) return;
          cliente = lista[Number(b.dataset.cl)];
          $('#d-tel', f).value = cliente.telefone || ''; $('#d-nome', f).value = cliente.nome || '';
          $('#d-bairro', f).value = cliente.bairro_id || ''; $('#d-end', f).value = cliente.endereco || '';
          $('#d-num', f).value = cliente.numero || ''; $('#d-comp', f).value = cliente.complemento || ''; $('#d-ref', f).value = cliente.referencia || '';
          $('#d-sug', f).innerHTML = '';
          if (KM) ENT.preencherCaixa(f, cliente);
          const h = await GET(`/api/clientes/${cliente.id}/historico`).catch(() => null);
          if (h && h.pedidos.length) {
            const u = h.pedidos[0];
            $('#d-hist', f).innerHTML = `<div class="historico-cliente"><b>${h.total_pedidos} pedido(s)</b> · ${brl(h.total_gasto)} no total${cliente.obs ? ` · <i>${esc(cliente.obs)}</i>` : ''}<br>
              Último (${dataBR(u.aberto_em)}): ${esc(u.itens.map(i => i.qtd + 'x ' + i.nome).join(', '))} <button class="btn sm" id="d-rep" style="margin-left:6px">Repetir último pedido</button></div>`;
            $('#d-rep', f).onclick = (ev) => { ev.preventDefault(); repetir = repetir ? null : u.itens; ev.target.textContent = repetir ? '✓ Vai repetir' : 'Repetir último pedido'; ev.target.classList.toggle('primary', !!repetir); };
          }
        };
      }, 250);
      $('#d-tel', f).addEventListener('input', () => { cliente = {}; repetir = null; $('#d-hist', f).innerHTML = ''; buscar(); });
      if (KM) ENT.ligarCaixa(f, S.bairros);
    },
  });
  if (!r) return;
  let p = await tentar(() => POST('/api/pedidos', { tipo: 'delivery', ...r }));
  if (repetir) {
    const itens = repetir.map(i => ({ produto_id: i.produto_id, produto2_id: i.produto2_id, tamanho: i.tamanho, qtd: i.qtd, obs: i.obs, adicionais: JSON.parse(i.adicionais || '[]').map(a => a.id) }));
    p = await tentar(() => POST(`/api/pedidos/${p.id}/itens`, { itens }), 'Pedido repetido e enviado').catch(() => p);
  }
  abrirEditor(p, 'delivery');
}

// ---------------- Visor do cliente ----------------
const visorEnviar = adiar((pedido, pix) => {
  if (!estacaoImpressao() && localStorage.getItem('mp_visor') !== '1') return;
  const resumo = pedido ? { titulo: tituloPedido(pedido), itens: pedido.itens.filter(i => !i.cancelado && i.status !== 'aguardando').map(i => ({ nome: i.nome, qtd: i.qtd, valor: (i.preco_unit + i.adicionais_total) * i.qtd })),
    subtotal: pedido.subtotal, servico: pedido.servico, desconto: pedido.desconto, taxa: pedido.taxa_entrega, gorjeta: pedido.gorjeta, total: pedido.total, pago: pedido.pago, restante: pedido.restante, status: pedido.status } : null;
  POST('/api/visor', { pedido: resumo, pix: pix || null }).catch(() => {});
}, 200);

// ---------------- Editor de pedido ----------------
function abrirEditor(pedido, voltar) { S.pedido = pedido; S.carrinho = []; S.voltar = voltar; S.busca = ''; ir('editor'); }
async function sairDoEditor() {
  visorEnviar(null);
  if (S.carrinho.length && !(await confirmar('Itens não enviados', 'Há itens que ainda não foram enviados. Sair mesmo assim?', 'Sair sem enviar', 'danger solid'))) return;
  const p = S.pedido;
  if (p && !p.itens.filter(i => !i.cancelado).length && !p.pagamentos.length && p.status === 'aberto') await POST(`/api/pedidos/${p.id}/cancelar`, { motivo: 'Pedido vazio' }).catch(() => {});
  ir(S.voltar);
}
function tituloPedido(p) {
  if (window.PRODUTO_TITULO_PEDIDO) { const t = window.PRODUTO_TITULO_PEDIDO(p); if (t) return t; }
  if (p.tipo === 'mesa') return 'Mesa ' + p.mesa_nome;
  if (p.comanda) return 'Comanda ' + p.comanda;
  if (p.tipo === 'delivery') return 'Delivery #' + p.numero;
  if (p.tipo === 'balcao') return (R.mesas ? 'Balcão' : (T.pedido || 'Venda')) + ' #' + p.numero + (p.cliente_nome && !R.mesas ? ' — ' + p.cliente_nome : '');
  return ((T.tipos || {})[p.tipo] || T.pedido || 'Venda') + ' #' + p.numero + (p.cliente_nome ? ' — ' + p.cliente_nome : '');
}

async function vEditor(c) {
  c.innerHTML = `<div class="editor">
    <section class="card painel-pedido" id="painel"></section>
    <section>
      <div class="row busca"><input type="text" id="busca" placeholder="${TOQUE ? 'Buscar produto…' : 'Buscar produto por nome ou código...  (atalho: /)'}" autocomplete="off"></div>
      <div class="cats" id="cats"></div>
      <div class="prods" id="prods" style="margin-top:10px"></div>
    </section></div>`;
  $('#busca').value = S.busca;
  $('#busca').addEventListener('input', (e) => { S.busca = e.target.value; desenharProdutos(); });
  $('#busca').addEventListener('keydown', (e) => { if (e.key === 'Enter') { const p = produtosFiltrados()[0]; if (p) adicionarProduto(p.id, e.shiftKey); } });
  $('#cats').onclick = (e) => { const b = e.target.closest('[data-cat]'); if (!b) return; S.catSel = Number(b.dataset.cat); S.busca = ''; $('#busca').value = ''; desenharProdutos(); };
  $('#prods').onclick = async (e) => {
    const esg = e.target.closest('[data-esg]');
    if (esg) { e.stopPropagation(); return alternarEsgotado(Number(esg.dataset.esg)); }
    const pz = e.target.closest('[data-pizza]');
    if (pz) { const cat = S.cardapio.categorias.find(c => c.id === Number(pz.dataset.pizza)); const item = await montarPizza(cat, S.cardapio); if (item) juntarNoCarrinho(item); return; }
    const ex = e.target.closest('[data-extra-cat]'); if (ex && window.PRODUTO_CATALOGO_CLIQUE) return window.PRODUTO_CATALOGO_CLIQUE(ex.dataset.extraCat, S.pedido);
    const b = e.target.closest('[data-prod]'); if (b) adicionarProduto(Number(b.dataset.prod));
  };
  desenharProdutos();
  desenharPedido();
  if (!TOQUE) setTimeout(() => $('#busca')?.focus(), 50);
}
function produtosFiltrados() {
  const q = S.busca.trim().toLowerCase();
  const vis = S.cardapio.produtos.filter(p => !(window.PRODUTO_OCULTAR_PRODUTO && window.PRODUTO_OCULTAR_PRODUTO(p)));
  if (q) return vis.filter(p => p.nome.toLowerCase().includes(q) || (p.codigo && String(p.codigo).toLowerCase() === q));
  if (S.catSel === -1) return vis.filter(p => p.destaque);
  return vis.filter(p => p.categoria_id === S.catSel);
}
function mpProductArt(p) {
 return `<span class="mp-product-art" aria-hidden="true">${arteSvg(p.nome, S.cardapio.categorias.find(c=>c.id===p.categoria_id)?.nome)}</span>`;
}

function desenharProdutos() {
  if (!$('#cats')) return;
  const temDestaque = S.cardapio.produtos.some(p => p.destaque);
  $('#cats').innerHTML = (temDestaque ? `<button class="cat ${!S.busca && S.catSel === -1 ? 'on' : ''}" data-cat="-1">★ Destaques</button>` : '') + S.cardapio.categorias.map(c => `<button class="cat ${!S.busca && c.id === S.catSel ? 'on' : ''}" data-cat="${c.id}">${esc(c.nome)}</button>`).join('');
  const lista = produtosFiltrados();
  const catAtual = S.cardapio.categorias.find(c => c.id === S.catSel);
  const pizzaCard = !S.busca && catAtual?.meio_a_meio && lista.length ? (() => { const min = Math.min(...lista.map(p => p.tamanhos.length ? Math.min(...p.tamanhos.map(t => t.preco)) : p.preco_atual)); return `<button class="prod pizza-card" data-pizza="${catAtual.id}"><span class="prod-txt"><b>🍕 Montar ${esc(catAtual.nome.replace(/s$/i, ''))}</b><span class="desc">1 ou 2 sabores, tamanho, borda</span><span class="row"><span class="preco num">a partir de ${brl(min)}</span></span></span></button>`; })() : '';
  const extraTopo = window.PRODUTO_CATALOGO_EXTRA ? window.PRODUTO_CATALOGO_EXTRA(S.pedido) : '';
  $('#prods').innerHTML = extraTopo + pizzaCard + (lista.length ? lista.map(p => `<button class="prod ${p.esgotado ? 'esgotado' : ''}" data-prod="${p.id}" title="${esc(p.descricao || '')}">${p.foto ? fotoHtml(p.foto, p.nome).s : mpProductArt(p)}<span class="prod-txt"><b>${esc(p.nome)} ${p.promo_ativa ? '<span class="tag-promo">PROMO</span>' : ''}${p.esgotado ? '<span class="tag-esgotado">ESGOTADO</span>' : ''}</b>
      ${p.descricao ? `<span class="desc">${esc(p.descricao.slice(0, 50))}</span>` : ''}
      <span class="row"><span class="preco num">${p.tamanhos.length ? 'a partir de ' + brl(Math.min(...p.tamanhos.map(t => t.preco))) : brl(p.preco_atual) + (p.por_quilo ? '/kg' : '')}</span><span class="spacer"></span>
        ${p.controla_estoque ? `<span class="small ${p.estoque_baixo ? 'tag-esgotado' : 'muted'}">${p.por_quilo ? String(+Number(p.estoque).toFixed(3)).replace('.', ',') + ' kg' : p.estoque + ' un.'}</span>` : ''}
        <span class="muted small" data-esg="${p.id}" title="Marcar esgotado/disponível" style="cursor:pointer">${p.esgotado ? '↺' : '⊘'}</span></span></span></button>`).join('')
    : `<div class="vazio" style="grid-column:1/-1">Nenhum produto ${S.busca ? 'encontrado' : 'nesta categoria'}.</div>`);
}
async function alternarEsgotado(id) {
  const p = S.cardapio.produtos.find(x => x.id === id);
  await tentar(() => POST(`/api/produtos/${id}/esgotado`, { esgotado: !p.esgotado }), p.esgotado ? `${p.nome} disponível de novo` : `${p.nome} marcado como esgotado`);
}
function juntarNoCarrinho(item) {
  const chave = (x) => [x.produto_id, x.produto2_id, x.tamanho, x.obs, JSON.stringify(x.adicionais), x.preco_livre ?? '', x.nome_livre || ''].join('|');
  const igual = S.carrinho.find(x => chave(x) === chave(item));
  if (igual) igual.qtd += item.qtd; else S.carrinho.push(item);
  if (S.busca) { S.busca = ''; $('#busca').value = ''; desenharProdutos(); }
  desenharPedido();
  if (TOQUE) toast(`✓ ${item.qtd > 1 ? item.qtd + 'x ' : ''}${item._nome} adicionado`, 'ok', { tempo: 1600 });
  else $('#busca')?.focus();
}
async function adicionarProduto(id, rapido = false) {
  const p = S.cardapio.produtos.find(x => x.id === id);
  if (!p) return;
  if (p.esgotado) return toast(`${p.nome} está esgotado`, 'erro');
  if (p.por_quilo && window.SALAO) return SALAO.pesar(p);
  const cat = S.cardapio.categorias.find(c => c.id === p.categoria_id);
  let item;
  if (cat?.meio_a_meio && !rapido) item = await montarPizza(cat, S.cardapio, p);
  else if (rapido && !p.tamanhos.length && !p.escolha) item = { produto_id: p.id, produto2_id: null, tamanho: null, qtd: 1, obs: '', adicionais: [], _nome: p.nome, _preco: p.preco_atual, _ads: [] };
  else item = await escolherProduto(p, S.cardapio);
  if (!item) return;
  juntarNoCarrinho(item);
}

function desenharPedido() {
  const p = S.pedido;
  const el = $('#painel');
  if (!el || !p) return;
  visorEnviar(p);
  const encerrado = ['fechado', 'cancelado'].includes(p.status);
  const ativos = p.itens.filter(i => !i.cancelado && i.status !== 'aguardando');
  const aguardando = p.itens.filter(i => !i.cancelado && i.status === 'aguardando');
  const totalCarrinho = S.carrinho.reduce((s, i) => s + i._preco * i.qtd, 0);
  const stItem = { aguardando: ['Aguardando aprovação', 'warn'], a_pagar: ['Espera pagamento', 'warn'], pendente: ['Na fila', 'warn'], preparando: ['Preparando', 'warn'], pronto: ['Pronto', 'ok'], entregue: ['Entregue', 'ok'] };
  const temPix = !!S.cfg.pix_chave;

  el.innerHTML = html`
    <div class="topo">
      <div class="row"><button class="btn sm" id="voltar">← Voltar <kbd>Esc</kbd></button><button class="btn sm so-celular" id="fechar-painel">▾ Esconder pedido</button><span class="spacer"></span>
        ${p.status === 'conta' ? html`<span class="badge info">Conta pedida</span>` : ''}
        ${p.status === 'fechado' ? html`<span class="badge ok">Pago</span>` : ''}
        ${p.status === 'cancelado' ? html`<span class="badge danger">Cancelado</span>` : ''}</div>
      <div class="row" style="margin-top:10px"><h1>${tituloPedido(p)}</h1><span class="spacer"></span>
        ${p.tipo !== 'delivery' && R.pessoas !== false ? html`<button class="btn sm" id="pessoas" title="Pessoas (para dividir a conta)">👥 ${p.pessoas}</button>` : ''}${p.tipo === 'mesa' || p.comanda || (R.profissionais && p.tipo !== 'delivery') ? html`<button class="btn sm" id="garcom" title="${T.profissional || 'Garçom'} responsável">${p.garcom_nome ? '🧑‍🍳 ' + p.garcom_nome : (T.profissional || 'Garçom') + '?'}</button>` : ''}${raw(window.PRODUTO_EDITOR_BOTOES ? window.PRODUTO_EDITOR_BOTOES(p) : '')}</div>
      <div class="muted small">Aberto às ${hora(p.aberto_em)} · ${minutosDesde(p.aberto_em)} min${p.cliente_nome && p.tipo === 'mesa' ? ' · ' + p.cliente_nome : ''}</div>
      ${p.tipo === 'delivery' ? html`<div class="card pad" style="margin-top:10px;box-shadow:none;background:var(--surface-2)">
        <div class="row"><b>${p.cliente_nome}</b><span class="spacer"></span><span class="muted">${p.cliente_telefone}</span>${p.cliente_telefone ? html`<a class="btn sm" target="_blank" id="zap" href="${linkWhatsApp(p.cliente_telefone, msgWhatsDelivery(p, p.delivery_status === 'saiu' ? 'saiu' : 'preparo'))}">WhatsApp</a>` : ''}</div>
        <div class="small">${p.endereco}${p.bairro ? ' — ' + p.bairro : ''}</div>
        <div class="row wrap small" style="margin-top:8px">
          <button class="btn sm" id="motoboy">🛵 ${p.motoboy_nome || 'Escolher entregador'}</button>
          <select id="dstatus" style="width:auto;min-height:32px;padding:4px 8px">${DSTATUS.map(s => html`<option value="${s.id}" ${s.id === p.delivery_status ? raw('selected') : ''}>${s.nome}</option>`)}</select>
          ${p.origem === 'online' ? html`<span class="badge accent">🌐 Online${p.retirada ? ' · retirada' : ''}${p.pagamento_online ? ' · ' + ({ pix: 'Pix', cartao: 'Cartão', dinheiro: 'Dinheiro' }[p.pagamento_online] || '') : ''}</span>` : ''}
          ${p.troco_para ? html`<span class="badge warn">Troco p/ ${brl(p.troco_para)}</span>` : ''}
          ${p.agendado_para ? html`<span class="badge info">⏰ ${p.agendado_para}</span>` : ''}
          ${window.ENT ? raw(ENT.selosEditor(p)) : ''}
        </div></div>` : ''}
      ${p.tipo === 'balcao' || (!['mesa', 'delivery'].includes(p.tipo) && !window.PRODUTO_EDITOR_CABECALHO) ? html`<button class="btn sm ghost" id="nome-cli" style="margin-top:6px;padding-left:0">👤 ${p.cliente_nome || 'Adicionar nome do cliente'}</button>` : ''}${raw(window.PRODUTO_EDITOR_CABECALHO ? window.PRODUTO_EDITOR_CABECALHO(p) : '')}
      ${p.obs ? html`<div class="small" style="margin-top:6px">📝 ${p.obs}</div>` : ''}
    </div>
    <div class="lista">
      ${aguardando.length ? html`<div class="carrinho" style="background:var(--info-soft)"><h3 style="color:var(--info)">${p.origem === 'online' ? 'Pedido online — aceitar?' : 'Pedido do cliente pelo celular — aprovar?'}</h3>
        <div class="itens">${aguardando.map(i => html`<div class="item"><span class="q">${i.qtd}x</span><span class="n">${i.nome}<small>${detalheItem(i)}</small></span><span class="v num">${brl((i.preco_unit + i.adicionais_total) * i.qtd)}</span>
          <button class="x" data-recusar="${i.id}" title="Recusar este item">✕</button></div>`)}</div>
        <div class="row" style="margin-top:8px"><button class="btn ok block" id="aprovar">✓ Aprovar e enviar à cozinha</button><button class="btn danger" id="recusar-todos">Recusar</button></div></div>` : ''}
      ${S.carrinho.length ? html`<div class="carrinho"><h3>${R.cozinha ? 'A enviar' : 'A lançar'} (${S.carrinho.length})</h3>
        <div class="itens">${S.carrinho.map((i, idx) => html`<div class="item"><span class="q">${i.qtd}x</span>
          <span class="n">${i._nome}<small>${detalheItem({ adicionais: i._ads, obs: i.obs })}</small></span>
          <span class="v num">${brl(i._preco * i.qtd)}</span><button class="x" data-rm="${idx}" title="Remover">✕</button></div>`)}</div>
        <button class="btn primary block" id="enviar" style="margin:8px 0 4px">${R.cozinha ? 'Enviar para a cozinha' : (T.enviar || 'Lançar')} · ${brl(totalCarrinho)} <kbd style="margin-left:6px">F10</kbd></button></div>` : ''}
      ${p.itens.filter(i => i.status !== 'aguardando' || i.cancelado).length ? html`<div class="itens">${p.itens.filter(i => i.status !== 'aguardando' || i.cancelado).map(i => html`<div class="item ${i.cancelado ? 'cancelado' : ''}">
          <span class="q">${i.qtd}x</span>
          <span class="n">${i.nome} ${i.origem === 'cliente' ? html`<span class="origem">QR</span>` : ''}<small>${detalheItem(i)}</small>
            <small class="st">${i.cancelado ? html`<span class="badge danger">Cancelado: ${i.cancel_motivo}</span>` : html`${R.cozinha || i.status !== 'entregue' ? html`<span class="badge ${stItem[i.status][1]}">${stItem[i.status][0]}</span> ` : ''}${hora(i.criado_em)} · ${i.profissional_nome || i.usuario_nome || ''}`}</small></span>${R.profissionais && !i.cancelado && !encerrado ? html`<button class="pessoa-chip ${i.profissional_id ? 'on' : ''}" data-prof-item="${i.id}" title="Quem fez este item (comissão)">${(T.icone_profissional || '✂') + ' ' + (i.profissional_nome ? i.profissional_nome.split(' ')[0] : '?')}</button>` : ''}
          ${p.pessoas > 1 && !i.cancelado && !encerrado ? html`<button class="pessoa-chip ${i.pessoa ? 'on' : ''}" data-pessoa="${i.id}" title="De quem é este item? (clique para trocar)">${i.pessoa ? '👤' + i.pessoa : '👥'}</button>` : ''}
          ${PRECO_LIVRE() && !i.cancelado && !encerrado ? html`<button class="v num preco-edit" data-preco-item="${i.id}" title="Mudar preço ou quantidade">${brl((i.preco_unit + i.adicionais_total) * i.qtd)}${i.qtd > 1 ? html`<small>${i.qtd} × ${brl(i.preco_unit + i.adicionais_total)}</small>` : ''} <span class="lapis">✎</span></button>` : html`<span class="v num">${brl((i.preco_unit + i.adicionais_total) * i.qtd)}</span>`}
          ${!i.cancelado && !encerrado ? html`<button class="x" data-cancel="${i.id}" title="Cancelar item">✕</button>` : ''}
        </div>`)}</div>` : (S.carrinho.length || aguardando.length) ? '' : html`<div class="vazio">Escolha os produtos ao lado →</div>`}
      ${p.pessoas > 1 && ativos.length ? html`<div class="muted small" style="padding:6px 0">👥 = dividido entre todos · clique no 👤 para marcar de quem é o item</div>` : ''}
    </div>
    <div class="base">
      <div class="totais">
        <div class="l"><span>Subtotal</span><span class="num">${brl(p.subtotal)}</span></div>
        ${p.tipo === 'mesa' ? html`<div class="l"><span>Serviço (${p.servico_pct}%)</span><span class="num">${brl(p.servico)}</span></div>` : ''}
        ${p.taxa_entrega ? html`<div class="l"><span>Taxa de entrega</span><span class="num">${brl(p.taxa_entrega)}</span></div>` : ''}
        ${p.gorjeta ? html`<div class="l"><span>Gorjeta</span><span class="num">${brl(p.gorjeta)}</span></div>` : ''}
        ${raw(VENDAS.linhasPedido(p))}
        ${p.pago ? html`<div class="l"><span>Já pago</span><span class="num">− ${brl(p.pago)}</span></div>` : ''}
        <div class="l total"><span>${p.pago ? 'Falta' : 'Total'}</span><span class="num">${brl(p.pago ? p.restante : p.total)}</span></div>
      </div>
      ${encerrado ? html`<div class="acoes"><button class="btn" id="imp-cupom">Imprimir cupom</button><button class="btn" id="voltar2">Fechar</button></div>` : html`
      <div class="acoes">
        <button class="btn ok lg" id="receber" ${ativos.length ? '' : raw('disabled')}>Receber ${brl(p.restante)} <kbd style="margin-left:6px">F8</kbd></button>
        <button class="btn so-celular" id="mais-acoes">⋯ Mais ações</button><div class="acoes-sec">
        <button class="btn" id="imp-conta" ${ativos.length ? '' : raw('disabled')}>${T.imprimir_conferencia || 'Imprimir conferência'}</button>
        ${temPix ? html`<button class="btn" id="pix" ${ativos.length ? '' : raw('disabled')}>QR Pix na tela</button>` : R.cozinha ? html`<button class="btn" id="imp-coz" ${ativos.length ? '' : raw('disabled')}>Reimprimir cozinha</button>` : ''}
        ${p.tipo === 'mesa' ? html`<button class="btn" id="transferir" ${p.itens.length ? '' : raw('disabled')}>Transferir / juntar</button>` : html`<button class="btn" id="obs">Observação</button>`}
        ${R.pacotes && p.tipo !== 'mesa' ? html`<button class="btn" id="usar-pacote">🎟 Usar pacote</button>` : ''}${p.cliente_id && !R.mesas ? html`<button class="btn" id="ficha-cli">👤 Ficha do cliente</button>` : ''}
        ${p.tipo === 'mesa' ? html`<button class="btn" id="obs">Observação</button>` : R.cozinha ? html`<button class="btn" id="imp-coz2" ${ativos.length ? '' : raw('disabled')}>Reimprimir cozinha</button>` : ''}
        ${raw(window.PRODUTO_EDITOR_ACOES ? window.PRODUTO_EDITOR_ACOES(p) : '')}
        <button class="btn danger" id="cancelar-ped">${T.cancelar_pedido || 'Cancelar pedido'}</button></div>
      </div>`}
    </div>`;
  const barraAntiga = $('#mob-barra'); if (barraAntiga) barraAntiga.remove();
  el.insertAdjacentHTML('afterend', barraPedidoHtml(p, totalCarrinho)); ligarBarraPedido();

  const on = (id, fn) => { const b = $('#' + id, el); if (b) b.onclick = fn; };
  on('voltar', sairDoEditor); on('voltar2', () => ir(S.voltar));
  on('fechar-painel', () => document.documentElement.classList.remove('ver-pedido'));
  on('mais-acoes', () => $('.acoes-sec', el).classList.toggle('aberto'));
  on('enviar', enviarCarrinho);
  on('receber', () => abrirPagamento());
  on('pix', () => mostrarPix(p.restante, 'MP' + p.numero));
  on('imp-conta', () => imprimirPedido(p, 'preconta'));
  on('imp-cupom', () => imprimirPedido(p, 'cupom'));
  on('imp-coz', () => tentar(() => imprimirAqui(`/api/pedidos/${p.id}/imprimir`, { tipo: 'cozinha' }), 'Enviado para impressão'));
  on('imp-coz2', () => tentar(() => imprimirAqui(`/api/pedidos/${p.id}/imprimir`, { tipo: 'cozinha' }), 'Enviado para impressão'));
  on('transferir', () => transferir());
  on('aprovar', async () => { S.pedido = await tentar(() => POST('/api/itens/aprovar', { item_ids: aguardando.map(i => i.id) }), 'Aprovado e enviado à cozinha'); desenharPedido(); carregarPendencias(); });
  on('recusar-todos', async () => {
    const m = await pedirTexto('Recusar pedido do cliente', 'Motivo (o cliente vê no celular)', 'Indisponível no momento');
    if (m === null) return;
    S.pedido = await tentar(() => POST('/api/itens/aprovar', { item_ids: aguardando.map(i => i.id), recusar: true, motivo: m }), 'Recusado'); desenharPedido(); carregarPendencias();
  });
  on('pessoas', async () => { const v = await pedirTexto('Pessoas na mesa', 'Quantidade de pessoas', p.pessoas, 'number'); if (v) { S.pedido = await tentar(() => PATCH('/api/pedidos/' + p.id, { pessoas: Number(v) })); desenharPedido(); } });
  on('garcom', async () => {
    const garcons = (await GET('/api/cad/usuarios').catch(() => [])).filter(u => R.profissionais ? u.perfil !== 'caixa' : u.perfil === 'garcom');
    const id = await modal({ titulo: (T.profissional || 'Garçom') + ' responsável', corpo: `<div class="stack">${garcons.map(g => `<button class="btn lg block ${g.id === p.garcom_id ? 'primary' : ''}" data-g="${g.id}">${esc(g.nome)}</button>`).join('')}<button class="btn block" data-g="">Nenhum</button></div>`,
      aoAbrir: (f, fechar) => f.addEventListener('click', (e) => { const b = e.target.closest('[data-g]'); if (b) fechar(b.dataset.g === '' ? 0 : Number(b.dataset.g)); }) });
    if (id === null) return;
    S.pedido = await tentar(() => PATCH('/api/pedidos/' + p.id, { garcom_id: id || null })); desenharPedido();
  });
  on('usar-pacote', () => usarPacoteNaComanda(p));
  on('ficha-cli', () => fichaCliente(p.cliente_id));
  if (window.PRODUTO_EDITOR_MONTAR) window.PRODUTO_EDITOR_MONTAR(el, p, { on, redesenhar: desenharPedido, encerrado });
  on('nome-cli', async () => { const v = await pedirTexto('Nome do cliente', 'Nome (aparece no pedido)', p.cliente_nome || ''); if (v !== null) { S.pedido = await tentar(() => PATCH('/api/pedidos/' + p.id, { cliente_nome: v })); desenharPedido(); } });
  on('obs', async () => { const v = await pedirTexto('Observação do pedido', 'Observação', p.obs || ''); if (v !== null) { S.pedido = await tentar(() => PATCH('/api/pedidos/' + p.id, { obs: v })); desenharPedido(); } });
  on('motoboy', async () => { const mb = await escolherMotoboy(p.motoboy_id); if (mb !== null) { S.pedido = await tentar(() => PATCH('/api/pedidos/' + p.id, { motoboy_id: mb || null })); desenharPedido(); } });
  const ds = $('#dstatus', el);
  if (ds) ds.onchange = async () => { S.pedido = await tentar(() => PATCH('/api/pedidos/' + p.id, { delivery_status: ds.value })); desenharPedido(); };
  on('cancelar-ped', async () => {
    let body = { motivo: 'Pedido vazio' };
    if (ativos.length) { const a = await pinGerente(true, 'Cancelar pedido inteiro'); if (!a) return; body = { motivo: a.motivo, pin_gerente: a.pin }; }
    else if (!(await confirmar('Cancelar pedido', 'Cancelar este pedido vazio?', 'Cancelar pedido', 'danger solid'))) return;
    await tentar(() => POST(`/api/pedidos/${p.id}/cancelar`, body), 'Pedido cancelado');
    ir(S.voltar);
  });
  el.onclick = async (e) => {
    const rm = e.target.closest('[data-rm]');
    if (rm) { S.carrinho.splice(Number(rm.dataset.rm), 1); desenharPedido(); return; }
    const pf = e.target.closest('[data-prof-item]');
    if (pf) {
      const profs = (await GET('/api/cad/usuarios').catch(() => [])).filter(u => u.perfil !== 'caixa');
      const id = await modal({ titulo: 'Quem fez este item?', corpo: `<div class="stack">${profs.map(g => `<button class="btn lg block" data-g="${g.id}">${esc(g.nome)}</button>`).join('')}<button class="btn block" data-g="">Ninguém</button></div>`,
        aoAbrir: (f, fechar) => f.addEventListener('click', (ev) => { const b = ev.target.closest('[data-g]'); if (b) fechar(b.dataset.g === '' ? 0 : Number(b.dataset.g)); }) });
      if (id === null) return;
      S.pedido = await tentar(() => PATCH('/api/itens/' + pf.dataset.profItem + '/profissional', { profissional_id: id || null })); desenharPedido(); return;
    }
    const ps = e.target.closest('[data-pessoa]');
    if (ps) { const it = p.itens.find(i => i.id === Number(ps.dataset.pessoa)); const prox = (it.pessoa + 1) % (p.pessoas + 1); S.pedido = await tentar(() => PATCH(`/api/itens/${it.id}/pessoa`, { pessoa: prox })); desenharPedido(); return; }
    const rc = e.target.closest('[data-recusar]');
    if (rc) { S.pedido = await tentar(() => POST('/api/itens/aprovar', { item_ids: [Number(rc.dataset.recusar)], recusar: true, motivo: 'Indisponível' })); desenharPedido(); carregarPendencias(); return; }
    const pe = e.target.closest('[data-preco-item]');
    if (pe) {
      const it = p.itens.find(i => i.id === Number(pe.dataset.precoItem));
      const r = await modal({ titulo: 'Mudar item', corpo: `<div class="stack"><label class="campo">Descrição<input type="text" id="pe-n" value="${esc(it.nome)}"></label><div class="grid2"><label class="campo">Quantidade<input type="number" id="pe-q" min="1" value="${it.qtd}"></label><label class="campo">Preço unitário (R$)<input type="text" inputmode="decimal" id="pe-p" value="${brlCurto(it.preco_unit)}" style="font-weight:700;font-size:18px"></label></div><div class="muted small" id="pe-t"></div></div>`,
        aoAbrir: (f) => { const t = () => { $('#pe-t', f).textContent = 'Total do item: ' + brl((paraCentavos($('#pe-p', f).value) || 0) * (Number($('#pe-q', f).value) || 1)); }; f.addEventListener('input', t); t(); setTimeout(() => $('#pe-p', f).select(), 40); },
        botoes: [{ texto: 'Cancelar' }, { texto: 'Salvar', classe: 'primary', padrao: true, acao: (f) => { const v = paraCentavos($('#pe-p', f).value); if (!(v >= 0) || $('#pe-p', f).value.trim() === '') throw new Error('Informe o preço'); return { preco: v, qtd: Number($('#pe-q', f).value) || 1, nome: $('#pe-n', f).value.trim() }; } }] });
      if (!r) return;
      S.pedido = await tentar(() => PATCH(`/api/itens/${it.id}/preco`, r), 'Item atualizado'); desenharPedido(); return;
    }
    const cx = e.target.closest('[data-cancel]');
    if (cx) {
      const it = p.itens.find(i => i.id === Number(cx.dataset.cancel));
      if (window.PRODUTO_REMOVER_SEM_GERENTE && window.PRODUTO_REMOVER_SEM_GERENTE(p, it)) {
        if (!(await confirmar('Tirar item', `Tirar "${it.nome}" ${window.PRODUTO_REMOVER_SEM_GERENTE_TEXTO || 'desta conta'}?`, 'Tirar', 'danger solid'))) return;
        S.pedido = await tentar(() => POST(`/api/itens/${it.id}/cancelar`, { motivo: 'Removido do orçamento', qtd: it.qtd }), 'Item removido'); desenharPedido(); return;
      }
      let qtd = it.qtd;
      if (it.qtd > 1) { const v = await pedirTexto('Cancelar item', `Quantas unidades de "${it.nome}" cancelar? (máx. ${it.qtd})`, it.qtd, 'number'); if (!v) return; qtd = Math.min(it.qtd, Math.max(1, Number(v) || 1)); }
      const a = await pinGerente(true, 'Cancelar ' + it.nome);
      if (!a) return;
      S.pedido = await tentar(() => POST(`/api/itens/${it.id}/cancelar`, { motivo: a.motivo, pin_gerente: a.pin, qtd }), 'Item cancelado');
      desenharPedido();
    }
  };
}
async function enviarCarrinho() {
  const itens = S.carrinho.map(({ produto_id, produto2_id, tamanho, qtd, obs, adicionais, preco_livre, nome_livre }) => ({ produto_id, produto2_id, tamanho, qtd, obs, adicionais, preco_livre, nome_livre }));
  const b = $('#enviar'); if (b) b.disabled = true;
  try { S.pedido = await POST(`/api/pedidos/${S.pedido.id}/itens`, { itens }); S.carrinho = []; toast(R.cozinha ? 'Pedido enviado' : (T.lancado || 'Itens lançados'), 'ok'); }
  catch (e) { toast(e.message, 'erro'); }
  desenharPedido();
}
async function transferir(pedido, doMapa = false) {
  const p = pedido || S.pedido;
  const mesas = (await GET('/api/mesas')).filter(m => m.id !== p.mesa_id).sort((a, b) => (a.area || '').localeCompare(b.area || '') || a.nome.localeCompare(b.nome, 'pt', { numeric: true }));
  const ativos = p.itens.filter(i => !i.cancelado);
  const r = await modal({
    titulo: `Transferir / juntar — da mesa ${p.mesa_nome}`, largo: true,
    corpo: `<div class="stack"><p class="muted small">Mesa <b>livre</b>: a conta muda de mesa. Mesa <b>ocupada</b>: as contas se juntam numa só (os itens vão para a conta de destino).</p>
      <label class="check"><input type="radio" name="modo" value="todos" checked> Mesa inteira (todos os itens)</label>
      <label class="check"><input type="radio" name="modo" value="alguns"> Só alguns itens</label>
      <div id="t-itens" class="stack hidden" style="gap:4px;padding-left:26px">${ativos.map(i => `<label class="check"><input type="checkbox" value="${i.id}"> ${i.qtd}x ${esc(i.nome)} <span class="muted num">${brl((i.preco_unit + i.adicionais_total) * i.qtd)}</span></label>`).join('')}</div>
      <div class="rotulo" style="margin-top:6px">PARA A MESA</div>
      <div class="mesas" style="grid-template-columns:repeat(auto-fill,minmax(90px,1fr))">${mesas.map(m => `<button class="mesa ${m.pedido ? 'ocupada' : ''}" style="min-height:70px" data-dest="${m.id}"><span class="nome" style="font-size:20px">${esc(m.nome)}</span><span class="info">${m.pedido ? 'Ocupada (juntar)' : 'Livre'}${m.area ? ' · ' + esc(m.area) : ''}</span></button>`).join('')}</div>
    </div>`,
    aoAbrir: (f, fechar) => {
      f.addEventListener('change', () => $('#t-itens', f).classList.toggle('hidden', $('input[name=modo]:checked', f).value !== 'alguns'));
      f.addEventListener('click', (e) => {
        const b = e.target.closest('[data-dest]'); if (!b) return;
        const alguns = $('input[name=modo]:checked', f).value === 'alguns';
        const ids = alguns ? $$('#t-itens input:checked', f).map(c => Number(c.value)) : [];
        if (alguns && !ids.length) return toast('Marque os itens', 'erro');
        fechar({ mesa_id: Number(b.dataset.dest), item_ids: ids });
      });
    },
  });
  if (!r) return;
  const dest = mesas.find(m => m.id === r.mesa_id);
  const novo = await tentar(() => POST(`/api/pedidos/${p.id}/transferir`, r), dest?.pedido ? `Contas juntadas na mesa ${dest.nome}` : `Transferido para a mesa ${dest?.nome || ''}`);
  if (doMapa) return render();
  if (r.item_ids.length) { S.pedido = await GET('/api/pedidos/' + p.id); desenharPedido(); } else abrirEditor(novo, 'mesas');
}

// ---------------- Pix na tela ----------------
async function mostrarPix(valor, txid) {
  const r = await tentar(() => GET(`/api/pix?valor=${valor}&txid=${encodeURIComponent(txid)}`));
  if (S.pedido) visorEnviar(S.pedido, { codigo: r.codigo, valor });
  await modal({ titulo: 'Pagar com Pix', corpo: html`<div class="pix-box stack" style="align-items:center">
      <div class="valor-grande num">${brl(valor)}</div>
      <div class="qr">${raw(qrImg(r.codigo, 5))}</div>
      <div class="muted small">Aponte a câmera do celular, ou copie o código abaixo (Pix copia e cola).</div>
      <textarea readonly id="pix-cod">${r.codigo}</textarea>
      <div class="muted small">Chave: ${r.chave} · ${r.nome}</div>
      <p class="small" style="color:var(--warn)">⚠ Confira o pagamento no app do banco antes de dar baixa.</p></div>`.s,
    botoes: [{ texto: 'Copiar código', acao: (f) => { navigator.clipboard?.writeText($('#pix-cod', f).value); toast('Código copiado', 'ok'); return false; } }, { texto: 'Fechar', classe: 'primary', padrao: true }] });
  if (S.pedido) visorEnviar(S.pedido, null);
}

// ---------------- Pagamento ----------------
async function abrirPagamento() {
  if (S.carrinho.length) { toast('Envie ou remova os itens pendentes antes de receber', 'erro'); return; }
  if (S.pedido.aguardando) { toast('Aprove ou recuse os itens do cliente antes de receber', 'erro'); return; }
  if (S.pedido.restante <= 0 && S.pedido.total === 0 && S.pedido.itens.some(i => !i.cancelado)) {
    if (!(await confirmar('Conta sem valor', 'Esta conta está zerada (pacote, cortesia ou desconto total). Concluir sem receber?', 'Concluir'))) return;
    const r = await tentar(() => POST(`/api/pedidos/${S.pedido.id}/concluir`), 'Conta concluída');
    S.pedido = r; await finalizado(r); return;
  }
  if (!S.caixa.aberto) {
    if (await confirmar('Caixa fechado', 'Para receber pagamentos é preciso abrir o caixa. Abrir agora?', 'Abrir caixa')) { if (!(await abrirCaixaModal())) return; } else return;
  }
  let formaSel = S.formas.filter(f => !f.fiado)[0]?.id;
  let p = S.pedido;
  let porPessoaDados = null, modoPessoa = false;
  const temPix = !!S.cfg.pix_chave;
  const desenhar = async (f) => {
    const porPessoa = p.pessoas > 1 ? Math.ceil(p.restante / p.pessoas) : 0;
    const forma = S.formas.find(x => x.id === formaSel);
    if (modoPessoa) porPessoaDados = await GET(`/api/pedidos/${p.id}/por-pessoa`).catch(() => null);
    $('#pg-corpo', f).innerHTML = html`
      <div class="grid2" style="align-items:start">
        <div class="stack">
          <div class="totais">
            <div class="l"><span>Subtotal</span><span class="num">${brl(p.subtotal)}</span></div>
            ${p.tipo === 'mesa' ? html`<div class="l"><label class="check"><input type="checkbox" id="pg-serv" ${p.servico_pct ? raw('checked') : ''}> Serviço (${p.servico_pct || S.cfg.servico_pct}%)</label><span class="num">${brl(p.servico)}</span></div>` : ''}
            ${p.taxa_entrega ? html`<div class="l"><span>Taxa de entrega</span><span class="num">${brl(p.taxa_entrega)}</span></div>` : ''}
            ${R.garcom || p.gorjeta ? html`<div class="l"><button class="btn sm ghost" id="pg-gorj" style="padding-left:0">Gorjeta ✎</button><span class="num">${p.gorjeta ? brl(p.gorjeta) : '—'}</span></div>` : ''}
            ${raw(VENDAS.linhasPagamento(p))}
            <div class="l"><button class="btn sm ghost" id="pg-desc" style="padding-left:0">Desconto ✎</button><span class="num">${VENDAS.manual(p) ? '− ' + brl(VENDAS.manual(p)) : '—'}</span></div>
            <div class="l total"><span>Total</span><span class="num">${brl(p.total)}</span></div>
          </div>
          ${raw(VENDAS.blocoPagamento(p))}
          ${R.mesas ? '' : raw('<!--')}<div class="row"><span class="muted">Dividir por</span><button class="btn sm" data-pes="-1">−</button><b class="num">${p.pessoas}</b><button class="btn sm" data-pes="1">+</button>
            <span class="spacer"></span>${porPessoa ? html`<button type="button" class="badge accent num" id="pg-cada" title="Preencher com o valor de uma pessoa" style="cursor:pointer;border:0">${brl(porPessoa)} cada ↓</button>` : ''}</div>${R.mesas ? '' : raw('-->')}
          ${p.pessoas > 1 ? html`<button class="btn sm ${modoPessoa ? 'primary' : ''}" id="pg-modo">${modoPessoa ? '▾ Conta por pessoa (itens de cada um)' : '▸ Ver conta por pessoa (itens de cada um)'}</button>` : ''}
          ${modoPessoa && porPessoaDados ? html`<div class="stack" style="gap:6px">${porPessoaDados.linhas.map(l => html`<div class="card pad" style="padding:10px 12px;box-shadow:none"><div class="row"><b>👤 Pessoa ${l.pessoa}</b><span class="spacer"></span><b class="num">${brl(l.total)}</b></div>
            <div class="small muted">${l.itens.map(i => i.qtd + 'x ' + i.nome).join(', ') || 'sem itens próprios'}${l.compartilhado ? ` · + ${brl(l.compartilhado)} dos compartilhados` : ''}</div>
            <div class="row" style="margin-top:6px"><button class="btn sm" data-pp-val="${l.total}">Receber ${brl(l.total)}</button><button class="btn sm ghost" data-pp-imp="${l.pessoa}">Imprimir</button></div></div>`)}
            ${porPessoaDados.itens_comuns.length ? html`<div class="small muted">Compartilhados (÷${porPessoaDados.pessoas}): ${porPessoaDados.itens_comuns.map(i => i.qtd + 'x ' + i.nome).join(', ')}. Marque de quem é cada item na tela do pedido (👤).</div>` : ''}</div>` : ''}
          ${p.pagamentos.length ? html`<div><div class="rotulo">PAGAMENTOS</div>
            ${p.pagamentos.map(pg => html`<div class="row" style="padding:6px 0;border-bottom:1px dashed var(--line)"><span>${pg.forma_nome}</span><span class="spacer"></span>
              <span class="num">${brl(pg.valor)}${pg.troco ? html` <span class="muted">(troco ${brl(pg.troco)})</span>` : ''}</span><button class="btn sm ghost danger" data-estorno="${pg.id}" title="Estornar">✕</button></div>`)}</div>` : ''}
        </div>
        <div class="stack">
          <div class="card pad" style="box-shadow:none;background:var(--surface-2);text-align:center"><div class="rotulo">FALTA RECEBER</div><div class="valor-grande num">${brl(p.restante)}</div></div>
          <div class="formas">${S.formas.map(fp => html`<button class="forma ${fp.id === formaSel ? 'on' : ''}" data-forma="${fp.id}">${fp.nome}</button>`)}</div>
          <label class="campo">Valor recebido<input type="text" inputmode="decimal" id="pg-valor" value="${brlCurto(p.restante)}" style="font-size:20px;font-weight:700"></label>
          ${forma?.fiado ? html`<div class="card pad stack" style="background:var(--warn-soft);border:0;box-shadow:none;gap:6px"><b>Venda a prazo (fiado)</b><div class="grid2"><label class="campo">Nome do cliente<input type="text" id="pg-fnome" value="${p.cliente_nome || ''}"></label><label class="campo">Telefone<input type="tel" id="pg-ftel" value="${p.cliente_telefone || ''}"></label></div><label class="campo">Observação<input type="text" id="pg-fobs" placeholder="Ex.: paga dia 10"></label><div class="small muted">Fica em Caixa → Fiado para receber depois. Precisa do PIN do gerente.</div></div>` : ''}
          <div id="pg-troco" class="muted"></div>
          ${temPix && /pix/i.test(forma?.nome || '') ? html`<button class="btn" id="pg-pix">Mostrar QR Pix de ${brl(p.restante)}</button>` : ''}
          <button class="btn ok lg block" id="pg-lancar">Lançar pagamento</button>
        </div>
      </div>`;
    const inp = $('#pg-valor', f);
    const atualizarTroco = () => {
      const v = paraCentavos(inp.value);
      const fm = S.formas.find(x => x.id === formaSel);
      $('#pg-troco', f).innerHTML = v > p.restante ? (fm?.dinheiro ? `Troco: <b class="num" style="color:var(--ok);font-size:18px">${brl(v - p.restante)}</b>` : '<span style="color:var(--danger)">Valor acima do restante (troco só em dinheiro)</span>') : '';
    };
    inp.addEventListener('input', atualizarTroco);
    inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); e.stopPropagation(); $('#pg-lancar', f).click(); } });
    atualizarTroco();
    const cada = $('#pg-cada', f); if (cada) cada.onclick = () => { inp.value = brlCurto(Math.min(porPessoa, p.restante)); atualizarTroco(); inp.focus(); inp.select(); };
    setTimeout(() => { inp.focus(); inp.select(); }, 30);
  };

  await modal({
    titulo: 'Receber — ' + tituloPedido(p), largo: true, corpo: '<div id="pg-corpo"></div>',
    aoAbrir: (f, fechar) => {
      desenhar(f);
      f.addEventListener('change', async (e) => { if (e.target.id === 'pg-serv') { p = await tentar(() => PATCH('/api/pedidos/' + p.id, { servico_pct: e.target.checked ? Number(S.cfg.servico_pct || 10) : 0 })); desenhar(f); } });
      f.addEventListener('click', async (e) => {
        if (await VENDAS.cliquePagamento(e, p, (np) => { p = np; desenhar(f); })) return;   // cupom e fidelidade (vendas.js)
        const fb = e.target.closest('[data-forma]');
        if (fb) { formaSel = Number(fb.dataset.forma); desenhar(f); return; }
        const pes = e.target.closest('[data-pes]');
        if (pes) { p = await tentar(() => PATCH('/api/pedidos/' + p.id, { pessoas: Math.max(1, p.pessoas + Number(pes.dataset.pes)) })); desenhar(f); return; }
        if (e.target.closest('#pg-pix')) return mostrarPix(p.restante, 'MP' + p.numero);
        if (e.target.closest('#pg-modo')) { modoPessoa = !modoPessoa; desenhar(f); return; }
        const ppv = e.target.closest('[data-pp-val]');
        if (ppv) { const inp = $('#pg-valor', f); inp.value = brlCurto(Math.min(Number(ppv.dataset.ppVal), p.restante)); inp.dispatchEvent(new Event('input')); inp.focus(); return; }
        const ppi = e.target.closest('[data-pp-imp]');
        if (ppi) { tentar(() => imprimirAqui(`/api/pedidos/${p.id}/imprimir`, { tipo: 'preconta', pessoa: Number(ppi.dataset.ppImp) }), 'Enviado para impressão'); return; }
        if (e.target.closest('#pg-gorj')) {
          const v = await pedirTexto('Gorjeta para o garçom', 'Valor (R$) — além da taxa de serviço', p.gorjeta ? brlCurto(p.gorjeta) : '');
          if (v === null) return;
          p = await tentar(() => PATCH('/api/pedidos/' + p.id, { gorjeta: paraCentavos(v) })); desenhar(f); return;
        }
        if (e.target.closest('#pg-desc')) {
          const v = await pedirTexto('Desconto', 'Valor em R$ ou percentual (ex.: 5,00 ou 10%)', '');
          if (v === null) return;
          const valor = v.includes('%') ? Math.round(p.subtotal * (parseFloat(v.replace(',', '.')) || 0) / 100) : paraCentavos(v);
          let pin = null;
          const maxPct = Number(S.cfg.desconto_max_caixa_pct || 0);
          const livre = maxPct > 0 && valor <= Math.round(p.subtotal * maxPct / 100);
          if (valor > 0 && S.usuario.perfil !== 'gerente' && !livre) { const a = await pinGerente(false, `Autorizar desconto${maxPct ? ` (acima de ${maxPct}%)` : ''}`); if (!a) return; pin = a.pin; }
          p = await tentar(() => PATCH('/api/pedidos/' + p.id, { desconto: valor, pin_gerente: pin })); desenhar(f); return;
        }
        const est = e.target.closest('[data-estorno]');
        if (est) {
          if (!(await confirmar('Estornar pagamento', 'Remover este pagamento?', 'Estornar', 'danger solid'))) return;
          let pin = '';
          if (S.usuario.perfil !== 'gerente') { const a = await pinGerente(false, 'Autorizar estorno'); if (!a) return; pin = a.pin; }
          p = await tentar(() => DEL(`/api/pagamentos/${est.dataset.estorno}?pin_gerente=${encodeURIComponent(pin || '')}`)); desenhar(f); return;
        }
        if (e.target.closest('#pg-lancar')) {
          const valor = paraCentavos($('#pg-valor', f).value);
          const extra = {};
          const fm = S.formas.find(x => x.id === formaSel);
          if (fm?.fiado) {
            extra.fiado_nome = $('#pg-fnome', f).value.trim(); extra.fiado_telefone = $('#pg-ftel', f).value.trim(); extra.fiado_obs = $('#pg-fobs', f).value.trim();
            if (!extra.fiado_nome) return toast('Informe o nome do cliente para o fiado', 'erro');
            const a = await pinGerente(false, 'Autorizar venda fiado'); if (!a) return; extra.pin_gerente = a.pin;
          }
          const r = await tentar(() => POST(`/api/pedidos/${p.id}/pagamentos`, { forma_id: formaSel, valor, ...extra })).catch(() => null);
          if (!r) return;
          p = r;
          if (r.fechou) { fechar(true); S.pedido = r; await finalizado(r); } else desenhar(f);
        }
      });
    },
  });
  if (S.view === 'editor' && S.pedido && S.pedido.status !== 'fechado') { S.pedido = await GET('/api/pedidos/' + S.pedido.id); desenharPedido(); }
}
async function finalizado(p) {
  const nf = window.Fiscal ? await window.Fiscal.aposPagamento(p).catch(() => ({})) : {};
  const r = await modal({
    titulo: 'Pagamento concluído',
    corpo: html`<div style="text-align:center" class="stack"><div style="font-size:46px;color:var(--ok)">✓</div>
      ${p.troco ? html`<div class="muted">Troco</div><div class="valor-grande num" style="color:var(--ok)">${brl(p.troco)}</div>` : html`<div class="muted">Conta encerrada.</div>`}
      ${nf && nf.nota ? html`<div class="badge ok" style="align-self:center">Nota fiscal nº ${nf.nota.numero || '—'} emitida${nf.nota.homologacao ? ' (teste)' : ''}</div>` : ''}</div>`.s,
    botoes: [{ texto: 'Imprimir cupom', valor: 'imprimir' }, ...(nf && nf.botao ? [{ texto: 'Nota fiscal', valor: 'nfce' }] : []), ...(nf && nf.nota && nf.nota.danfe ? [{ texto: 'Imprimir nota fiscal', valor: 'nfce-imp' }] : []), ...(p.cliente_telefone ? [{ texto: 'Comprovante por WhatsApp', valor: 'zap' }] : []), { texto: 'Concluir', classe: 'primary', padrao: true, valor: 'ok' }],
  });
  if (r === 'imprimir') await imprimirPedido(p, 'cupom');
  if (r === 'nfce') await window.Fiscal.emitirComCpf(p);
  if (r === 'nfce-imp') window.open(nf.nota.danfe, '_blank', 'noopener');
  if (r === 'zap') window.open(linkWhatsApp(p.cliente_telefone, msgWhatsDelivery(p, 'comprovante') + '\nPago ✓ Obrigado!'));
  if (p.tipo === 'delivery' && p.delivery_status !== 'entregue' && S.view === 'editor') { S.pedido = await GET('/api/pedidos/' + p.id); desenharPedido(); return; }
  ir(S.voltar);
}

// ---------------- PDV (fechar contas rápido) ----------------
async function vPDV(c) {
  const d = await GET('/api/pdv');
  const tipoNome = nomesTipo;
  const rotulo = (p) => (window.PRODUTO_ROTULO_PDV && window.PRODUTO_ROTULO_PDV(p)) || (p.tipo === 'mesa' ? (p.comanda ? `Comanda ${p.comanda}` : `Mesa ${p.mesa_nome || ''}`) : p.tipo === 'delivery' ? `🛵 ${p.cliente_nome || 'Delivery'}` : `${nomesTipo[p.tipo] || 'Balcão'} #${p.numero}${p.cliente_nome && p.tipo !== 'balcao' ? ' — ' + p.cliente_nome : ''}`);
  const filtro = S.pdvFiltro || 'todos';
  const lista = d.andamento.filter(p => filtro === 'todos' || (filtro === 'conta' ? p.status === 'conta' : filtro === 'prontos' ? (p.prontos && !p.na_cozinha) : p.tipo === filtro));
  const estado = (p) => p.status === 'conta' ? ['💳 Pediu a conta', 'conta'] : p.aguardando ? [`${p.aguardando} p/ aprovar`, 'warn'] : (p.na_cozinha && R.cozinha) ? [`${p.na_cozinha} na cozinha`, 'warn'] : p.prontos ? [`${p.prontos} pronto(s) · pode fechar`, 'ok'] : p.tipo === 'delivery' && p.status === 'fechado' ? [`Pago · ${(DSTATUS.find(x => x.id === (p.delivery_status || 'recebido')) || {}).nome}`, 'info'] : p.qtd_itens ? ['Entregue · pode fechar', 'ok'] : ['Sem itens', ''];
  c.innerHTML = html`<div class="cab"><div><span class="mp-page-label">PDV · Caixa rápido</span><h1>Fechar contas</h1></div><span class="muted">Tudo que está em andamento, pronto para receber com um clique.</span><span class="spacer"></span>
      ${d.caixa_aberto ? '' : html`<span class="badge warn">Caixa fechado — abre ao receber</span>`}<button class="btn" id="pdv-venda">+ Venda rápida (balcão)</button></div>
    <div class="kpis">
      <div class="card kpi"><div class="r">Faturado hoje</div><div class="v num">${brl(d.faturado)}</div><div class="delta muted">${d.qtd_fechados} conta(s) fechada(s)${d.cancelados ? ` · ${d.cancelados} cancelada(s)` : ''}</div></div>
      <div class="card kpi"><div class="r">Em aberto (a receber)</div><div class="v num">${brl(d.em_aberto)}</div><div class="delta muted">${d.andamento.filter(p => p.status !== 'fechado').length} conta(s) em andamento</div></div>
      <div class="card kpi destaque"><div class="r">Faturamento previsto</div><div class="v num">${brl(d.previsto)}</div><div class="delta muted">faturado + em aberto</div></div>
      ${R.mesas ? html`<div class="card kpi"><div class="r">Pediram a conta</div><div class="v num">${d.andamento.filter(p => p.status === 'conta').length}</div><div class="delta muted">${d.andamento.filter(p => p.prontos && !p.na_cozinha && p.status !== 'fechado').length} com tudo entregue</div></div>` : ''}
    </div>
    <div class="chips" style="margin:10px 0">${[['todos', 'Todos'], ...(R.mesas ? [['conta', '💳 Pediram a conta']] : []), ...(R.cozinha ? [['prontos', 'Tudo pronto']] : []), ...(R.mesas ? [['mesa', 'Mesas']] : []), ['balcao', nomesTipo.balcao], ...(R.delivery ? [['delivery', 'Delivery']] : []), ...(PR.tipos_pedido || []).filter(t => !['mesa', 'balcao', 'delivery'].includes(t)).map(t => [t, nomesTipo[t] || t])].map(([k, n]) => html`<button class="chip ${filtro === k ? 'on' : ''}" data-f="${k}">${n}</button>`)}</div>
    <div class="pdv-grade">${lista.map(p => { const [txt, cls] = estado(p); return html`<div class="card pdv-card ${p.status === 'conta' ? 'conta' : ''}" data-p="${p.id}">
        <div class="row"><b class="pdv-nome">${rotulo(p)}</b><span class="spacer"></span><span class="small muted">${hora(p.aberto_em)} · ${minutosDesde(p.aberto_em)} min</span></div>
        <div class="row small muted">${tipoNome[p.tipo]}${p.garcom_nome ? ' · ' + p.garcom_nome : ''}${p.pessoas > 1 ? ` · ${p.pessoas} 👥` : ''} · ${p.qtd_itens + p.aguardando} item(ns)</div>
        <div class="row" style="margin-top:6px"><span class="badge ${cls}">${txt}</span><span class="spacer"></span><span class="pdv-total num">${brl(p.total)}</span></div>
        ${p.pago ? html`<div class="small muted num">já pago ${brl(p.pago)} · falta ${brl(p.total - p.pago)}</div>` : ''}
        <div class="row" style="margin-top:8px">${p.status === 'fechado' ? html`<button class="btn sm" data-abrir="${p.id}">Ver / entregar</button>` : html`<button class="btn primary" data-receber="${p.id}" ${p.aguardando ? raw('disabled title="Aprove os itens do cliente primeiro"') : ''}>💳 Receber</button><button class="btn sm" data-abrir="${p.id}">Abrir</button><button class="btn sm" data-imp="${p.id}" title="Imprimir conferência">🖨</button>`}</div></div>`; })}
      ${lista.length ? '' : html`<div class="vazio">Nada em andamento${filtro !== 'todos' ? ' com esse filtro' : ''}. ${filtro === 'todos' ? (R.mesas ? 'Abra uma mesa, uma venda no balcão ou um delivery.' : (TX.pdv_vazio || 'Quando houver contas abertas, elas aparecem aqui para receber.')) : ''}</div>`}</div>
    <h3 style="margin-top:18px">Fechadas hoje <span class="badge">${d.fechados.length}</span></h3>
    <div class="card"><table class="tab"><thead><tr><th>Hora</th><th>Conta</th><th>Pagamento</th><th class="r">Total</th><th></th></tr></thead><tbody>${d.fechados.map(p => html`<tr><td>${hora(p.fechado_em)}</td><td>${rotulo(p)}</td><td class="small muted">${p.formas || '—'}</td><td class="r num">${brl(p.total)}</td><td class="r"><button class="btn sm" data-abrir="${p.id}">Ver</button></td></tr>`)}</tbody></table>${d.fechados.length ? '' : html`<div class="vazio small">Nenhuma conta fechada hoje ainda.</div>`}</div>`;
  $('#pdv-venda').onclick = () => ir('balcao');
  c.onclick = async (e) => {
    const f = e.target.closest('[data-f]'); if (f) { S.pdvFiltro = f.dataset.f; return render(); }
    const rc = e.target.closest('[data-receber]');
    if (rc) { S.pedido = await GET('/api/pedidos/' + rc.dataset.receber); S.carrinho = []; S.voltar = 'pdv'; return abrirPagamento(); }
    const ab = e.target.closest('[data-abrir]');
    if (ab) return abrirEditor(await GET('/api/pedidos/' + ab.dataset.abrir), 'pdv');
    const im = e.target.closest('[data-imp]');
    if (im) return imprimirPedido(d.andamento.find(x => x.id === Number(im.dataset.imp)) || { id: Number(im.dataset.imp) }, 'preconta');
  };
}

// ---------------- Pedidos (histórico) ----------------
async function vendaManual() {
  const [garcons, mesas] = await Promise.all([GET('/api/cad/usuarios').catch(() => []), GET('/api/mesas').catch(() => [])]);
  const itens = [];
  const agoraLocal = (() => { const d = new Date(); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 16); })();
  let lerProd;
  const r = await modal({ titulo: '✍️ Lançar venda manual (feita no papel)', largo: true, corpo: `<div class="stack">
      <div class="muted small">Use quando o sistema estava parado (sem luz, sem PC) e a venda foi anotada no papel. Ela entra nos relatórios e no caixa atual com a data/hora que você informar.</div>
      <div class="grid3"><label class="campo">Tipo<select id="vm-tipo">${R.mesas ? '<option value="mesa">Mesa</option>' : ''}<option value="balcao">${R.mesas ? 'Balcão / comanda' : esc(nomesTipo.balcao)}</option>${R.delivery ? '<option value="delivery">Delivery</option>' : ''}</select></label>
        <label class="campo">Quando foi<input type="datetime-local" id="vm-quando" value="${agoraLocal}"></label><label class="campo"${R.pessoas === false ? ' hidden' : ''}>Pessoas<input type="number" id="vm-pes" value="1" min="1"></label></div>
      <div class="grid3"><label class="campo"${R.mesas ? '' : ' hidden'}>Mesa (se foi mesa)<select id="vm-mesa"><option value="">—</option>${mesas.map(m => `<option value="${m.id}">${esc(m.nome)}</option>`).join('')}</select></label><label class="campo">${R.profissionais ? esc(T.profissional || 'Profissional') : 'Garçom'}<select id="vm-garcom"><option value="">—</option>${garcons.filter(u => u.perfil === 'garcom').map(u => `<option value="${u.id}">${esc(u.nome)}</option>`).join('')}</select></label><label class="campo">Cliente (opcional)<input type="text" id="vm-cli"></label></div>
      <div class="rotulo">ITENS</div>
      <div class="row" style="align-items:flex-end"><div class="autocomp" style="flex:2"><label class="campo">Produto<input type="text" id="vm-prod" placeholder="Digite o nome (pode ser um item que não está cadastrado)" autocomplete="off"></label><div class="lista-ac hidden" id="vm-lista"></div></div>
        <label class="campo" style="width:80px">Qtd<input type="number" id="vm-qtd" value="1" min="1"></label><label class="campo" style="width:120px">Preço un.<input type="text" inputmode="decimal" id="vm-preco"></label><button type="button" class="btn primary" id="vm-add" style="margin-bottom:0">+ Item</button></div>
      <div class="itens" id="vm-itens"></div>
      <div class="grid3"><label class="campo">Desconto (R$)<input type="text" inputmode="decimal" id="vm-desc" value="0,00"></label><label class="campo"${R.delivery ? '' : ' hidden'}>Taxa de entrega (R$)<input type="text" inputmode="decimal" id="vm-taxa" value="0,00"></label><label class="campo">Forma de pagamento<select id="vm-forma">${S.formas.map(f => `<option value="${f.id}">${esc(f.nome)}</option>`).join('')}</select></label></div>
      <div class="row" style="font-size:20px;font-weight:800"><span>Total</span><span class="spacer"></span><span class="num" id="vm-total">R$ 0,00</span></div></div>`,
    botoes: [{ texto: 'Cancelar' }, { texto: 'Lançar venda', classe: 'primary', acao: (f) => {
      if (!itens.length) throw new Error('Adicione pelo menos um item');
      return POST('/api/pedidos/manual', { tipo: $('#vm-tipo', f).value, quando: $('#vm-quando', f).value.replace('T', ' '), pessoas: $('#vm-pes', f).value, mesa_id: $('#vm-mesa', f).value || null, garcom_id: $('#vm-garcom', f).value || null, cliente_nome: $('#vm-cli', f).value,
        itens, desconto: paraCentavos($('#vm-desc', f).value), taxa_entrega: paraCentavos($('#vm-taxa', f).value), forma_id: $('#vm-forma', f).value });
    } }],
    aoAbrir: (f) => {
      let escolhido = null;
      lerProd = campoProdutoBusca(f, { inputSel: '#vm-prod', listaSel: '#vm-lista', aoEscolher: async (e) => { escolhido = e; if (e?.id) { const p = S.cardapio.produtos.find(x => x.id === e.id); if (p) $('#vm-preco', f).value = brlCurto(p.preco_atual); } $('#vm-qtd', f).focus(); } });
      const total = () => { const t = itens.reduce((x, i) => x + i.preco * i.qtd, 0) - paraCentavos($('#vm-desc', f).value) + paraCentavos($('#vm-taxa', f).value); $('#vm-total', f).textContent = brl(Math.max(0, t)); };
      const desenharItens = () => { $('#vm-itens', f).innerHTML = itens.map((i, k) => `<div class="item"><span class="q">${i.qtd}x</span><span class="n">${esc(i.nome)}</span><span class="v num">${brl(i.preco * i.qtd)}</span><button type="button" class="x" data-rm="${k}">✕</button></div>`).join('') || '<div class="muted small">Nenhum item ainda.</div>'; total(); };
      const add = () => { const e = lerProd(); const nome = e?.nome || $('#vm-prod', f).value.trim(); if (!nome) return toast('Digite o produto', 'erro'); itens.push({ produto_id: e?.id || null, nome, qtd: Math.max(1, Number($('#vm-qtd', f).value) || 1), preco: paraCentavos($('#vm-preco', f).value) }); $('#vm-prod', f).value = ''; $('#vm-preco', f).value = ''; $('#vm-qtd', f).value = 1; escolhido = null; desenharItens(); $('#vm-prod', f).focus(); };
      $('#vm-add', f).onclick = add;
      $('#vm-preco', f).addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); e.stopPropagation(); add(); } });
      f.addEventListener('click', (e) => { const rm = e.target.closest('[data-rm]'); if (rm) { itens.splice(Number(rm.dataset.rm), 1); desenharItens(); } });
      $('#vm-desc', f).addEventListener('input', total); $('#vm-taxa', f).addEventListener('input', total);
      desenharItens();
    } });
  if (r) { toast(`Venda #${r.numero} lançada`, 'ok'); render(); }
}
async function vPedidos(c) {
  const f = S.filtroPedidos;
  const qs = new URLSearchParams({ de: f.de, ate: f.ate, ...(f.tipo ? { tipo: f.tipo } : {}), ...(f.status ? { status: f.status } : {}), ...(f.q ? { q: f.q } : {}) });
  const [lista, res] = await Promise.all([GET('/api/pedidos?' + qs), GET(`/api/pedidos/resumo?de=${f.de}&ate=${f.ate}`)]);
  const stBadge = { aberto: ['Aberto', 'warn'], conta: ['Conta', 'info'], fechado: ['Pago', 'ok'], cancelado: ['Cancelado', 'danger'] };
  const stN = (k) => res.porStatus.find(x => x.status === k)?.n || 0;
  c.innerHTML = html`<div class="cab"><h1>${T.menu_pedidos || T.pedidos || 'Pedidos'}</h1><span class="muted">${f.de === f.ate ? dataBR(f.de) : dataBR(f.de) + ' a ' + dataBR(f.ate)}</span><span class="spacer"></span>
      <button class="btn" id="manual">✍️ Lançar venda manual</button>${pode('gerente') ? html`<button class="btn" id="exp-vendas">⇩ Vendas (CSV)</button><button class="btn" id="exp-itens">⇩ Itens (CSV)</button>` : ''}</div>
    <div class="kpis">
      <div class="card kpi"><div class="r">Receita</div><div class="v num">${brl(res.receita)}</div><div class="delta muted">${res.n} venda(s) pagas</div></div>
      <div class="card kpi"><div class="r">Clientes atendidos</div><div class="v num">${res.clientes}</div><div class="delta muted">${res.por_cliente ? brl(res.por_cliente) + ' por pessoa' : '—'}</div></div>
      <div class="card kpi"><div class="r">Ticket médio</div><div class="v num">${brl(res.ticket)}</div><div class="delta muted">${res.itens} item(ns) vendidos</div></div>
      <div class="card kpi"><div class="r">Por canal</div><div class="v" style="font-size:15px;line-height:1.5">${res.porTipo.length ? res.porTipo.map(t => html`<div class="row"><span>${nomesTipo[t.tipo]}</span><span class="spacer"></span><b class="num">${brl(t.t)}</b></div>`) : '—'}</div></div>
      <div class="card kpi ${stN('aberto') + stN('conta') ? 'alerta-card' : ''}"><div class="r">Em aberto agora</div><div class="v num">${stN('aberto') + stN('conta')}</div><div class="delta muted">${stN('conta')} pediram a conta</div></div>
      <div class="card kpi ${res.cancelados.n ? 'alerta-card vermelho' : ''}"><div class="r">Cancelados</div><div class="v num">${res.cancelados.n}</div><div class="delta muted">${brl(res.cancelados.t)}${res.horaPico ? ' · pico ' + res.horaPico.h + 'h' : ''}</div></div>
    </div>
    <div class="filtros"><input type="date" id="f-de" value="${f.de}"><span>até</span><input type="date" id="f-ate" value="${f.ate}">
      <select id="f-tipo"><option value="">Todos os tipos</option>${R.mesas ? html`<option value="mesa" ${f.tipo === 'mesa' ? raw('selected') : ''}>Mesas</option>` : ''}<option value="balcao" ${f.tipo === 'balcao' ? raw('selected') : ''}>${nomesTipo.balcao}</option>${R.delivery ? html`<option value="delivery" ${f.tipo === 'delivery' ? raw('selected') : ''}>Delivery</option>` : ''}${(PR.tipos_pedido || []).filter(t => !['mesa','balcao','delivery'].includes(t)).map(t => html`<option value="${t}" ${f.tipo === t ? raw('selected') : ''}>${nomesTipo[t] || t}</option>`)}</select>
      <select id="f-st"><option value="">Qualquer status</option>${Object.entries(stBadge).map(([k, v]) => html`<option value="${k}" ${f.status === k ? raw('selected') : ''}>${v[0]}</option>`)}</select>
      <input type="text" id="f-q" placeholder="${R.mesas ? 'Nº, cliente, telefone ou mesa' : 'Nº, cliente ou telefone'}" value="${f.q}" style="min-width:220px"><button class="btn primary" id="f-ok">Buscar</button></div>
    <div class="card"><table class="tab"><thead><tr><th>Nº</th><th>Tipo</th><th>Quando</th><th>${R.mesas ? 'Cliente / mesa' : 'Cliente'}</th><th>Itens</th><th>Pagamento</th><th class="r">Total</th><th></th></tr></thead><tbody>
      ${lista.map(p => html`<tr class="click" data-p="${p.id}"><td><b>#${p.numero}</b>${p.manual ? html` <span class="badge" title="Lançamento manual">✍️</span>` : ''}</td><td>${nomesTipo[p.tipo]}${p.comanda ? ' C' + p.comanda : ''}</td><td>${dataBR(p.fechado_em || p.aberto_em).slice(0, 5)} ${hora(p.fechado_em || p.aberto_em)}</td>
        <td>${p.tipo === 'mesa' ? 'Mesa ' + p.mesa_nome + (p.garcom_nome ? ' · ' + p.garcom_nome : '') : p.cliente_nome || '—'}</td><td>${p.qtd_itens}</td><td class="small">${p.formas || '—'}</td>
        <td class="r num">${brl(p.total)}</td><td class="r"><span class="badge ${stBadge[p.status][1]}">${stBadge[p.status][0]}</span></td></tr>`)}
    </tbody></table>${lista.length ? '' : html`<div class="vazio">Nenhum pedido nesse filtro.</div>`}</div>`;
  const aplicar = () => { S.filtroPedidos = { de: $('#f-de').value, ate: $('#f-ate').value, tipo: $('#f-tipo').value, status: $('#f-st').value, q: $('#f-q').value.trim() }; render(); };
  $('#f-ok').onclick = aplicar;
  $('#manual').onclick = vendaManual;
  $('#f-q').onkeydown = (e) => { if (e.key === 'Enter') aplicar(); };
  const ev = $('#exp-vendas'); if (ev) ev.onclick = () => tentar(() => baixarArquivo(`/api/relatorios/csv?tipo=vendas&de=${f.de}&ate=${f.ate}`));
  const ei = $('#exp-itens'); if (ei) ei.onclick = () => tentar(() => baixarArquivo(`/api/relatorios/csv?tipo=itens&de=${f.de}&ate=${f.ate}`));
  c.onclick = async (e) => {
    const tr = e.target.closest('tr[data-p]'); if (!tr) return;
    const p = await GET('/api/pedidos/' + tr.dataset.p);
    if (['aberto', 'conta'].includes(p.status)) return abrirEditor(p, 'pedidos');
    modal({ titulo: `${tituloPedido(p)} — ${dataHoraBR(p.fechado_em || p.aberto_em)}`, largo: true, corpo: html`<div class="stack">
        ${p.cliente_nome ? html`<div><b>${p.cliente_nome}</b> ${p.cliente_telefone || ''}<br><span class="small muted">${p.endereco || ''}</span></div>` : ''}
        <div class="itens">${p.itens.map(i => html`<div class="item ${i.cancelado ? 'cancelado' : ''}"><span class="q">${i.qtd}x</span><span class="n">${i.nome}<small>${detalheItem(i)}${i.cancelado ? ' · Cancelado: ' + i.cancel_motivo : ''}</small></span><span class="v num">${brl((i.preco_unit + i.adicionais_total) * i.qtd)}</span></div>`)}</div>
        <div class="totais"><div class="l"><span>Subtotal</span><span class="num">${brl(p.subtotal)}</span></div>${p.servico ? html`<div class="l"><span>Serviço</span><span class="num">${brl(p.servico)}</span></div>` : ''}${p.taxa_entrega ? html`<div class="l"><span>Entrega</span><span class="num">${brl(p.taxa_entrega)}</span></div>` : ''}${p.desconto ? html`<div class="l"><span>Desconto</span><span class="num">− ${brl(p.desconto)}</span></div>` : ''}<div class="l total"><span>Total</span><span class="num">${brl(p.total)}</span></div></div>
        ${p.pagamentos.length ? html`<div class="small">${p.pagamentos.map(pg => html`<div>${pg.forma_nome}: ${brl(pg.valor)}${pg.troco ? ` (troco ${brl(pg.troco)})` : ''} · ${hora(pg.criado_em)}</div>`)}</div>` : ''}
        ${p.cancel_motivo ? html`<div class="badge danger">Cancelado: ${p.cancel_motivo}</div>` : ''}</div>`.s,
      botoes: [{ texto: window.PRODUTO_IMPRIMIR && window.PRODUTO_IMPRIMIR_ROTULO ? window.PRODUTO_IMPRIMIR_ROTULO(p) : 'Reimprimir cupom', acao: () => imprimirPedido(p, 'cupom').then(() => false) }, { texto: 'Fechar', classe: 'primary', padrao: true }] });
  };
}

// ---------------- Caixa ----------------
function abrirCaixaModal() {
  return modal({ titulo: 'Abrir caixa', corpo: '<label class="campo">Fundo de troco (dinheiro na gaveta)<input type="text" inputmode="decimal" id="cx-fundo" placeholder="0,00"></label>',
    botoes: [{ texto: 'Cancelar' }, { texto: 'Abrir caixa', classe: 'primary', padrao: true, acao: async (f) => { await POST('/api/caixa/abrir', { fundo: paraCentavos($('#cx-fundo', f).value) }); await carregarCaixa(); toast('Caixa aberto', 'ok'); return true; } }] });
}
// Mesas e contas em aberto dentro do Caixa (receber, abrir, conferência; mesa livre abre aqui mesmo)
async function painelContasCaixa() {
  if (!R.mesas) return null;
  const [mesas, d] = await Promise.all([GET('/api/mesas'), GET('/api/pdv')]);
  const naMesa = new Set(mesas.filter(m => m.pedido).map(m => m.pedido.id));
  const contas = d.andamento.filter(p => p.status !== 'fechado' && !naMesa.has(p.id));
  const ocup = mesas.filter(m => m.pedido);
  const rotulo = (p) => (window.PRODUTO_ROTULO_PDV && window.PRODUTO_ROTULO_PDV(p)) || (p.tipo === 'mesa' ? (p.comanda ? `Comanda ${p.comanda}` : `Mesa ${p.mesa_nome || ''}`) : p.tipo === 'delivery' ? `🛵 ${p.cliente_nome || 'Delivery'}` : `${nomesTipo[p.tipo] || 'Balcão'} #${p.numero}${p.cliente_nome ? ' — ' + p.cliente_nome : ''}`);
  const botoes = (p) => html`<div class="row cx-bts"><button class="btn sm primary" data-receber="${p.id}" ${p.aguardando ? raw('disabled title="Aprove os itens do cliente primeiro"') : ''}>💳 Receber</button><button class="btn sm" data-abrir="${p.id}">Abrir</button><button class="btn sm" data-imp="${p.id}" title="Imprimir conferência">🖨</button></div>`;
  const aberto = ocup.reduce((t, m) => t + (m.pedido.total || 0), 0) + contas.reduce((t, p) => t + (p.total || 0), 0);
  const h = html`<div class="card pad cx-contas" id="cx-contas">
    <div class="row wrap" style="gap:8px"><h2 style="margin:0">Mesas e comandas</h2><span class="badge">${ocup.length}/${mesas.length} mesa(s) ocupada(s)</span>${contas.length ? html`<span class="badge">${contas.length} outra(s) conta(s)</span>` : ''}<span class="badge accent num">${brl(aberto)} em aberto</span>
      <span class="spacer"></span><button class="btn sm" id="cx-venda">+ Venda no balcão</button><button class="btn sm" id="cx-mapa">Mapa completo →</button></div>
    ${mesas.length ? html`<div class="mesas cx-mesas">${mesas.map(m => { const p = m.pedido; const st = p ? (p.status === 'conta' ? 'conta' : 'ocupada') : 'livre';
      return html`<div class="mesa cx-mesa ${st === 'livre' ? '' : st} ${m.chamadas.length ? 'chamando' : ''}" data-cxmesa="${m.id}" data-cx-state="${st}" title="${p ? 'Abrir a mesa' : 'Abrir a mesa ' + m.nome}">
        <div class="row"><span class="nome">${m.nome}</span><span class="spacer"></span>${m.chamadas.length ? html`<span>${m.chamadas.map(ch => ch === 'conta' ? '💳' : '🙋')}</span>` : ''}</div>
        ${p ? html`<span class="valor num">${brl(p.total)}</span><span class="info">${minutosDesde(p.aberto_em)} min${p.garcom_nome ? ' · ' + p.garcom_nome : ''}${p.status === 'conta' ? ' · pediu a conta' : ''}</span>${botoes(p)}` : html`<span class="info">Livre</span>`}
      </div>`; })}</div>` : html`<div class="vazio small">Nenhuma mesa cadastrada. Vá em Cadastros → Mesas.</div>`}
    ${contas.length ? html`<h3 style="margin:14px 0 8px">Comandas, balcão e delivery em aberto</h3><div class="pdv-grade">${contas.map(p => html`<div class="card pdv-card ${p.status === 'conta' ? 'conta' : ''}" data-cxconta="${p.id}">
        <div class="row"><b class="pdv-nome">${rotulo(p)}</b><span class="spacer"></span><span class="small muted">${minutosDesde(p.aberto_em)} min</span></div>
        <div class="row" style="margin-top:4px"><span class="small muted">${p.qtd_itens + (p.aguardando || 0)} item(ns)${p.pago ? ' · falta ' + brl(p.total - p.pago) : ''}</span><span class="spacer"></span><span class="pdv-total num">${brl(p.total)}</span></div>${botoes(p)}</div>`)}</div>` : ''}
  </div>`;
  return { h, mesas, contas: [...contas, ...ocup.map(m => m.pedido)] };
}
async function cliqueContasCaixa(e, painel) {
  if (!painel) return false;
  const rc = e.target.closest('#cx-contas [data-receber]');
  if (rc) { S.pedido = await GET('/api/pedidos/' + rc.dataset.receber); S.carrinho = []; S.voltar = 'caixa'; abrirPagamento(); return true; }
  const ab = e.target.closest('#cx-contas [data-abrir]');
  if (ab) { abrirEditor(await GET('/api/pedidos/' + ab.dataset.abrir), 'caixa'); return true; }
  const im = e.target.closest('#cx-contas [data-imp]');
  if (im) { imprimirPedido({ id: Number(im.dataset.imp) }, 'preconta'); return true; }
  if (e.target.closest('#cx-venda')) { ir('balcao'); return true; }
  if (e.target.closest('#cx-mapa')) { ir('mesas'); return true; }
  const mc = e.target.closest('[data-cxmesa]');
  if (mc) { const m = painel.mesas.find(x => x.id === Number(mc.dataset.cxmesa)); if (!m) return true;
    if (m.pedido) abrirEditor(await GET('/api/pedidos/' + m.pedido.id), 'caixa'); else await abrirMesaLivre(m, 'caixa'); return true; }
  const cc = e.target.closest('[data-cxconta]');
  if (cc) { abrirEditor(await GET('/api/pedidos/' + cc.dataset.cxconta), 'caixa'); return true; }
  return false;
}
async function vCaixa(c) {
  await carregarCaixa();
  if (S.abaCaixa === 'fiado') return vFiado(c);
  const cx = S.caixa;
  const painel = await painelContasCaixa();
  const blocoContas = painel ? painel.h : '';
  let historico = '';
  if (pode('gerente')) {
    const lista = await GET('/api/caixas');
    historico = html`<h2 style="margin:26px 0 10px">Histórico de caixas</h2>
      <div class="card"><table class="tab"><thead><tr><th>Abertura</th><th>Fechamento</th><th>Por</th><th class="r">Vendas</th><th></th></tr></thead><tbody>
      ${lista.map(x => html`<tr class="click" data-cx="${x.id}"><td>${dataHoraBR(x.aberto_em)}</td><td>${x.fechado_em ? dataHoraBR(x.fechado_em) : html`<span class="badge ok">Aberto</span>`}</td>
        <td>${x.usuario_abertura_nome || ''}${x.usuario_fechamento_nome && x.usuario_fechamento_nome !== x.usuario_abertura_nome ? ' / ' + x.usuario_fechamento_nome : ''}</td><td class="r num">${brl(x.total_vendas)}</td><td class="r"><span class="muted">ver →</span></td></tr>`)}
      </tbody></table></div>`;
  }
  const abasCaixa = html`<div class="abas"><button class="aba on" data-abacx="caixa">Caixa</button><button class="aba" data-abacx="fiado">Fiado / a receber</button></div>`;
  if (!cx.aberto) {
    c.innerHTML = html`<div class="cab"><h1>Caixa</h1></div>${abasCaixa}<div class="card pad" style="max-width:460px"><h2>O caixa está fechado</h2><p class="muted">Abra o caixa para começar a receber pagamentos.${painel ? ' Se receber uma mesa com o caixa fechado, ele abre sozinho.' : ''}</p><button class="btn primary lg" id="abrir">Abrir caixa</button></div>${blocoContas}${historico}`;
    $('#abrir').onclick = async () => { if (await abrirCaixaModal()) render(); };
  } else {
    const r = cx.resumo;
    c.innerHTML = html`<div class="cab"><h1>Caixa aberto</h1><span class="muted">desde ${dataHoraBR(cx.caixa.aberto_em)} por ${cx.caixa.usuario_nome || ''}</span>
        <span class="spacer"></span><button class="btn" id="suprimento">+ Suprimento</button><button class="btn" id="sangria">− Sangria</button><button class="btn" id="imp-parcial">🖨 Resumo parcial</button><button class="btn primary" id="fechar">Fechar caixa</button></div>
      ${abasCaixa}
      ${blocoContas}
      <div class="kpis">
        <div class="card kpi"><div class="r">Vendas</div><div class="v num">${r.qtd_vendas}</div></div>
        <div class="card kpi"><div class="r">Total vendido</div><div class="v num">${brl(r.total_vendas)}</div></div>
        <div class="card kpi"><div class="r">Dinheiro na gaveta</div><div class="v num">${brl(r.formas.find(f => f.dinheiro)?.esperado || 0)}</div></div>
        <div class="card kpi"><div class="r">Sangrias</div><div class="v num">${brl(r.sangrias)}</div></div>
      </div>
      <div class="rel-grid">
        <div class="card"><h3>Por forma de pagamento</h3><table class="tab"><tbody>${r.formas.map(f => html`<tr><td>${f.nome}${f.dinheiro ? html` <span class="muted small">(inclui fundo e movimentos)</span>` : ''}${f.fiado ? html` <span class="muted small">(a prazo — não entra na gaveta)</span>` : ''}</td><td class="r num"><b>${brl(f.esperado)}</b></td></tr>`)}
          ${r.porTipo?.length ? html`<tr><td colspan="2" class="small muted" style="padding-top:12px">${r.porTipo.map(t => `${nomesTipo[t.tipo]}: ${t.n} (${brlCurto(t.t)})`).join(' · ')}${r.cancelados?.n ? ` · Cancelados: ${r.cancelados.n} (${brlCurto(r.cancelados.t)})` : ''}${r.gorjetas ? ` · Gorjetas: ${brlCurto(r.gorjetas)}` : ''}</td></tr>` : ''}</tbody></table></div>
        <div class="card"><h3>Movimentos</h3>${r.movimentos.length ? html`<table class="tab"><tbody>${r.movimentos.map(m => html`<tr><td>${hora(m.criado_em)}</td><td><span class="badge ${m.tipo === 'sangria' ? 'danger' : 'ok'}">${m.tipo}</span> ${m.motivo || ''} <span class="muted small">${m.usuario_nome || ''}</span></td><td class="r num">${brl(m.valor)}</td></tr>`)}</tbody></table>` : html`<div class="vazio">Nenhuma sangria ou suprimento.</div>`}</div>
      </div>${historico}`;
    const mov = (tipo) => modal({ titulo: tipo === 'sangria' ? 'Sangria (retirada)' : 'Suprimento (entrada)',
      corpo: '<div class="stack"><label class="campo">Valor<input type="text" inputmode="decimal" id="mv-v"></label><label class="campo">Motivo<input type="text" id="mv-m"></label></div>',
      botoes: [{ texto: 'Cancelar' }, { texto: 'Confirmar', classe: 'primary', padrao: true, acao: async (f) => { await POST('/api/caixa/movimento', { tipo, valor: paraCentavos($('#mv-v', f).value), motivo: $('#mv-m', f).value }); toast('Registrado', 'ok'); render(); } }] });
    $('#sangria').onclick = () => mov('sangria'); $('#suprimento').onclick = () => mov('suprimento'); $('#fechar').onclick = fecharCaixa;
    $('#imp-parcial').onclick = () => tentar(() => POST(`/api/caixas/${cx.caixa.id}/imprimir`).then(imprimirTextos), 'Enviado para impressão');
  }
  c.onclick = async (e) => {
    const ab = e.target.closest('[data-abacx]'); if (ab) { S.abaCaixa = ab.dataset.abacx; return render(); }
    if (e.target.closest('#cx-contas') && await cliqueContasCaixa(e, painel)) return;
    const tr = e.target.closest('[data-cx]'); if (!tr) return;
    const d = await GET('/api/caixas/' + tr.dataset.cx);
    modal({ titulo: 'Caixa de ' + dataBR(d.caixa.aberto_em), largo: true, corpo: tabelaFechamento(d).s,
      botoes: [{ texto: 'Imprimir', acao: () => POST(`/api/caixas/${d.caixa.id}/imprimir`).then((r) => { imprimirTextos(r); toast('Enviado', 'ok'); return false; }) }, { texto: 'Fechar', classe: 'primary' }] });
  };
}
async function vFiado(c) {
  const d = await GET('/api/fiados');
  const formasReais = S.formas.filter(f => !f.fiado);
  const escolherForma = (titulo, valorSug) => modal({ titulo, corpo: `<div class="stack"><div class="formas">${formasReais.map(f => `<button class="forma" data-f="${f.id}">${esc(f.nome)}</button>`).join('')}</div>${valorSug != null ? `<label class="campo">Valor<input type="text" inputmode="decimal" id="fi-v" value="${brlCurto(valorSug)}"></label>` : ''}</div>`,
    aoAbrir: (f, fechar) => f.addEventListener('click', (e) => { const b = e.target.closest('[data-f]'); if (b) fechar({ forma_id: Number(b.dataset.f), valor: $('#fi-v', f) ? paraCentavos($('#fi-v', f).value) : null }); }) });
  c.innerHTML = html`<div class="cab"><h1>Fiado / contas a receber</h1><span class="badge danger num">${brl(d.total)} em aberto</span></div>
    <div class="abas"><button class="aba" data-abacx="caixa">Caixa</button><button class="aba on" data-abacx="fiado">Fiado / a receber</button></div>
    <div class="rel-grid">
      <div class="card"><h3 style="padding:14px 16px 6px">Por cliente</h3>${d.porCliente.length ? html`<table class="tab"><tbody>${d.porCliente.map(cl => html`<tr><td><b>${cl.nome}</b><br><span class="small muted">${cl.telefone || ''} · ${cl.n} venda(s)</span></td><td class="r num"><b>${brl(cl.devendo)}</b></td>
        <td class="r"><button class="btn sm ok" data-quitar="${cl.nome}" data-v="${cl.devendo}">Receber tudo</button> ${cl.telefone ? html`<a class="btn sm" target="_blank" href="${linkWhatsApp(cl.telefone, `Olá ${cl.nome}! Passando para lembrar do saldo em aberto no ${S.cfg.nome_estabelecimento}: ${brl(cl.devendo)}. Obrigado!`)}">Cobrar</a>` : ''}</td></tr>`)}</tbody></table>` : html`<div class="vazio">Ninguém devendo 🎉</div>`}</div>
      <div class="card"><h3 style="padding:14px 16px 6px">Lançamentos em aberto</h3>${d.lista.length ? html`<table class="tab"><tbody>${d.lista.map(f => html`<tr><td>${dataBR(f.criado_em).slice(0, 5)} · <b>${f.nome}</b><br><span class="small muted">Pedido #${f.numero || '-'}${f.obs ? ' · ' + f.obs : ''}</span></td><td class="r num">${brl(f.valor - f.pago)}${f.pago ? html`<br><span class="small muted">de ${brl(f.valor)}</span>` : ''}</td><td class="r"><button class="btn sm" data-rec="${f.id}" data-v="${f.valor - f.pago}">Receber</button></td></tr>`)}</tbody></table>` : html`<div class="vazio">Nada em aberto.</div>`}</div>
    </div>
    <p class="muted small" style="margin-top:12px">Para vender fiado, escolha a forma "Fiado (a prazo)" na hora de receber. O recebimento entra no caixa aberto na forma escolhida (dinheiro, Pix...).</p>`;
  c.onclick = async (e) => {
    const ab = e.target.closest('[data-abacx]'); if (ab) { S.abaCaixa = ab.dataset.abacx; return render(); }
    const q = e.target.closest('[data-quitar]');
    if (q) { const r = await escolherForma(`Receber ${brl(q.dataset.v)} de ${q.dataset.quitar}`, null); if (!r) return; await tentar(() => POST('/api/fiados/0/cliente/receber-tudo', { nome: q.dataset.quitar, forma_id: r.forma_id }), 'Recebido'); return render(); }
    const rc = e.target.closest('[data-rec]');
    if (rc) { const r = await escolherForma('Receber fiado', Number(rc.dataset.v)); if (!r) return; await tentar(() => POST(`/api/fiados/${rc.dataset.rec}/receber`, { forma_id: r.forma_id, valor: r.valor }), 'Recebido'); return render(); }
  };
}
function tabelaFechamento(d) {
  const temInf = d.resumo.formas.some(f => f.informado != null);
  return html`<p class="muted">Abertura ${dataHoraBR(d.caixa.aberto_em)} · Fechamento ${d.caixa.fechado_em ? dataHoraBR(d.caixa.fechado_em) : '—'}</p>
    <table class="tab"><thead><tr><th>Forma</th><th class="r">Esperado</th>${temInf ? html`<th class="r">Informado</th><th class="r">Diferença</th>` : ''}</tr></thead><tbody>
    ${d.resumo.formas.map(f => { const dif = (f.informado ?? 0) - f.esperado; return html`<tr><td>${f.nome}</td><td class="r num">${brl(f.esperado)}</td>
      ${temInf ? html`<td class="r num">${brl(f.informado)}</td><td class="r num" style="color:${dif === 0 ? 'var(--ok)' : 'var(--danger)'}">${dif > 0 ? '+' : ''}${brl(dif)}</td>` : ''}</tr>`; })}
    </tbody></table><p><b>Total vendido:</b> ${brl(d.resumo.total_vendas)} em ${d.resumo.qtd_vendas} venda(s)${d.caixa.obs ? html`<br><b>Obs:</b> ${d.caixa.obs}` : ''}</p>`;
}
async function fecharCaixa() {
  const abertos = (await GET('/api/pedidos?ativos=1')).filter(p => p.status !== 'fechado');
  const r = S.caixa.resumo;
  const cego = S.cfg.fechamento_cego === '1' && S.usuario.perfil !== 'gerente';
  const res = await modal({ titulo: 'Fechar caixa', largo: true,
    corpo: html`${abertos.length ? html`<div class="card pad alerta-card" style="box-shadow:none;margin-bottom:12px">⚠ Ainda há <b>${abertos.length}</b> pedido(s) em aberto. Eles continuarão abertos para o próximo caixa.</div>` : ''}
      <p class="muted">Conte o dinheiro e confira os comprovantes. Digite quanto você tem de cada forma:${cego ? ' (fechamento cego: o valor esperado aparece só depois)' : ''}</p>
      <table class="tab"><thead><tr><th>Forma</th>${cego ? '' : html`<th class="r">Esperado</th>`}<th style="width:160px">Contado</th></tr></thead><tbody>
      ${r.formas.filter(f => !f.fiado).map(f => html`<tr><td>${f.nome}</td>${cego ? '' : html`<td class="r num">${brl(f.esperado)}</td>`}<td><input type="text" inputmode="decimal" data-inf="${f.forma_id}" placeholder="0,00"></td></tr>`)}</tbody></table>
      <label class="campo" style="margin-top:10px">Observação<input type="text" id="fc-obs"></label>
      <label class="check" style="margin-top:10px"><input type="checkbox" id="fc-imp" checked> Imprimir relatório de fechamento</label>`.s,
    botoes: [{ texto: 'Cancelar' }, { texto: 'Fechar caixa', classe: 'primary', acao: async (f) => { const informado = {}; $$('[data-inf]', f).forEach(i => { informado[i.dataset.inf] = paraCentavos(i.value); }); return POST('/api/caixa/fechar', { informado, obs: $('#fc-obs', f).value, imprimir: $('#fc-imp', f).checked }).then(imprimirTextos); } }] });
  if (!res) return;
  await carregarCaixa();
  await modal({ titulo: 'Caixa fechado', largo: true, corpo: tabelaFechamento(res).s, botoes: [{ texto: 'OK', classe: 'primary', padrao: true }] });
  render();
}

// ---------------- Estoque ----------------
// Campo de produto com busca: digita o nome; lista os que existem; permite criar novo.
function campoProdutoBusca(f, { inputSel, listaSel, aoEscolher, permitirNovo = true }) {
  const inp = $(inputSel, f), lista = $(listaSel, f);
  let escolhido = null;
  const buscar = adiar(async () => {
    const q = inp.value.trim();
    escolhido = null;
    if (q.length < 1) { lista.innerHTML = ''; lista.classList.add('hidden'); return; }
    const r = await GET('/api/produtos/busca?q=' + encodeURIComponent(q)).catch(() => []);
    const exato = r.find(x => x.nome.toLowerCase() === q.toLowerCase());
    lista.innerHTML = r.map(x => `<button type="button" data-id="${x.id}"><span style="flex:1">${esc(x.nome)}${x.ativo ? '' : ' <span class="muted small">(inativo)</span>'}</span><span class="muted small">${x.controla_estoque ? x.estoque + ' ' + (x.unidade || 'un') : 'sem controle'}${x.custo ? ' · custo ' + brlCurto(x.custo) : ''}</span></button>`).join('')
      + (permitirNovo && !exato ? `<button type="button" class="novo" data-novo="1">+ Criar "${esc(q)}" como produto novo</button>` : '');
    lista.classList.remove('hidden');
  }, 200);
  inp.addEventListener('input', buscar);
  inp.addEventListener('focus', () => { if (lista.innerHTML) lista.classList.remove('hidden'); });
  lista.addEventListener('mousedown', (e) => {
    const b = e.target.closest('button'); if (!b) return;
    e.preventDefault();
    if (b.dataset.novo) { escolhido = { novo: true, nome: inp.value.trim() }; }
    else { escolhido = { id: Number(b.dataset.id), nome: $('span', b).textContent.replace(/\s*\(inativo\)/, '').trim() }; inp.value = escolhido.nome; }
    lista.classList.add('hidden');
    aoEscolher?.(escolhido);
  });
  document.addEventListener('click', (e) => { if (!f.contains(e.target) || (!lista.contains(e.target) && e.target !== inp)) lista.classList.add('hidden'); });
  return () => escolhido || (inp.value.trim() ? { novo: permitirNovo, nome: inp.value.trim() } : null);
}
async function entradaMercadoria(prodFixo) {
  let ler;
  const r = await modal({ titulo: '📦 Entrada de mercadoria', largo: true, corpo: `<div class="stack">
      <div class="autocomp"><label class="campo">Produto <span class="muted" style="font-weight:400">— digite o nome; se não existir, cria na hora</span><input type="text" id="en-prod" value="${esc(prodFixo?.nome || '')}" placeholder="Ex.: Coca-Cola lata, Queijo mussarela, Farinha..." autocomplete="off"></label><div class="lista-ac hidden" id="en-lista"></div></div>
      <div id="en-novo" class="card pad hidden" style="background:var(--warn-soft);border:0;box-shadow:none"><b>Produto novo</b> — preencha o básico:
        <div class="grid3" style="margin-top:6px"><label class="campo">Categoria<input type="text" id="en-cat" placeholder="Ex.: Insumos, Bebidas"></label><label class="campo">Preço de venda (R$)<input type="text" inputmode="decimal" id="en-venda" placeholder="vazio = não vende"></label><label class="campo">Unidade<select id="en-un"><option>un</option><option>kg</option><option>g</option><option>L</option><option>ml</option><option>cx</option><option>pct</option><option>fardo</option></select></label></div>
        <label class="check" style="margin-top:6px"><input type="checkbox" id="en-nocard"> ${R.cozinha ? 'Aparece no cardápio para venda (desmarque para insumos como farinha, queijo, embalagem)' : 'Aparece para venda (desmarque para itens de uso interno, como material e embalagem)'}</label></div>
      <div class="grid3"><label class="campo">Quantidade que entrou<input type="number" step="any" id="en-qtd" min="0"></label><label class="campo">Preço de custo unitário (R$)<input type="text" inputmode="decimal" id="en-custo" placeholder="0,00"></label><label class="campo">Total da nota (calculado)<input type="text" id="en-total" readonly></label></div>
      <label class="campo">Fornecedor / nota / observação<input type="text" id="en-obs" placeholder="Ex.: Atacadão NF 1234"></label>
      <label class="campo">Avisar quando o estoque chegar em<input type="number" step="any" id="en-min" placeholder="opcional"></label></div>`,
    botoes: [{ texto: 'Cancelar' }, { texto: 'Dar entrada', classe: 'primary', acao: async (f) => {
      const esc0 = ler();
      if (!esc0) throw new Error('Informe o produto');
      const body = { qtd: $('#en-qtd', f).value, custo_unit: paraCentavos($('#en-custo', f).value), motivo: $('#en-obs', f).value, estoque_minimo: $('#en-min', f).value || 0 };
      if (esc0.id) body.produto_id = esc0.id; else { body.nome = esc0.nome; body.categoria = $('#en-cat', f).value; body.preco_venda = paraCentavos($('#en-venda', f).value); body.unidade = $('#en-un', f).value; body.no_cardapio = $('#en-nocard', f).checked; }
      return POST('/api/estoque/entrada', body);
    } }],
    aoAbrir: (f) => {
      ler = campoProdutoBusca(f, { inputSel: '#en-prod', listaSel: '#en-lista', aoEscolher: (e) => { $('#en-novo', f).classList.toggle('hidden', !e?.novo); if (e?.novo) $('#en-cat', f).focus(); else $('#en-qtd', f).focus(); } });
      if (prodFixo) { $('#en-qtd', f).focus(); }
      const calc = () => { const q = Number($('#en-qtd', f).value) || 0, c = paraCentavos($('#en-custo', f).value); $('#en-total', f).value = brlCurto(Math.round(q * c)); };
      $('#en-qtd', f).addEventListener('input', calc); $('#en-custo', f).addEventListener('input', calc);
      $('#en-prod', f).addEventListener('blur', () => { const e = ler(); $('#en-novo', f).classList.toggle('hidden', !(e && e.novo)); });
    } });
  if (r) { toast(`${r.nome}: saldo ${r.estoque}`, 'ok'); return true; }
  return false;
}
async function vEstoque(c) {
  const d = await GET('/api/estoque');
  const q = (S.filtroEstoque || '').toLowerCase();
  const prods = q ? d.produtos.filter(p => p.nome.toLowerCase().includes(q)) : d.produtos;
  const baixos = d.produtos.filter(p => p.controla_estoque && p.estoque <= p.estoque_minimo).length;
  c.innerHTML = html`<div class="cab"><h1>Estoque</h1><span class="badge ${baixos ? 'danger' : 'ok'}">${baixos ? baixos + ' abaixo do mínimo' : 'tudo ok'}</span><span class="badge num">${brl(d.valor_estoque)} em estoque (a custo)</span><span class="spacer"></span>
      <button class="btn" id="exp">⇩ CSV</button><button class="btn primary lg" id="entrada">📦 Entrada de mercadoria</button></div>
    <div class="row" style="margin-bottom:12px"><input type="text" id="est-busca" placeholder="Buscar produto..." value="${S.filtroEstoque || ''}" style="max-width:320px"><span class="muted small">Clique nos números para editar. Saldo negativo = vendeu mais do que entrou.</span></div>
    <div class="rel-grid" style="grid-template-columns: 1.6fr 1fr">
      <div class="card"><table class="tab"><thead><tr><th>Produto</th><th class="r">Saldo</th><th class="r">Mínimo</th><th class="r">Custo unit.</th><th>Última entrada</th><th></th></tr></thead><tbody>
        ${prods.map(p => { const baixo = p.controla_estoque && p.estoque <= p.estoque_minimo; return html`<tr class="${baixo ? 'estoque-baixo' : ''}">
          <td><b>${p.nome}</b> ${p.esgotado ? html`<span class="tag-esgotado">ESGOTADO</span>` : ''}<br><span class="small muted">${p.categoria_nome || 'sem categoria'} · ${p.unidade || 'un'}</span></td>
          <td class="r num"><button class="btn sm" data-aj="${p.id}" data-t="ajuste" title="Corrigir saldo (contagem)"><b>${p.estoque}</b></button></td>
          <td class="r num"><button class="btn sm ghost" data-min="${p.id}" data-v="${p.estoque_minimo}">${p.estoque_minimo}</button></td>
          <td class="r num"><button class="btn sm ghost" data-custo="${p.id}" data-v="${p.custo}">${p.custo ? brlCurto(p.custo) : '—'}</button></td>
          <td class="small muted">${p.ultima_entrada ? dataBR(p.ultima_entrada).slice(0, 5) + (p.ultimo_custo ? ' · ' + brlCurto(p.ultimo_custo) : '') : '—'}</td>
          <td class="r" style="white-space:nowrap"><button class="btn sm" data-ent="${p.id}">+ Entrada</button> <button class="btn sm ghost" data-aj="${p.id}" data-t="perda">− Perda</button> <button class="btn sm ghost" data-esg="${p.id}" data-v="${p.esgotado ? 0 : 1}">${p.esgotado ? 'Disponível' : 'Esgotado'}</button></td></tr>`; })}
        </tbody></table>${prods.length ? '' : html`<div class="vazio">${q ? 'Nada encontrado.' : 'Nenhum produto com controle de estoque. Clique em "Entrada de mercadoria" para começar: pode digitar qualquer produto, inclusive insumos (farinha, queijo, embalagens).'}</div>`}</div>
      <div class="card"><h3 style="padding:14px 16px 6px">Últimas movimentações</h3><table class="tab"><tbody>${d.movimentos.slice(0, 40).map(m => html`<tr><td class="small">${dataBR(m.criado_em).slice(0, 5)} ${hora(m.criado_em)}</td><td>${m.produto_nome}<br><span class="small muted">${m.tipo}${m.custo_unit ? ' a ' + brlCurto(m.custo_unit) : ''}${m.motivo ? ' · ' + m.motivo : ''}${m.usuario_nome ? ' · ' + m.usuario_nome : ''}</span></td><td class="r num" style="color:${m.qtd > 0 ? 'var(--ok)' : 'var(--danger)'}">${m.qtd > 0 ? '+' : ''}${m.qtd}</td></tr>`)}</tbody></table></div>
    </div>`;
  $('#entrada').onclick = async () => { if (await entradaMercadoria()) render(); };
  $('#exp').onclick = () => { const csv = '\ufeff' + ['Produto;Saldo;Mínimo;Custo;Unidade'].concat(d.produtos.map(p => `"${p.nome}";${p.estoque};${p.estoque_minimo};${brlCurto(p.custo)};${p.unidade || 'un'}`)).join('\r\n'); const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' })); a.download = 'estoque.csv'; a.click(); };
  $('#est-busca').oninput = adiar((e) => { S.filtroEstoque = e.target.value; render().then(() => { const i = $('#est-busca'); if (i) { i.focus(); i.setSelectionRange(i.value.length, i.value.length); } }); }, 250);
  const ajuste = async (id, tipo) => {
    const p = d.produtos.find(x => x.id === id);
    const r = await modal({ titulo: tipo === 'perda' ? 'Registrar perda / quebra' : 'Contagem (corrigir saldo)', corpo: `<div class="stack"><div><b>${esc(p.nome)}</b> — saldo atual ${p.estoque} ${esc(p.unidade || 'un')}</div>
      <div class="grid2"><label class="campo">${tipo === 'ajuste' ? 'Saldo contado' : 'Quantidade perdida'}<input type="number" step="any" id="aj-q" ${tipo === 'ajuste' ? `value="${p.estoque}"` : ''}></label><label class="campo">Motivo<input type="text" id="aj-m" placeholder="${tipo === 'perda' ? 'Ex.: vencido, quebrou' : 'Ex.: contagem semanal'}"></label></div></div>`,
      botoes: [{ texto: 'Cancelar' }, { texto: 'Confirmar', classe: 'primary', padrao: true, acao: (f) => POST(`/api/estoque/${id}/ajuste`, { tipo, qtd: $('#aj-q', f).value, motivo: $('#aj-m', f).value }) }] });
    if (r) { toast('Estoque atualizado', 'ok'); render(); }
  };
  c.onclick = async (e) => {
    const en = e.target.closest('[data-ent]'); if (en) { if (await entradaMercadoria(d.produtos.find(x => x.id === Number(en.dataset.ent)))) render(); return; }
    const a = e.target.closest('[data-aj]'); if (a) return ajuste(Number(a.dataset.aj), a.dataset.t);
    const mn = e.target.closest('[data-min]'); if (mn) { const v = await pedirTexto('Estoque mínimo', 'Avisar quando o saldo chegar em', mn.dataset.v, 'number'); if (v === null) return; await tentar(() => PATCH(`/api/estoque/${mn.dataset.min}`, { estoque_minimo: v })); return render(); }
    const cu = e.target.closest('[data-custo]'); if (cu) { const v = await pedirTexto('Custo unitário', 'Quanto você paga por unidade (R$)', cu.dataset.v ? brlCurto(cu.dataset.v) : ''); if (v === null) return; await tentar(() => PATCH(`/api/estoque/${cu.dataset.custo}`, { custo: paraCentavos(v) })); return render(); }
    const es = e.target.closest('[data-esg]'); if (es) { await tentar(() => POST(`/api/produtos/${es.dataset.esg}/esgotado`, { esgotado: es.dataset.v === '1' })); render(); }
  };
}

// ---------------- Relatórios ----------------
async function vRelatorios(c) {
  if (S.abaRel === 'perguntas' && window.vPerguntas) return vPerguntas(c);
  const { de, ate } = S.rel;
  const r = await GET(`/api/relatorios?de=${de}&ate=${ate}`);
  const ticket = r.resumo.vendas ? Math.round(r.resumo.total / r.resumo.vendas) : 0;
  const barras = (lista, rotulo, max = Math.max(1, ...lista.map(x => x.total || 0))) => lista.length ? html`<div class="barras" style="padding:6px 16px 16px">
    ${lista.map(x => html`<div class="barra"><span>${rotulo(x)}</span><div><div class="b" style="width:${Math.round((x.total || 0) / max * 100)}%"></div></div><span class="num" style="text-align:right">${brl(x.total)}</span></div>`)}</div>` : html`<div class="vazio">Sem dados</div>`;
  const tabela = (cols, linhas) => linhas.length ? html`<table class="tab"><thead><tr>${cols.map(([t, rr]) => html`<th class="${rr ? 'r' : ''}">${t}</th>`)}</tr></thead>
    <tbody>${linhas.map(l => html`<tr>${l.map((v, i) => html`<td class="${cols[i][1] ? 'r num' : ''}">${v}</td>`)}</tr>`)}</tbody></table>` : html`<div class="vazio">Sem dados</div>`;
  const atalho = (d) => { const x = new Date(); x.setDate(x.getDate() - d); return hojeISO(x); };
  const mesIni = hojeISO(new Date(new Date().getFullYear(), new Date().getMonth(), 1));
  const temCusto = r.resumo.itens_com_custo > 0;
  c.innerHTML = html`<div class="cab"><h1>Relatórios</h1><span class="spacer"></span>
      <div class="row wrap"><button class="btn sm" data-at="0">Hoje</button><button class="btn sm" data-at="1">Ontem</button><button class="btn sm" data-at="7">7 dias</button><button class="btn sm" data-at="30">30 dias</button><button class="btn sm" data-at="mes">Este mês</button>
        <input type="date" id="r-de" value="${de}" style="width:auto"><span>até</span><input type="date" id="r-ate" value="${ate}" style="width:auto"><button class="btn primary" id="r-ok">Ver</button>
        <button class="btn" id="r-csv" title="Exportar para Excel">⇩ CSV</button></div></div>
    ${raw(window.abasRelatorios ? abasRelatorios() : '')}
    <div class="kpis">
      <div class="card kpi"><div class="r">Faturamento</div><div class="v num">${brl(r.resumo.total)}</div></div>
      <div class="card kpi"><div class="r">Vendas</div><div class="v num">${r.resumo.vendas}</div></div>
      <div class="card kpi"><div class="r">Ticket médio</div><div class="v num">${brl(ticket)}</div></div>
      ${temCusto ? html`<div class="card kpi"><div class="r">Lucro bruto (estimado)</div><div class="v num" style="color:var(--ok)">${brl(r.resumo.lucro)}</div><div class="delta muted">${r.resumo.subtotal ? Math.round(r.resumo.lucro / r.resumo.subtotal * 100) : 0}% de margem · custo ${brl(r.resumo.custo)}</div></div>` : html`<div class="card kpi"><div class="r">Lucro</div><div class="v muted" style="font-size:14px">Cadastre o custo dos produtos para ver a margem</div></div>`}
      <div class="card kpi"><div class="r">Serviço</div><div class="v num">${brl(r.resumo.servico)}</div></div>
      <div class="card kpi"><div class="r">Taxas de entrega</div><div class="v num">${brl(r.resumo.taxas)}</div></div>
      <div class="card kpi"><div class="r">Descontos</div><div class="v num">${brl(r.resumo.descontos)}</div></div>
      ${r.tempoPreparo?.media ? html`<div class="card kpi"><div class="r">Tempo de preparo</div><div class="v num">${r.tempoPreparo.media} min</div><div class="delta muted">máx. ${r.tempoPreparo.maximo} min</div></div>` : ''}
      ${r.tempoMesa?.media ? html`<div class="card kpi"><div class="r">Tempo médio de mesa</div><div class="v num">${r.tempoMesa.media} min</div><div class="delta muted">${r.tempoMesa.n} mesa(s)</div></div>` : ''}
    </div>
    <div class="rel-grid">
      <div class="card"><h3>Por dia</h3>${barras(r.porDia, x => dataBR(x.dia).slice(0, 5))}</div>
      <div class="card"><h3>Por horário</h3>${barras(r.porHora, x => x.hora + 'h')}</div>
      <div class="card"><h3>Por dia da semana</h3>${barras(r.porDiaSemana, x => DIAS_SEMANA[x.dia])}</div>
      <div class="card"><h3>Por tipo</h3>${tabela([['Tipo'], ['Vendas', 1], ['Total', 1], ['Ticket', 1]], r.porTipo.map(x => [nomesTipo[x.tipo], x.vendas, brl(x.total), brl(Math.round(x.total / x.vendas))]))}</div>
      <div class="card"><h3>Formas de pagamento</h3>${tabela([['Forma'], ['Qtd', 1], ['Total', 1]], r.porForma.map(x => [x.nome, x.qtd, brl(x.total)]))}</div>
      <div class="card"><h3>Produtos mais vendidos</h3>${tabela([['Produto'], ['Qtd', 1], ['Total', 1], ...(temCusto ? [['Lucro', 1]] : [])], r.porProduto.slice(0, 30).map(x => [x.nome, x.qtd, brl(x.total), ...(temCusto ? [brl(x.total - x.custo)] : [])]))}</div>
      <div class="card"><h3>Por categoria</h3>${tabela([['Categoria'], ['Qtd', 1], ['Total', 1]], r.porCategoria.map(x => [x.nome, x.qtd, brl(x.total)]))}</div>
      ${R.garcom ? '' : raw('<!--')}<div class="card"><h3>Garçons: comissão, serviço e gorjetas</h3>${tabela([['Garçom'], ['Mesas', 1], ['Vendido', 1], ['Serviço', 1], ['Gorjetas', 1], ['Comissão', 1]], r.porGarcom.map(x => [x.nome, x.mesas, brl(x.subtotal), brl(x.servico), brl(x.gorjeta), `${brl(x.comissao_valor)} (${x.comissao}%)`]))}</div>${R.garcom ? '' : raw('-->')}
      ${(r.fiado.vendido || r.fiado.recebido) ? html`<div class="card"><h3>Fiado</h3>${tabela([['Item'], ['Valor', 1]], [['Vendido a prazo no período', brl(r.fiado.vendido)], ['Recebido no período', brl(r.fiado.recebido)], ['Ainda em aberto (destas vendas)', brl(r.fiado.aberto)]])}</div>` : ''}
      ${R.delivery ? '' : raw('<!--')}<div class="card"><h3>Entregadores</h3>${tabela([['Entregador'], ['Entregas', 1], ['Taxas', 1]], r.porMotoboy.map(x => [x.nome, x.entregas, brl(x.taxas)]))}</div>
      <div class="card"><h3>Bairros (delivery)</h3>${tabela([['Bairro'], ['Entregas', 1], ['Total', 1]], r.porBairro.map(x => [x.nome, x.entregas, brl(x.total)]))}</div>${R.delivery ? '' : raw('-->')}
      <div class="card"><h3>Melhores clientes</h3>${tabela([['Cliente'], [R.mesas ? 'Pedidos' : (T.pedidos || 'Vendas'), 1], ['Total', 1]], r.melhoresClientes.map(x => [`${x.nome || ''} ${x.telefone || ''}`, x.pedidos, brl(x.total)]))}</div>
      <div class="card" style="grid-column:1/-1"><h3>Itens cancelados</h3>${tabela([['Quando'], ['Pedido'], ['Item'], ['Motivo'], ['Autorizado por'], ['Valor', 1]],
        r.cancelados.map(x => [dataBR(x.cancel_em).slice(0, 5) + ' ' + hora(x.cancel_em), x.tipo === 'mesa' ? 'Mesa ' + x.mesa_nome : '#' + x.numero, x.qtd + 'x ' + x.nome, x.cancel_motivo, x.autorizado_por || '', brl(x.total)]))}</div>
    </div>`;
  $('#r-ok').onclick = () => { S.rel = { de: $('#r-de').value, ate: $('#r-ate').value }; render(); };
  $('#r-csv').onclick = () => tentar(() => baixarArquivo(`/api/relatorios/csv?tipo=produtos&de=${de}&ate=${ate}`));
  c.onclick = (e) => {
    const b = e.target.closest('[data-at]'); if (!b) return;
    const a = b.dataset.at;
    if (a === 'mes') S.rel = { de: mesIni, ate: hojeISO() }; else if (a === '1') S.rel = { de: atalho(1), ate: atalho(1) }; else S.rel = { de: atalho(Number(a)), ate: hojeISO() };
    render();
  };
}

// ---------------- Cadastros ----------------
const TIPOS_IMP = [['nenhuma', 'Não imprimir'], ['windows', 'Impressora instalada no Windows (USB ou rede)'], ['rede', 'Térmica de rede (pelo IP)'], ['navegador', 'Pela janela de impressão do navegador'], ['compartilhada', 'Térmica USB compartilhada (nome do compartilhamento)']];
function camposImpressora(imp = {}, pref = 'imp') {
  return `<div class="stack" data-impressora="${pref}">
    <label class="campo">Tipo de impressora<select data-k="tipo">${TIPOS_IMP.filter(([v]) => (!S.nuvem || v === 'nenhuma' || v === 'navegador') && (v !== 'compartilhada' || imp.tipo === 'compartilhada')).map(([v, t]) => `<option value="${v}" ${imp.tipo === v ? 'selected' : ''}>${t}</option>`).join('')}</select></label>
    <div class="grid2" data-se="rede"><label class="campo">IP da impressora<input type="text" data-k="ip" value="${esc(imp.ip || '')}" placeholder="192.168.0.50"></label><label class="campo">Porta<input type="text" data-k="porta" value="${esc(imp.porta || '9100')}"></label></div>
    <div class="stack" data-se="windows" style="gap:6px"><label class="campo">Impressora<select data-k="nome" data-lista-imp><option value="${esc(imp.nome || '')}">${esc(imp.nome || 'Carregando as impressoras do Windows…')}</option></select></label>
      <div class="row wrap" style="gap:8px;align-items:center"><button type="button" class="btn sm ghost" data-atualizar-imp>Atualizar lista</button><span class="small muted" data-info-imp>Mostra as impressoras instaladas neste computador (Configurações do Windows › Impressoras). Não precisa compartilhar.</span></div></div>
    <div class="small" data-se="navegador" data-info-nav style="line-height:1.45"></div>
    <label class="campo" data-se="compartilhada">Nome do compartilhamento<input type="text" data-k="compartilhamento" value="${esc(imp.compartilhamento || '')}" placeholder="TERMICA"></label>
    <label class="campo" data-se="windows rede compartilhada navegador">Largura do papel<select data-k="largura"><option value="48" ${Number(imp.largura) !== 32 ? 'selected' : ''}>80 mm</option><option value="32" ${Number(imp.largura) === 32 ? 'selected' : ''}>58 mm</option></select></label>
    <div data-se="windows rede compartilhada navegador"><button type="button" class="btn sm" data-testar>Imprimir teste</button></div></div>`;
}
function ligarImpressora(f, pref = 'imp') {
  const box = $(`[data-impressora="${pref}"]`, f);
  const ler = () => Object.fromEntries($$('[data-k]', box).map(i => [i.dataset.k, i.dataset.k === 'largura' ? Number(i.value) : i.value]));
  const sel = $('[data-lista-imp]', box), info = $('[data-info-imp]', box);
  let carregou = false;
  const carregarLista = async () => {
    carregou = true; const atual = sel.value; info.textContent = 'Procurando as impressoras do Windows…';
    const r = await GET('/api/impressoras').catch(e => ({ lista: [], erro: e.message }));
    const lista = r.lista || [];
    const nomes = lista.map(p => p.nome);
    sel.innerHTML = (atual && !nomes.includes(atual) ? `<option value="${esc(atual)}" selected>${esc(atual)} (não encontrada agora)</option>` : (!atual ? '<option value="">Escolha a impressora</option>' : ''))
      + lista.map(p => `<option value="${esc(p.nome)}" ${p.nome === atual ? 'selected' : ''}>${esc(p.nome)}${p.padrao ? ' (padrão)' : ''}${p.offline ? ' — desligada/offline' : ''}${p.virtual ? ' — não imprime papel' : ''}</option>`).join('');
    info.textContent = r.erro ? r.erro : !r.windows ? 'A lista só aparece no programa instalado no computador com Windows.'
      : !lista.length ? 'Nenhuma impressora instalada no Windows. Instale o driver da impressora (veja o manual dela) e clique em "Atualizar lista".'
      : `${lista.filter(p => !p.virtual).length} impressora(s) encontrada(s). Se a sua não aparece, instale o driver dela no Windows e clique em "Atualizar lista".`;
  };
  $('[data-atualizar-imp]', box).onclick = () => carregarLista();
  // "pelo navegador": cada impressão abre a janela de impressão, onde se escolhe a impressora
  const infoNav = $('[data-info-nav]', box); let navCarregou = false;
  const carregarNav = async () => {
    navCarregou = true;
    const est = estacaoImpressao();
    let h = 'Cada impressão abre a janela de impressão: escolha a impressora e clique em <b>Imprimir</b>. Para sair direto, sem janela, use <b>"Impressora instalada no Windows"</b>.';
    if (!est) h += `<div class="pin-erro" style="margin-top:6px">Este aparelho não é a estação de impressão: os pedidos "pelo navegador" saem no computador marcado em Configurações › Geral ("Este computador é a estação de impressão"). O "Imprimir teste" sai aqui mesmo.</div>`;
    infoNav.innerHTML = h;
  };
  const atualizar = () => { const t = $('[data-k=tipo]', box).value; $$('[data-se]', box).forEach(el => el.classList.toggle('hidden', !el.dataset.se.split(' ').includes(t))); if (t === 'windows' && !carregou) carregarLista(); if (t === 'navegador' && !navCarregou) carregarNav(); };
  $('[data-k=tipo]', box).addEventListener('change', atualizar);
  $('[data-testar]', box).onclick = () => tentar(async () => { const r = await POST('/api/impressora/teste', { impressora: ler() }); if (r.local && r.texto) imprimirTexto(r.texto); }, 'Teste enviado');
  atualizar();
  return ler;
}
const opts = (lista, atual, vazio) => (vazio ? `<option value="">${vazio}</option>` : '') + lista.map(x => `<option value="${x.id}" ${x.id === atual ? 'selected' : ''}>${esc(x.nome)}</option>`).join('');
const DIAS_CHK = (sel) => DIAS_SEMANA.map((d, i) => `<label class="check" style="display:inline-flex;margin-right:8px"><input type="checkbox" name="promo_dia" value="${i}" ${String(sel || '').split(',').includes(String(i)) ? 'checked' : ''}> ${d}</label>`).join('');
const DIAS_DISP_CHK = (sel) => DIAS_SEMANA.map((d, i) => `<label class="check" style="display:inline-flex;margin-right:8px"><input type="checkbox" data-dia-disp value="${i}" ${String(sel || '').split(',').includes(String(i)) ? 'checked' : ''}> ${d}</label>`).join('');
function diasTexto(dias) { const l = String(dias || '').split(',').filter(Boolean).map(Number); if (!l.length || l.length === 7) return ''; return 'só ' + l.map(i => DIAS_SEMANA[i]).join(', '); }
function escolhaDoProduto(p) { try { const e = typeof p.escolhas === 'string' ? JSON.parse(p.escolhas || 'null') : p.escolhas; return e && Array.isArray(e.opcoes) ? e : null; } catch { return null; } }
const CAD = {
  produtos: { nome: 'Produtos', colunas: [['', (p, d) => fotoHtml(p.foto, p.nome, 'thumb', d.categorias.find(c => c.id === p.categoria_id)?.nome)], ['Código', p => p.codigo || ''], ['Nome', p => p.nome + (p.esgotado ? ' ⊘' : '') + (p.destaque ? ' ★' : '') + (p.dias ? ' 📅 ' + diasTexto(p.dias) : '')], ['Categoria', (p, d) => d.categorias.find(c => c.id === p.categoria_id)?.nome || '—'], ['Setor', (p, d) => d.setores.find(c => c.id === p.setor_id)?.nome || '—'], ['Preço', p => p.tamanhos?.length ? p.tamanhos.map(t => `${t.nome} ${brlCurto(t.preco)}`).join(' / ') : brl(p.preco) + (p.promo_preco ? ` (promo ${brlCurto(p.promo_preco)})` : ''), 1], ['Estoque', p => p.controla_estoque ? p.estoque : '', 1]],
    form: (p, d) => `<div class="stack">
      <div class="foto-form"><div class="prev" id="foto-prev">${p.foto ? `<img src="${esc(p.foto)}" alt="">` : 'Sem foto'}</div>
        <div class="stack" style="gap:6px"><div class="row wrap"><button type="button" class="btn sm" id="foto-escolher">📷 Escolher / tirar foto</button><button type="button" class="btn sm" id="foto-galeria">Imagem do catálogo</button><button type="button" class="btn sm ghost danger ${p.foto ? '' : 'hidden'}" id="foto-remover">Remover</button></div>
        <input type="file" id="foto-arq" accept="image/*" class="hidden"><input type="hidden" name="foto" value="${esc(p.foto || '')}">
        <div class="muted small">${R.cardapio_qr ? 'A foto aparece no caixa, no celular do garçom e no cardápio digital do cliente.' : 'A foto aparece no caixa, na hora de lançar.'} Pode tirar pelo celular do gerente abrindo o caixa nele.</div></div></div>
      <div class="grid3"><label class="campo">Código<input type="text" name="codigo" value="${esc(p.codigo || '')}"></label><label class="campo" style="grid-column:span 2">Nome<input type="text" name="nome" value="${esc(p.nome || '')}"></label></div>
      <div class="grid3"><label class="campo">Preço (R$)<input type="text" inputmode="decimal" name="preco" data-dinheiro value="${p.preco != null ? brlCurto(p.preco) : ''}"></label>
        <label class="campo">Custo (R$) <span class="muted" style="font-weight:400">p/ lucro</span><input type="text" inputmode="decimal" name="custo" data-dinheiro value="${p.custo ? brlCurto(p.custo) : ''}"></label>
        <label class="campo">Categoria<select name="categoria_id" data-num>${opts(d.categorias, p.categoria_id, '— sem categoria —')}</select></label></div>
      ${(R.agenda || R.pacotes) ? `<div class="grid3"><label class="campo">Tipo<select name="tipo" id="f-tipo">${[['produto', 'Produto (venda)'], ['servico', 'Serviço'], ...(R.pacotes ? [['pacote', 'Pacote de sessões']] : [])].map(([v, t]) => `<option value="${v}" ${(p.tipo || 'produto') === v ? 'selected' : ''}>${t}</option>`).join('')}</select></label>
        <label class="campo">Duração (min) <span class="muted" style="font-weight:400">se for serviço</span><input type="number" name="duracao_min" data-num value="${p.duracao_min ?? 30}"></label>
        ${R.pacotes ? `<label class="campo">Pacote: nº de sessões<input type="number" name="pacote_sessoes" data-num value="${p.pacote_sessoes ?? 0}"></label></div>
        <div class="grid2"><label class="campo">Pacote: qual serviço cobre<select name="pacote_servico_id" data-num>${opts((d.servicos || []), p.pacote_servico_id, '— escolha o serviço —')}</select></label><label class="campo">Pacote: validade (dias)<input type="number" name="pacote_validade_dias" data-num value="${p.pacote_validade_dias ?? 90}"></label></div>` : '</div>'}` : ''}
      <div class="grid2">${R.setores ? `<label class="campo">Setor de preparo<select name="setor_id" data-num>${opts(d.setores, p.setor_id, '— não envia —')}</select></label>` : ''}
        <label class="campo">Descrição ${R.cardapio_qr ? '(aparece no cardápio digital)' : ''}<input type="text" name="descricao" value="${esc(p.descricao || '')}"></label></div>
      <div class="row wrap"><label class="check"><input type="checkbox" name="destaque" ${p.destaque ? 'checked' : ''}> ★ Destaque</label><label class="check"><input type="checkbox" name="esgotado" ${p.esgotado ? 'checked' : ''}> ${R.agenda ? 'Indisponível no momento' : 'Esgotado no momento'}</label></div>
      <details ${p.tamanhos?.length ? 'open' : ''}><summary style="cursor:pointer;font-weight:600">Tamanhos (P/M/G, 300ml/500ml...)</summary>
        <div class="muted small" style="margin:6px 0">Se preencher, o preço de cada tamanho substitui o preço acima.</div>
        <div id="tam-lista" class="stack" style="gap:6px">${(p.tamanhos || []).map(t => `<div class="row tam-linha"><input type="text" placeholder="Nome (ex.: G)" value="${esc(t.nome)}" data-tn style="max-width:160px"><input type="text" inputmode="decimal" placeholder="Preço" value="${brlCurto(t.preco)}" data-tp style="max-width:140px"><button type="button" class="btn sm ghost danger" data-tam-rm>✕</button></div>`).join('')}</div>
        <button type="button" class="btn sm" id="tam-add" style="margin-top:6px">+ Tamanho</button></details>
      <details ${p.promo_preco ? 'open' : ''}><summary style="cursor:pointer;font-weight:600">Promoção / happy hour</summary>
        <div class="grid3" style="margin-top:6px"><label class="campo">Preço promocional<input type="text" inputmode="decimal" name="promo_preco" data-dinheiro value="${p.promo_preco ? brlCurto(p.promo_preco) : ''}"></label>
          <label class="campo">Das<input type="time" name="promo_de" value="${esc(p.promo_de || '')}"></label><label class="campo">Até<input type="time" name="promo_ate" value="${esc(p.promo_ate || '')}"></label></div>
        <div style="margin-top:6px">${DIAS_CHK(p.promo_dias)}</div><div class="muted small">Sem dias marcados = todos os dias. Sem horário = o dia inteiro.</div></details>
      <details ${escolhaDoProduto(p) ? 'open' : ''}><summary style="cursor:pointer;font-weight:600">Escolha obrigatória (sabor, ponto da carne...)</summary>
        <div class="muted small" style="margin:6px 0">O cliente e o garçom precisam escolher uma opção antes de adicionar. Ex.: Suco natural → Sabor: Laranja, Maracujá, Abacaxi. A escolha vai para a cozinha junto com o item.</div>
        <div class="grid3"><label class="campo">Nome da escolha<input type="text" id="esc-titulo" maxlength="30" value="${esc(escolhaDoProduto(p)?.titulo || 'Sabor')}" placeholder="Sabor"></label>
          <div class="campo" style="grid-column:span 2"><span>Opções (digite e aperte Enter)</span><div id="chips-esc"></div></div></div></details>
      <details ${p.dias ? 'open' : ''}><summary style="cursor:pointer;font-weight:600">Dias em que aparece no cardápio${p.dias ? ' — ' + diasTexto(p.dias) : ''}</summary>
        <div class="muted small" style="margin:6px 0">Para pratos do dia (ex.: feijoada só no sábado). Nos outros dias ele some do cardápio da mesa, do cardápio online e do totem. Sem dia marcado = aparece todos os dias.</div>
        <div>${DIAS_DISP_CHK(p.dias)}</div></details>
      <details ${p.controla_estoque ? 'open' : ''}><summary style="cursor:pointer;font-weight:600">Controle de estoque</summary>
        <div class="grid3" style="margin-top:6px"><label class="check" style="margin-top:22px"><input type="checkbox" name="controla_estoque" ${p.controla_estoque ? 'checked' : ''}> Controlar estoque</label>
          ${!p.id ? `<label class="campo">Saldo inicial<input type="number" step="any" name="estoque" data-num value="0"></label>` : `<div class="campo"><span>Saldo atual</span><b style="padding:9px 0">${p.estoque}</b></div>`}
          <label class="campo">Avisar quando ≤<input type="number" step="any" name="estoque_minimo" data-num value="${p.estoque_minimo ?? 0}"></label></div>
        <div class="muted small">Cada venda baixa o estoque automaticamente. Entradas e contagem ficam na tela Estoque.</div></details></div>` },
  categorias: { nome: 'Categorias', colunas: [['Ordem', x => x.ordem], ['Nome', x => x.nome + (x.meio_a_meio ? ' (meio a meio)' : '')], ['Obs. rápidas', x => x.obs_rapidas || '']],
    form: (x) => `<div class="stack"><div class="grid3"><label class="campo" style="grid-column:span 2">Nome<input type="text" name="nome" value="${esc(x.nome || '')}"></label><label class="campo">Ordem<input type="number" name="ordem" data-num value="${x.ordem ?? 0}"></label></div>
      <div class="campo"><span>Observações rápidas (digite e aperte Enter — viram bolinhas que ${R.garcom ? 'o garçom toca na hora do pedido' : 'aparecem na hora de lançar o item'})</span><div id="chips-obs"></div><input type="hidden" name="obs_rapidas" value="${esc(x.obs_rapidas || '')}"></div>
      ${R.pizza !== false && R.mesas ? html`<label class="check"><input type="checkbox" name="meio_a_meio" ${x.meio_a_meio ? 'checked' : ''}> Permite meio a meio (pizzas: dois sabores no mesmo item)</label>` : ''}
      ${R.cardapio_qr ? html`<label class="check"><input type="checkbox" name="no_cardapio" ${x.no_cardapio !== 0 ? 'checked' : ''}> Aparece no cardápio digital do cliente</label>` : ''}</div>` },
  adicionais: { nome: 'Adicionais', colunas: [['Nome', x => x.nome], ['Vale para', (x, d) => d.categorias.find(c => c.id === x.categoria_id)?.nome || 'Todos os produtos'], ['Preço', x => brl(x.preco), 1]],
    form: (x, d) => `<div class="stack"><label class="campo">Nome<input type="text" name="nome" value="${esc(x.nome || '')}"></label><div class="grid2"><label class="campo">Preço (R$)<input type="text" inputmode="decimal" name="preco" data-dinheiro value="${x.preco != null ? brlCurto(x.preco) : ''}"></label><label class="campo">Aparece em<select name="categoria_id" data-num>${opts(d.categorias, x.categoria_id, 'Todos os produtos')}</select></label></div></div>` },
  setores: { nome: 'Setores e impressoras', colunas: [['Nome', x => x.nome], ['Impressora', x => (TIPOS_IMP.find(t => t[0] === x.impressora?.tipo) || TIPOS_IMP[0])[1] + (x.impressora?.ip ? ' — ' + x.impressora.ip : '') + (x.impressora?.tipo === 'windows' && x.impressora?.nome ? ' — ' + x.impressora.nome : '')]],
    form: (x) => `<div class="stack"><label class="campo">Nome do setor<input type="text" name="nome" value="${esc(x.nome || '')}" placeholder="Cozinha, Bar, Pizzaria..."></label>${camposImpressora(x.impressora || {})}<p class="muted small">O pedido sempre aparece na tela da cozinha. A impressora é opcional.</p></div>` },
  mesas: { nome: 'Mesas', colunas: [['Ordem', x => x.ordem], ['Nome', x => x.nome], ['Área', x => x.area || ''], ['Lugares', x => x.lugares, 1]], lote: true,
    form: (x) => `<div class="grid2"><label class="campo">Nome / número<input type="text" name="nome" value="${esc(x.nome || '')}"></label><label class="campo">Área (Salão, Varanda...)<input type="text" name="area" value="${esc(x.area || '')}"></label><label class="campo">Ordem<input type="number" name="ordem" data-num value="${x.ordem ?? 0}"></label><label class="campo">Lugares<input type="number" name="lugares" data-num value="${x.lugares ?? 4}"></label></div>` },
  usuarios: { nome: R.profissionais ? (T.equipe || 'Equipe') : 'Usuários', colunas: [['Nome', x => raw((R.profissionais && x.cor ? `<span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:${esc(x.cor)};margin-right:6px"></span>` : '') + esc(x.nome))], ['Perfil', x => ({ gerente: 'Gerente', caixa: 'Caixa', garcom: (window.PRODUTO?.termos?.profissional) || 'Garçom', entregador: 'Entregador' })[x.perfil]], ['PIN', () => '••••'], ['Comissão', x => x.comissao + '%' + (R.comissao ? ' / ' + (x.comissao_produto || 0) + '%' : ''), 1]],
    form: (x) => `<div class="stack"><div class="grid2"><label class="campo">Nome<input type="text" name="nome" value="${esc(x.nome || '')}"></label>${R.profissionais ? `<label class="campo">Telefone / WhatsApp<input type="text" name="telefone" value="${esc(x.telefone || '')}"></label>` : ''}</div><div class="grid3">
      <label class="campo">Perfil<select name="perfil">${[['garcom', (window.PRODUTO?.termos?.profissional) || 'Garçom'], ['caixa', 'Caixa / recepção'], ['gerente', 'Gerente'], ...(R.delivery ? [['entregador', 'Entregador (app de entregas)']] : [])].map(([v, t]) => `<option value="${v}" ${x.perfil === v ? 'selected' : ''}>${t}</option>`).join('')}</select></label>
      <label class="campo">PIN (4 a 6 números)<input type="password" inputmode="numeric" name="pin" value="${esc(x.pin || '')}" autocomplete="new-password"></label>
      <label class="campo">Comissão ${R.comissao ? 'em serviços' : ''} %<input type="number" step="0.5" name="comissao" data-num value="${x.comissao ?? 0}"></label></div>
      ${R.profissionais ? `<div class="grid3">${R.comissao ? `<label class="campo">Comissão em produtos %<input type="number" step="0.5" name="comissao_produto" data-num value="${x.comissao_produto ?? 0}"></label>` : ''}<label class="campo">Cor na agenda<input type="color" name="cor" value="${esc(x.cor || '#3f5bd9')}" style="height:42px;padding:4px"></label><div style="padding-top:24px"><label class="check"><input type="checkbox" name="agenda" ${x.agenda == null || x.agenda ? 'checked' : ''}> Aparece na agenda</label></div></div>` : ''}
      <p class="muted small">${R.delivery ? 'Entregador: só o app de entregas no celular (/entregador). ' : ''}${R.garcom ? 'Garçom: usa a comanda no celular. Caixa: mesas, balcão, delivery e caixa.' : `${(window.PRODUTO?.termos?.profissional) || 'Profissional'}: vê a agenda e lança o que fez. Caixa / recepção: agenda, vendas e caixa.`} Gerente: tudo, inclusive cancelamentos, descontos e relatórios.</p></div>` },
  formas_pagamento: { nome: 'Formas de pagamento', colunas: [['Nome', x => x.nome], ['Tipo', x => (x.dinheiro ? 'Dinheiro (troco)' : x.fiado ? 'Fiado / a prazo' : 'Outros')]],
    form: (x) => `<div class="stack"><label class="campo">Nome<input type="text" name="nome" value="${esc(x.nome || '')}"></label><label class="check"><input type="checkbox" name="dinheiro" ${x.dinheiro ? 'checked' : ''}> É dinheiro (permite troco e entra na conferência da gaveta)</label><label class="check"><input type="checkbox" name="fiado" ${x.fiado ? 'checked' : ''}> É fiado / a prazo (gera conta a receber, não entra na gaveta)</label></div>` },
  bairros: { nome: 'Bairros e taxas', colunas: [['Bairro', x => x.nome], ['Taxa de entrega', x => brl(x.taxa), 1]],
    form: (x) => `<div class="grid2"><label class="campo">Bairro<input type="text" name="nome" value="${esc(x.nome || '')}"></label><label class="campo">Taxa (R$)<input type="text" inputmode="decimal" name="taxa" data-dinheiro value="${x.taxa != null ? brlCurto(x.taxa) : ''}"></label></div>` },
  motoboys: { nome: 'Entregadores', colunas: [['Nome', x => x.nome], ['Telefone', x => x.telefone || '']],
    form: (x) => `<div class="grid2"><label class="campo">Nome<input type="text" name="nome" value="${esc(x.nome || '')}"></label><label class="campo">Telefone<input type="tel" name="telefone" value="${esc(x.telefone || '')}"></label></div>` },
  clientes: { nome: 'Clientes', semAtivo: true, colunas: [['Nome', x => raw(`<button class="btn sm ghost" data-ficha="${x.id}" style="padding:2px 6px" title="Abrir ficha">👤</button> ` + esc(x.nome || ''))], ['Telefone', x => x.telefone || ''], ...(window.PRODUTO?.recursos?.delivery ? [['Endereço', x => [x.endereco, x.numero].filter(Boolean).join(', ')], ['Bairro', (x, d) => d.bairros.find(b => b.id === x.bairro_id)?.nome || '']] : [['Aniversário', x => x.nascimento ? dataBR(x.nascimento) : ''], ['Observação', x => x.obs || '']]), ['Compras', x => x.pedidos || 0, 1]],
    form: (x, d) => `<div class="stack"><div class="grid2"><label class="campo">Nome<input type="text" name="nome" value="${esc(x.nome || '')}"></label><label class="campo">Telefone / WhatsApp<input type="tel" name="telefone" value="${esc(x.telefone || '')}"></label></div>
      ${!window.PRODUTO?.recursos?.delivery ? `<div class="grid3"><label class="campo">Aniversário<input type="date" name="nascimento" value="${esc(x.nascimento || '')}"></label><label class="campo">E-mail<input type="email" name="email" value="${esc(x.email || '')}"></label><label class="campo">Etiquetas (separe por ;)<input type="text" name="tags" value="${esc(x.tags || '')}" placeholder="VIP; alergia a tinta"></label></div>` : ''}
      <div class="grid3"><label class="campo" style="grid-column:span 2">Endereço<input type="text" name="endereco" value="${esc(x.endereco || '')}"></label><label class="campo">Número<input type="text" name="numero" value="${esc(x.numero || '')}"></label></div>
      <div class="grid3"><label class="campo">Complemento<input type="text" name="complemento" value="${esc(x.complemento || '')}"></label><label class="campo">Bairro<select name="bairro_id" data-num>${opts(d.bairros, x.bairro_id, '—')}</select></label><label class="campo">Referência<input type="text" name="referencia" value="${esc(x.referencia || '')}"></label></div>
      <label class="campo">Observação (aparece ao abrir o cliente)<input type="text" name="obs" value="${esc(x.obs || '')}" placeholder="Ex.: sempre pede sem cebola; portão azul"></label></div>` },
};

// Abas de cadastro conforme o produto
{
  const FLAG = { setores: 'setores', mesas: 'mesas', adicionais: 'adicionais', bairros: 'delivery', motoboys: 'delivery' };
  for (const [k, f] of Object.entries(FLAG)) if (R[f] === false) delete CAD[k];
  if (T.produtos && CAD.produtos) CAD.produtos.nome = T.produtos;
  if (T.equipe && CAD.usuarios) CAD.usuarios.nome = T.equipe;
  for (const [k, v] of Object.entries(window.PRODUTO_CAD || {})) { if (v.estender && CAD[k]) { const { estender, ...resto } = v; Object.assign(CAD[k], resto); continue; } if (v.antes && CAD[v.antes]) { const novo = {}; for (const [k2, v2] of Object.entries(CAD)) { if (k2 === v.antes) novo[k] = v; novo[k2] = v2; } for (const k2 of Object.keys(CAD)) delete CAD[k2]; Object.assign(CAD, novo); } else CAD[k] = v; }
}
function abasCadastros(aba) {
  return html`<div class="abas">${Object.entries(CAD).map(([k, v]) => html`<button class="aba ${k === aba ? 'on' : ''}" data-aba="${k}">${v.nome}</button>`)}</div>`;
}
async function editarMesa(m, areas) {
  const novo = !m.id;
  const r = await modal({ titulo: novo ? 'Nova mesa' : 'Mesa ' + m.nome, corpo: `<div class="stack">
      <div class="grid2"><label class="campo">Nome / número<input type="text" id="m-nome" value="${esc(m.nome || '')}"></label>
        <label class="campo">Ambiente<input type="text" id="m-area" list="m-areas" value="${esc(m.area || areas[0] || 'Salão')}"><datalist id="m-areas">${areas.map(a => `<option value="${esc(a)}">`).join('')}</datalist></label></div>
      <div class="row"><span class="campo" style="flex-direction:row;align-items:center;gap:10px">Cadeiras / lugares <span class="stepper"><button type="button" data-st="-1">−</button><b id="m-lug">${m.lugares ?? 4}</b><button type="button" data-st="1">+</button></span></span><span class="spacer"></span>
        ${novo ? '' : `<label class="check"><input type="checkbox" id="m-ativo" ${m.ativo !== 0 ? 'checked' : ''}> Ativa</label>`}</div></div>`,
    botoes: [{ texto: 'Cancelar' }, ...(novo ? [] : [{ texto: 'Plaquinha QR', acao: () => { window.open('/plaquinhas', '_blank'); return false; } }]), { texto: 'Salvar', classe: 'primary', padrao: true, acao: (f) => ({ nome: $('#m-nome', f).value.trim(), area: $('#m-area', f).value.trim(), lugares: Number($('#m-lug', f).textContent), ativo: novo ? 1 : ($('#m-ativo', f).checked ? 1 : 0) }) }],
    aoAbrir: (f) => f.addEventListener('click', (e) => { const b = e.target.closest('[data-st]'); if (b) { const el = $('#m-lug', f); el.textContent = Math.max(1, Number(el.textContent) + Number(b.dataset.st)); } }) });
  if (!r) return false;
  if (!r.nome) { toast('Informe o nome', 'erro'); return false; }
  await tentar(() => novo ? POST('/api/cad/mesas', { ...r, ordem: 999 }) : PUT(`/api/cad/mesas/${m.id}`, r), 'Salvo');
  return true;
}
async function adicionarMesasEmLote(area) {
  const r = await modal({ titulo: `Adicionar mesas em "${area}"`, corpo: `<div class="grid3"><label class="campo">Quantas mesas<input type="number" id="l-qtd" value="4" min="1"></label><label class="campo">Começar no número<input type="number" id="l-ini" value="1" min="1"></label><label class="campo">Cadeiras em cada<input type="number" id="l-lug" value="4" min="1"></label></div><label class="campo" style="margin-top:8px">Prefixo (opcional, ex.: V para V1, V2...)<input type="text" id="l-pre" maxlength="3"></label>`,
    botoes: [{ texto: 'Cancelar' }, { texto: 'Criar', classe: 'primary', padrao: true, acao: (f) => POST('/api/mesas/gerar', { areas: [{ nome: area, qtd: $('#l-qtd', f).value, inicio: $('#l-ini', f).value, lugares: $('#l-lug', f).value, prefixo: $('#l-pre', f).value }] }) }] });
  if (r) toast(`${r.criadas} mesa(s) criada(s)`, 'ok');
  return !!r;
}
async function vCadMesas(c) {
  const mesas = await GET('/api/cad/mesas?todos=1');
  const areas = [...new Set(mesas.map(m => m.area || 'Salão'))];
  if (!areas.length) areas.push('Salão');
  c.innerHTML = html`<div class="cab"><h1>Cadastros</h1></div>${abasCadastros('mesas')}
    <div class="row wrap" style="margin-bottom:12px"><span class="muted">Clique numa mesa para mudar nome, ambiente ou cadeiras. Mesas inativas ficam apagadas.</span><span class="spacer"></span><button class="btn" id="nova-area">+ Novo ambiente</button><button class="btn" id="qr">🖨 Plaquinhas QR</button><button class="btn primary" id="assist">Refazer pelo assistente</button></div>
    <div class="areas-editor">${areas.map(a => { const ms = mesas.filter(m => (m.area || 'Salão') === a); return html`<div class="card area-bloco"><h3>${a} <span class="badge">${ms.filter(m => m.ativo).length} mesas · ${ms.filter(m => m.ativo).reduce((x, m) => x + (m.lugares || 0), 0)} lugares</span><span class="spacer"></span><button class="btn sm" data-lote="${a}">+ Várias</button><button class="btn sm ghost" data-renomear="${a}">Renomear</button></h3>
      <div class="mesas-mini">${ms.map(m => html`<div class="mesa-mini ${m.ativo ? '' : 'inativa'}" data-m="${m.id}"><div class="n">${m.nome}</div><div class="c">🪑 ${m.lugares}</div></div>`)}<div class="mesa-mini add" data-add="${a}">+ mesa</div></div></div>`; })}</div>`;
  $('#nova-area').onclick = async () => { const n = await pedirTexto('Novo ambiente', 'Nome (ex.: Varanda, Área externa, 2º andar)'); if (!n) return; if (await adicionarMesasEmLote(n)) render(); };
  $('#qr').onclick = () => window.open('/plaquinhas', '_blank');
  $('#assist').onclick = () => { S.passoAssist = 1; ir('assistente'); };
  c.onclick = async (e) => {
    const ab = e.target.closest('[data-aba]'); if (ab) { S.abaCad = ab.dataset.aba; return render(); }
    const m = e.target.closest('[data-m]'); if (m) { if (await editarMesa(mesas.find(x => x.id === Number(m.dataset.m)), areas)) render(); return; }
    const ad = e.target.closest('[data-add]'); if (ad) { if (await editarMesa({ area: ad.dataset.add, lugares: 4, nome: String(mesas.length + 1).padStart(2, '0') }, areas)) render(); return; }
    const lt = e.target.closest('[data-lote]'); if (lt) { if (await adicionarMesasEmLote(lt.dataset.lote)) render(); return; }
    const rn = e.target.closest('[data-renomear]');
    if (rn) { const n = await pedirTexto('Renomear ambiente', 'Novo nome', rn.dataset.renomear); if (!n || n === rn.dataset.renomear) return; for (const m of mesas.filter(x => (x.area || 'Salão') === rn.dataset.renomear)) await PUT(`/api/cad/mesas/${m.id}`, { area: n }).catch(() => {}); toast('Renomeado', 'ok'); render(); }
  };
}
const PRESETS_SETOR = ['Cozinha', 'Bar', 'Pizzaria', 'Chapa', 'Sobremesas', 'Copa', 'Churrasqueira', 'Sushi'];
async function vCadSetores(c) {
  const [setores, produtos] = await Promise.all([GET('/api/cad/setores?todos=1'), GET('/api/cad/produtos')]);
  const nomeImp = (i) => (TIPOS_IMP.find(t => t[0] === i?.tipo) || TIPOS_IMP[0])[1] + (i?.ip ? ' — ' + i.ip : '') + (i?.compartilhamento ? ' — ' + i.compartilhamento : '');
  c.innerHTML = html`<div class="cab"><h1>Cadastros</h1></div>${abasCadastros('setores')}
    <div class="row wrap" style="margin-bottom:12px"><span class="muted">Cada setor é um lugar de preparo. O pedido aparece na tela da cozinha do setor e, se tiver impressora, imprime lá.</span><span class="spacer"></span><button class="btn primary" id="novo-setor">+ Novo setor</button></div>
    <div class="setores-grid">${setores.map(st => { const n = produtos.filter(p => p.setor_id === st.id).length; return html`<div class="card setor-card ${st.ativo ? '' : 'inativo'}"><h3>${st.nome}${st.ativo ? '' : html` <span class="badge">inativo</span>`}<span class="spacer"></span><span class="badge">${n} produto(s)</span></h3>
      <div class="small" style="margin:8px 0">🖨 ${nomeImp(st.impressora)}</div>
      <div class="row wrap"><button class="btn sm" data-ed="${st.id}">Editar / impressora</button>${st.impressora?.tipo && st.impressora.tipo !== 'nenhuma' ? html`<button class="btn sm" data-teste="${st.id}">Imprimir teste</button>` : ''}<a class="btn sm" href="/cozinha" target="_blank">Abrir tela</a></div></div>`; })}
    ${setores.length ? '' : html`<div class="vazio">Nenhum setor. Crie "Cozinha" para começar.</div>`}</div>
    <div class="muted small" style="margin-top:14px">Sem setor, o produto não vai para a cozinha (ex.: bebida servida direto pelo garçom).</div>`;
  const editar = async (st) => {
    const novo = !st.id;
    let lerImp;
    const r = await modal({ titulo: novo ? 'Novo setor' : 'Setor ' + st.nome, corpo: `<div class="stack">${novo ? `<div class="rotulo">SUGESTÕES</div><div class="chips">${PRESETS_SETOR.filter(p => !setores.some(x => x.nome.toLowerCase() === p.toLowerCase())).map(p => `<button type="button" class="chip" data-pre="${p}">${p}</button>`).join('')}</div>` : ''}
        <label class="campo">Nome do setor<input type="text" id="st-nome" value="${esc(st.nome || '')}"></label>${camposImpressora(st.impressora || {})}
        ${novo ? '' : '<label class="check"><input type="checkbox" id="st-ativo" ' + (st.ativo ? 'checked' : '') + '> Ativo</label>'}</div>`,
      botoes: [{ texto: 'Cancelar' }, { texto: 'Salvar', classe: 'primary', padrao: true, acao: (f) => ({ nome: $('#st-nome', f).value.trim(), impressora: lerImp(), ativo: novo ? 1 : ($('#st-ativo', f).checked ? 1 : 0) }) }],
      aoAbrir: (f) => { lerImp = ligarImpressora(f); f.addEventListener('click', (e) => { const b = e.target.closest('[data-pre]'); if (b) $('#st-nome', f).value = b.dataset.pre; }); } });
    if (!r) return;
    if (!r.nome) return toast('Informe o nome', 'erro');
    await tentar(() => novo ? POST('/api/cad/setores', r) : PUT(`/api/cad/setores/${st.id}`, r), 'Salvo');
    render();
  };
  $('#novo-setor').onclick = () => editar({});
  c.onclick = async (e) => {
    const ab = e.target.closest('[data-aba]'); if (ab) { S.abaCad = ab.dataset.aba; return render(); }
    const ed = e.target.closest('[data-ed]'); if (ed) return editar(setores.find(x => x.id === Number(ed.dataset.ed)));
    const ts = e.target.closest('[data-teste]'); if (ts) { const st = setores.find(x => x.id === Number(ts.dataset.teste)); tentar(() => POST('/api/impressora/teste', { impressora: st.impressora }), 'Teste enviado'); }
  };
}
async function vCadastros(c) {
  let aba = S.abaCad;
  if (!CAD[aba]) aba = S.abaCad = Object.keys(CAD)[0];
  if (aba === 'mesas') return vCadMesas(c);
  if (aba === 'setores') return vCadSetores(c);
  const def = CAD[aba];
  const [lista, categorias, setores, bairros] = await Promise.all([GET(`/api/cad/${aba}?todos=1`), GET('/api/cad/categorias'), GET('/api/cad/setores'), GET('/api/cad/bairros')]);
  const d = { categorias, setores, bairros };
  for (const t of (def.extras || [])) d[t] = await GET(`/api/cad/${t}`).catch(() => []);
  if (aba === 'produtos') d.servicos = lista.filter(x => x.tipo === 'servico' && x.ativo);
  const filtro = S.filtroCad || '';
  const nInativos = def.semAtivo ? 0 : lista.filter(x => x.ativo === 0).length;
  const vis = (filtro ? lista.filter(x => JSON.stringify(x).toLowerCase().includes(filtro.toLowerCase())) : lista).filter(x => S.verInativos || x.ativo !== 0 || def.semAtivo);
  c.innerHTML = html`<div class="cab"><h1>Cadastros</h1></div>
    <div class="abas">${Object.entries(CAD).map(([k, v]) => html`<button class="aba ${k === aba ? 'on' : ''}" data-aba="${k}">${v.nome}</button>`)}</div>
    <div class="row" style="margin-bottom:12px"><input type="text" id="cad-filtro" placeholder="Filtrar..." value="${filtro}" style="max-width:320px">${nInativos ? html`<button class="btn ghost sm" id="cad-inativos" style="margin-left:8px">${S.verInativos ? 'Esconder inativos' : `Mostrar inativos (${nInativos})`}</button>` : ''}<span class="spacer"></span>
      ${aba === 'produtos' ? html`${R.catalogo_bebidas ? html`<button class="btn" id="cad-catalogo">🥤 Catálogo de bebidas</button>` : ''}<button class="btn" id="cad-import">⇧ Importar de planilha</button>` : ''}${raw(def.botoes ? def.botoes(d) : '')}${aba === 'mesas' ? html`<button class="btn" id="cad-lote">Criar várias mesas</button><button class="btn" id="cad-qr">🖨 Plaquinhas QR</button>` : ''}<button class="btn primary" id="cad-novo">+ Novo</button></div>
    <div class="card"><table class="tab"><thead><tr>${def.colunas.map(([t, , r]) => html`<th class="${r ? 'r' : ''}">${t}</th>`)}${def.semAtivo ? '' : html`<th>Situação</th>`}</tr></thead><tbody>
      ${vis.map(x => html`<tr class="click ${x.ativo === 0 ? 'inativo' : ''}" data-id="${x.id}">${def.colunas.map(([, fn, r]) => html`<td class="${r ? 'r num' : ''}">${fn(x, d)}</td>`)}
        ${def.semAtivo ? '' : html`<td>${x.ativo ? html`<span class="badge ok">Ativo</span>` : html`<span class="badge">Inativo</span>`}</td>`}</tr>`)}
    </tbody></table>${vis.length ? '' : html`<div class="vazio">Nada cadastrado ainda.</div>`}</div>`;
  $('#cad-filtro').oninput = adiar((e) => { S.filtroCad = e.target.value; render().then(() => { const i = $('#cad-filtro'); if (i) { i.focus(); i.setSelectionRange(i.value.length, i.value.length); } }); }, 250);
  $('#cad-novo').onclick = () => editarCadastro(aba, {}, d);
  if ($('#cad-inativos')) $('#cad-inativos').onclick = () => { S.verInativos = !S.verInativos; render(); };
  if (def.aoMontar) def.aoMontar(c, d, lista);
  c.querySelector('tbody')?.addEventListener('click', (e) => { const b = e.target.closest('[data-ficha]'); if (b) { e.stopPropagation(); fichaCliente(Number(b.dataset.ficha)); } }, true);
  const on = (id, fn) => { const b = $('#' + id); if (b) b.onclick = fn; };
  on('cad-lote', async () => {
    const v = await modal({ titulo: 'Criar várias mesas', corpo: '<div class="grid3"><label class="campo">De<input type="number" id="l-de" value="1"></label><label class="campo">Até<input type="number" id="l-ate" value="10"></label><label class="campo">Área<input type="text" id="l-area" placeholder="Salão"></label></div>',
      botoes: [{ texto: 'Cancelar' }, { texto: 'Criar', classe: 'primary', padrao: true, acao: (f) => ({ de: Number($('#l-de', f).value), ate: Number($('#l-ate', f).value), area: $('#l-area', f).value }) }] });
    if (!v) return;
    for (let i = v.de; i <= Math.min(v.ate, v.de + 200); i++) await POST('/api/cad/mesas', { nome: String(i).padStart(2, '0'), ordem: i, ativo: 1, area: v.area, lugares: 4 }).catch(() => {});
    toast('Mesas criadas', 'ok'); render();
  });
  on('cad-qr', () => window.open('/plaquinhas', '_blank'));
  on('cad-catalogo', catalogoBebidas);
  on('cad-import', () => modal({ titulo: 'Importar produtos de planilha', largo: true, corpo: `<div class="stack"><p class="muted small">No Excel, monte as colunas <b>código; nome; categoria; setor; preço; custo</b>, copie as linhas e cole aqui. Categorias e setores que não existirem são criados. Produtos com o mesmo código são atualizados.</p>
      <textarea id="imp-txt" rows="10" placeholder="1;X-Burguer;Lanches;Cozinha;18,00;7,00&#10;2;Coca lata;Bebidas;Bar;6;3"></textarea></div>`,
    botoes: [{ texto: 'Cancelar' }, { texto: 'Importar', classe: 'primary', acao: async (f) => { const r = await POST('/api/cad/produtos/importar', { texto: $('#imp-txt', f).value }); toast(`${r.criados} criado(s), ${r.atualizados} atualizado(s)${r.erros.length ? ', ' + r.erros.length + ' erro(s)' : ''}`, r.erros.length ? 'alerta' : 'ok'); render(); } }] }));
  c.onclick = (e) => {
    const a = e.target.closest('[data-aba]'); if (a) { S.abaCad = a.dataset.aba; S.filtroCad = ''; return render(); }
    const tr = e.target.closest('tr[data-id]'); if (tr) editarCadastro(aba, lista.find(x => x.id === Number(tr.dataset.id)), d);
  };
}
async function editarCadastro(aba, item, d, semRender = false) {
  const def = CAD[aba];
  const novo = !item.id;
  let lerImp, fotoPendente;
  await modal({
    titulo: (novo ? 'Novo — ' : 'Editar — ') + def.nome, largo: ['produtos', 'clientes', 'categorias'].includes(aba),
    corpo: `<form id="cad-form" onsubmit="return false">${def.form(item, d)}${def.semAtivo ? '' : `<label class="check" style="margin-top:14px"><input type="checkbox" name="ativo" ${novo || item.ativo ? 'checked' : ''}> Ativo</label>`}</form>`,
    botoes: [...(!novo && ['produtos', 'categorias', 'adicionais'].includes(aba) && pode('gerente') ? [{ texto: 'Excluir', classe: 'danger', acao: async () => {
      const oQue = aba === 'categorias' ? `a categoria "${item.nome}"` : aba === 'adicionais' ? `o adicional "${item.nome}"` : `"${item.nome}"`;
      if (!(await confirmar(`Excluir ${oQue}?`, 'Sai das listas e do cardápio. As vendas antigas continuam no histórico.', 'Excluir', 'danger solid'))) return false;
      const r = await DEL(`/api/cad/${aba}/${item.id}`);
      toast(r.historico ? 'Excluído. Ele aparece só nas vendas antigas.' : 'Excluído', 'ok');
      if (['produtos', 'categorias', 'adicionais'].includes(aba)) S.cardapio = await GET('/api/cardapio');
      if (!semRender) render();
    } }] : []), { texto: 'Cancelar' }, { texto: 'Salvar', classe: 'primary', padrao: true, acao: async (f) => {
      const dados = {};
      for (const el of $$('#cad-form [name]', f)) {
        if (el.name === 'promo_dia') continue;
        if (el.type === 'checkbox') dados[el.name] = el.checked ? 1 : 0;
        else if ('dinheiro' in el.dataset) dados[el.name] = paraCentavos(el.value);
        else if ('num' in el.dataset) dados[el.name] = el.value === '' ? null : Number(el.value);
        else dados[el.name] = el.value.trim();
      }
      if (aba === 'categorias' && f._chipsObs) dados.obs_rapidas = f._chipsObs.get().join(';');
      if (aba === 'produtos') {
        dados.promo_dias = $$('input[name=promo_dia]:checked', f).map(c => c.value).join(',');
        const diasD = $$('input[data-dia-disp]:checked', f).map(c => c.value);
        dados.dias = diasD.length === 7 ? '' : diasD.join(',');
        const opcEsc = f._chipsEsc ? f._chipsEsc.get() : [];
        dados.escolhas = opcEsc.length ? { titulo: ($('#esc-titulo', f).value || '').trim() || 'Sabor', opcoes: opcEsc } : '';
        dados.tamanhos = $$('.tam-linha', f).map(l => ({ nome: $('[data-tn]', l).value.trim(), preco: paraCentavos($('[data-tp]', l).value) })).filter(t => t.nome);
      }
      if (lerImp) dados.impressora = lerImp();
      if (aba === 'usuarios' && !novo && !dados.pin) delete dados.pin;
      if (aba === 'produtos' && fotoPendente !== undefined && dados.foto && dados.foto.startsWith('/fotos/')) delete dados.foto;
      const salvo = await (novo ? POST(`/api/cad/${aba}`, dados) : PUT(`/api/cad/${aba}/${item.id}`, dados));
      if (aba === 'produtos' && fotoPendente) await POST(`/api/produtos/${salvo.id}/foto`, { dados: fotoPendente });
      toast('Salvo', 'ok');
      if (['produtos', 'categorias', 'adicionais'].includes(aba)) S.cardapio = await GET('/api/cardapio');
      if (!semRender) render();
    } }],
    aoAbrir: (f) => {
      if (aba === 'setores') lerImp = ligarImpressora(f);
      if (aba === 'categorias') { const hid = $('input[name=obs_rapidas]', f); const ch = montarChips($('#chips-obs', f), hid.value.split(';').map(v => v.trim()).filter(Boolean), 'Ex.: Sem cebola'); f._chipsObs = ch; }
      if (aba === 'produtos') {
        f._chipsEsc = montarChips($('#chips-esc', f), escolhaDoProduto(item)?.opcoes || [], 'Ex.: Laranja');
        const prev = $('#foto-prev', f), hid = $('input[name=foto]', f), arq = $('#foto-arq', f);
        const mostrar = (src) => { prev.innerHTML = src ? `<img src="${esc(src)}" alt="">` : 'Sem foto'; $('#foto-remover', f).classList.toggle('hidden', !src); };
        $('#foto-escolher', f).onclick = () => arq.click();
        arq.onchange = async () => {
          const file = arq.files[0]; if (!file) return;
          try { fotoPendente = await redimensionarImagem(file); mostrar(fotoPendente); hid.value = item.foto || ''; } catch (e) { toast(e.message, 'erro'); }
        };
        $('#foto-remover', f).onclick = async () => {
          fotoPendente = null; hid.value = ''; mostrar('');
          if (item.id && item.foto) await DEL(`/api/produtos/${item.id}/foto`).catch(() => {});
        };
        $('#foto-galeria', f).onclick = async () => {
          const { imagens } = await GET('/api/catalogo');
          const sel = await modal({ titulo: 'Imagens do catálogo', largo: true, corpo: `<div class="galeria">${imagens.map(i => `<button type="button" data-img="${esc(i)}"><img src="${esc(i)}" alt=""></button>`).join('')}</div>`,
            aoAbrir: (f2, fechar) => f2.addEventListener('click', (e) => { const b = e.target.closest('[data-img]'); if (b) fechar(b.dataset.img); }) });
          if (sel) { fotoPendente = null; hid.value = sel; mostrar(sel); }
        };
        const add = () => { const div = document.createElement('div'); div.className = 'row tam-linha'; div.innerHTML = '<input type="text" placeholder="Nome (ex.: G)" data-tn style="max-width:160px"><input type="text" inputmode="decimal" placeholder="Preço" data-tp style="max-width:140px"><button type="button" class="btn sm ghost danger" data-tam-rm>✕</button>'; $('#tam-lista', f).appendChild(div); $('[data-tn]', div).focus(); };
        $('#tam-add', f).onclick = add;
        f.addEventListener('click', (e) => { const b = e.target.closest('[data-tam-rm]'); if (b) b.closest('.tam-linha').remove(); });
      }
    },
  });
}

// ---------------- Catálogo de bebidas ----------------
async function catalogoBebidas() {
  const { itens } = await GET('/api/catalogo');
  const cats = [...new Set(itens.map(i => i.cat))];
  const sel = new Map();
  const r = await modal({ titulo: 'Catálogo de bebidas — adicione com um clique', largo: true,
    corpo: `<div class="stack"><div class="muted small">Marque as bebidas que você vende e ajuste o preço se quiser. As que já existem no seu cadastro aparecem apagadas. As imagens são ilustrações por tipo; depois você pode trocar pela foto real do produto.</div>
      <div class="row wrap"><button type="button" class="btn sm" id="ct-todos">Marcar todas</button><button type="button" class="btn sm" id="ct-nenhum">Desmarcar</button><label class="check" style="margin-left:auto"><input type="checkbox" id="ct-estoque"> Ligar controle de estoque nelas</label></div>
      ${cats.map(c => `<div><div class="rotulo">${esc(c)}</div><div class="catalogo">${itens.filter(i => i.cat === c).map(i => `<label class="cat-item ${i.ja_tem ? 'tem' : ''}" data-ch="${i.chave}"><img src="${esc(i.foto)}" alt=""><span class="n">${esc(i.nome)}${i.ja_tem ? '<br><span class="muted">já cadastrado</span>' : ''}</span><input type="text" inputmode="decimal" value="${brlCurto(i.preco)}" data-preco title="Preço"></label>`).join('')}</div></div>`).join('')}</div>`,
    botoes: [{ texto: 'Cancelar' }, { texto: 'Adicionar selecionadas', classe: 'primary', acao: async (f) => {
      const lista = [...sel.keys()].map(ch => ({ chave: ch, preco: paraCentavos($(`[data-ch="${ch}"] [data-preco]`, f).value), estoque: $('#ct-estoque', f).checked }));
      if (!lista.length) throw new Error('Marque pelo menos uma bebida');
      return POST('/api/catalogo/adicionar', { itens: lista });
    } }],
    aoAbrir: (f) => {
      const marcar = (el, on) => { const ch = el.dataset.ch; if (on) sel.set(ch, 1); else sel.delete(ch); el.classList.toggle('on', on); };
      f.addEventListener('click', (e) => {
        if (e.target.matches('[data-preco]')) return;
        const it = e.target.closest('[data-ch]'); if (it) { e.preventDefault(); marcar(it, !sel.has(it.dataset.ch)); }
      });
      $('#ct-todos', f).onclick = () => $$('[data-ch]:not(.tem)', f).forEach(el => marcar(el, true));
      $('#ct-nenhum', f).onclick = () => $$('[data-ch]', f).forEach(el => marcar(el, false));
    } });
  if (r) { toast(`${r.criados} bebida(s) adicionada(s)`, 'ok'); S.cardapio = await GET('/api/cardapio'); render(); }
}

// Card do período de teste / renovação na tela Início
// 3.9.1: depois da compra, lembra os adicionais escolhidos na página de compra e ainda não ativados
function cardAdicionaisPendentes() {
  const l = S.licenca; const a = l && l.adicionais;
  if (!a || !a.pendentes || !a.pendentes.length || l.estado !== 'ativada' || !pode('gerente')) return '';
  const lista = a.pendentes.map(p => `${p.nome} (${brl(Math.round(p.valor * 100))}/mês)`).join(' e ');
  return html`<div class="card pad alerta-card" style="margin-bottom:14px" id="ad-pendentes"><div class="row wrap" style="gap:12px;align-items:center"><div style="flex:1;min-width:240px"><b>Obrigado pela compra! Falta só ativar o que você escolheu:</b><div class="small">${lista}.</div><div class="small muted">Abre o pagamento mensal no cartão, com o mesmo e-mail. Cancele quando quiser.</div></div><a class="btn primary" href="${a.pendentes[0].url}" target="_blank" rel="noopener">Ativar agora</a></div></div>`;
}
function cardLicenca() {
  const l = S.licenca; if (!l) return '';
  const wa = l.vendedor_whatsapp ? linkWhatsApp(l.vendedor_whatsapp, `Olá! Quero ativar o MesaPronta. Código do computador: ${l.codigo_maquina}`) : '';
  const comprar = botaoComprar(l, 'btn primary lg');
  const auto = !!l.compra_automatica && !l.nuvem;
  const botoes = auto ? html`<div class="row wrap" style="gap:8px">${raw(comprar)}<button class="btn" data-ja-comprei>Já paguei — verificar</button><button class="btn ghost" data-ir-licenca>Tenho uma chave</button></div>`
    : html`<div class="row wrap" style="gap:8px">${raw(comprar)}${wa ? html`<a class="btn ${comprar ? '' : 'primary'}" href="${wa}" target="_blank">${comprar ? 'Já comprei — pedir a chave' : 'Pedir chave pelo WhatsApp'}</a>` : ''}<button class="btn" data-copiar-cod>Copiar código ${l.codigo_maquina}</button><button class="btn" data-ir-licenca>Já tenho a chave</button></div>`;
  if (l.estado === 'teste') {
    const n = Number(l.dias_restantes), urgente = n <= 2;
    return html`<div class="card pad mp-lic ${urgente ? 'alerta-card vermelho' : ''}" style="margin-bottom:14px"><div class="row wrap" style="gap:14px;align-items:center"><div class="mp-lic-n"><b>${n <= 0 ? 'HOJE' : n}</b><span>${n <= 0 ? 'último dia' : n === 1 ? 'dia restante' : 'dias restantes'}</span></div>
      <div style="flex:1;min-width:240px"><b>${n <= 0 ? 'Seu período de teste termina hoje.' : `Seu período de teste termina em ${n} dia${n > 1 ? 's' : ''}${l.termina_em ? ' (' + dataBR(l.termina_em) + ')' : ''}.`}</b><div class="small muted">${auto ? 'Compre agora com Pix ou cartão: a licença ativa sozinha neste computador logo depois do pagamento. ' : comprar ? 'Compre agora e garanta seu acesso: depois da compra, envie o código deste computador e receba a chave. ' : `Para continuar usando, envie o código deste computador para ${esc(l.vendedor_nome || 'o vendedor')} e ative com a chave que receber. `}Nada do que você cadastrou se perde.</div></div>${botoes}</div></div>`;
  }
  if (l.estado === 'ativada' && l.dias_para_expirar != null && l.dias_para_expirar <= 15) {
    return html`<div class="card pad mp-lic ${l.dias_para_expirar <= 3 ? 'alerta-card vermelho' : 'alerta-card'}" style="margin-bottom:14px"><div class="row wrap" style="gap:14px;align-items:center"><div style="flex:1;min-width:240px"><b>Sua licença vence ${l.dias_para_expirar <= 0 ? 'hoje' : 'em ' + l.dias_para_expirar + ' dia(s)'} (${dataBR(l.expira)}).</b><div class="small muted">${auto ? 'Renove pelo botão abaixo: a licença nova ativa sozinha depois do pagamento.' : `Peça a renovação a ${esc(l.vendedor_nome || 'o vendedor')} e cole a nova chave em Configurações → Licença.`}</div></div>${botoes}</div></div>`;
  }
  return '';
}
// ---------------- Configurações ----------------
async function vConfig(c) {
  const [cfg, info, backups, lic, rede] = await Promise.all([GET('/api/config'), GET('/api/info'), GET('/api/backups'), GET('/api/licenca'), GET('/api/sistema/rede').catch(() => null)]);
  S.licenca = lic; avisoLicenca(); S.cfg = cfg;
  const base = baseSistema(info) || `http://localhost:${info.porta}`;
  const abas = [['geral', 'Geral'], ['rede', 'Rede, celulares e app'], ...(R.cardapio_qr ? [['cardapio', 'Cardápio digital (QR)']] : []), ['pix', 'Pix'], ['impressora', R.cozinha ? 'Impressoras' : 'Impressora do caixa'], ...((window.PRODUTO_CONFIG || {}).abas || []).map(x => [x.id, x.nome]), ['licenca', 'Licença e atualizações'], ['backup', 'Backup e sistema']];
  if (!abas.some(x => x[0] === S.abaConfig)) S.abaConfig = 'geral';
  if (S.abaConfig === 'acesso') S.abaConfig = 'rede';
  const a = S.abaConfig;
  const chk = (id, on, texto) => html`<label class="check"><input type="checkbox" id="${id}" ${on ? raw('checked') : ''}> ${texto}</label>`;
  const temSalvar = ['geral', 'cardapio', 'pix', 'impressora', 'backup'].includes(a) || ((window.PRODUTO_CONFIG || {}).abas || []).some(x => x.id === a && x.salvar);
  let corpo = '';
  if (a === 'geral') corpo = html`<div class="card pad stack" style="max-width:760px">
      <div class="row wrap"><div><h2>Configuração geral</h2><div class="muted small">Primeira vez? Use o assistente: ele configura ${R.mesas ? 'mesas, cardápio' : (T.produtos || 'produtos').toLowerCase()}, equipe e impressoras passo a passo.</div></div><span class="spacer"></span><button class="btn primary" id="c-assist">🧭 Abrir assistente de configuração</button></div>
      <details class="sec"><summary>Dados do estabelecimento (preenche uma vez só)</summary><div class="stack" style="padding:8px 0">
        <label class="campo">Nome (sai no cupom${R.cardapio_qr ? ' e no cardápio digital' : ''})<input type="text" id="c-nome" value="${cfg.nome_estabelecimento}"></label>
        <div class="grid2"><label class="campo">CNPJ / CPF<input type="text" id="c-doc" value="${cfg.documento}"></label><label class="campo">Telefone<input type="text" id="c-tel" value="${cfg.telefone}"></label></div>
        <label class="campo">Endereço<input type="text" id="c-end" value="${cfg.endereco}"></label>
        <label class="campo">Mensagem no fim do cupom<input type="text" id="c-rod" value="${cfg.rodape_cupom}"></label></div></details>
      <details class="sec" open><summary>Conta e recebimento</summary><div class="stack" style="padding:8px 0">
        ${R.servico ? html`<div class="grid2"><label class="campo">Taxa de serviço (%)<input type="number" id="c-serv" value="${cfg.servico_pct}"></label><div style="padding-top:24px">${chk('c-serv-on', cfg.servico_padrao_ativo === '1', 'Cobrar serviço por padrão nas mesas')}</div></div>
        ${chk('c-prec', cfg.imprimir_preconta_ao_pedir_conta === '1', 'Imprimir conferência quando o cliente/garçom pedir a conta')}` : ''}
        ${chk('c-cup', cfg.imprimir_cupom_ao_fechar === '1', 'Imprimir cupom automaticamente ao receber')}</div></details>
      <details class="sec" open><summary>Caixa</summary><div class="stack" style="padding:8px 0">
        ${chk('c-cego', cfg.fechamento_cego === '1', 'Fechamento cego: o operador conta sem ver o valor esperado (gerente sempre vê)')}
        <label class="campo">Desconto que o caixa pode dar sem PIN do gerente (% do subtotal; 0 = sempre pede PIN)<input type="number" id="c-descmax" value="${cfg.desconto_max_caixa_pct}" min="0" max="100" style="max-width:160px"></label></div></details>
      <details class="sec"><summary>${R.mesas ? 'Cardápio e pedidos' : (T.produtos || 'Produtos') + ' e ' + (T.pedidos || 'vendas').toLowerCase()}</summary><div class="stack" style="padding:8px 0">
        <div class="campo"><span>Observações rápidas gerais (valem para todos os itens — digite e aperte Enter)</span><div id="c-obsr-chips"></div></div>
        ${R.pizza ? html`<label class="campo">Pizza meio a meio cobra<select id="c-meio" style="max-width:260px"><option value="maior" ${cfg.meio_a_meio_regra !== 'media' ? raw('selected') : ''}>o sabor mais caro</option><option value="media" ${cfg.meio_a_meio_regra === 'media' ? raw('selected') : ''}>a média dos dois</option></select></label>` : ''}${raw(((window.PRODUTO_CONFIG || {}).geral || (() => ''))(cfg))}</div></details>
      ${R.cozinha ? html`<details class="sec"><summary>Cozinha e tempos</summary><div class="stack" style="padding:8px 0">
        <div class="grid3"><label class="campo">Alerta amarelo após (min)<input type="number" id="c-al" value="${cfg.cozinha_alerta_min}"></label><label class="campo">Atrasado após (min)<input type="number" id="c-at" value="${cfg.cozinha_atraso_min}"></label><label class="campo">Delivery: previsão (min)<input type="number" id="c-te" value="${cfg.tempo_entrega_min}"></label></div>
        ${chk('c-somrep', cfg.cozinha_som_repetir === '1', 'Repetir o alerta sonoro a cada 20 s até a cozinha confirmar que viu o pedido')}
        ${chk('c-voz', cfg.cozinha_voz === '1', 'Anunciar por voz ("Novo pedido, mesa 5") — precisa de caixa de som na tela da cozinha')}</div></details>` : ''}</div>`;
  const telasRede = (PR.telas && PR.telas.length ? PR.telas.map(t => [t[1].replace(/ \(.*\)$/, ''), t[2]]) : [['Garçom', '/garcom'], ['Cozinha', '/cozinha'], ['Caixa', '/'], ['Visor', '/visor'], ['Senhas', '/painel']]);
  const net = info.internet;
  const qrRede = (url, nome) => html`<div class="stack" style="text-align:center;align-items:center;gap:2px"><div class="qr">${raw(qrImg(url, 3))}</div><b class="small">${nome}</b></div>`;
  const cardInternet = !net ? '' : html`<div class="card pad stack" style="grid-column:1/-1">
      <div class="row wrap" style="gap:10px;align-items:center"><h2 style="margin:0">🌐 Pela internet <span class="muted" style="font-weight:600;font-size:15px">— 4G ou qualquer Wi-Fi</span></h2><span class="spacer"></span>
        ${!net.ativo ? html`<span class="badge">Desligado</span>` : net.conectado ? html`<span class="badge ok">● Conectado</span>` : html`<span class="badge warn">● ${net.ligado ? 'Sem internet agora' : 'Ligando…'}</span>`}</div>
      <p class="muted small" style="margin:0">A equipe, você de casa e os clientes na mesa usam pelo endereço <b>${net.url || '…'}</b>, sem precisar estar no Wi-Fi. <b>Se a internet cair, quem estiver no Wi-Fi do restaurante continua trabalhando normalmente</b> pelo endereço do Wi-Fi (logo abaixo).</p>
      ${net.ativo && net.url && net.convite ? html`<div class="row wrap" style="gap:18px;align-items:flex-start">${telasRede.map(([n, u]) => qrRede(linkEquipe(info, u), n))}${qrRede(linkEquipe(info, '/'), 'Você, de casa')}</div>
        <div class="small muted">Cada QR já libera o aparelho para usar pela internet (depois ele pede o PIN). Mostre só para a sua equipe.</div>`
        : net.ativo ? html`<div class="small muted">${net.erro ? 'Aguardando conexão: ' + net.erro : 'Conectando ao servidor… os QR aparecem aqui em instantes.'}</div>` : ''}
      <div class="row wrap" style="gap:14px"><label class="check"><input type="checkbox" id="c-internet" ${net.ativo ? raw('checked') : ''}> Permitir usar pela internet</label>
        ${net.ativo && net.convite ? html`<button type="button" class="btn sm" id="c-convite">🔒 Desconectar todos os aparelhos da internet</button>` : ''}</div></div>`;
  if (a === 'rede') corpo = html`<div class="rel-grid">${cardInternet}<div class="card pad stack"><h2>${net ? '📶 No Wi-Fi do restaurante' : 'Celulares e outras telas'}${net ? html` <span class="muted" style="font-weight:600;font-size:15px">— funciona sem internet</span>` : ''}</h2>
      ${rede?.so_local ? html`<div class="card pad stack" style="background:var(--warn-soft);border:0;box-shadow:none;gap:8px"><b>📵 Os celulares e as outras telas ainda não estão liberados</b><div class="small">Por enquanto o sistema só abre neste computador${net && net.ativo ? ' pelo Wi-Fi. Pela internet (card acima) os celulares já funcionam, sem mexer no Windows' : ''}. Para usar celulares, tablet ou TV pelo Wi-Fi, clique no botão abaixo. O Windows vai perguntar se permite alterações: clique em <b>Sim</b> (só uma vez).</div><div><button type="button" class="btn primary" id="c-fwb">📱 Liberar celulares e TV</button></div></div>` : ''}
      <p class="muted small" style="margin:0">${info.nuvem ? html`Funciona em qualquer celular, tablet ou computador com internet, de qualquer lugar. Aponte a câmera para o QR: ele já libera o aparelho para a sua equipe.` : html`Os aparelhos precisam estar no <b>mesmo Wi-Fi</b> deste computador. Aponte a câmera para o QR ou digite o endereço.`}</p>
      ${info.enderecos.length ? html`<div class="row wrap" style="gap:18px;align-items:flex-start">
        ${telasRede.map(([n, u]) => html`<div class="stack" style="text-align:center;align-items:center;gap:2px"><div class="qr">${raw(qrImg(linkEquipe(info, u, 'wifi') || base + u, 3))}</div><b class="small">${n}</b><div class="small muted" style="font-size:11px">${(baseSistema(info, 'wifi') || base) + u}</div></div>`)}</div>
      ${info.enderecos.length > 1 && !info.nuvem ? html`<div class="small muted">Outros endereços deste PC: ${info.enderecos.slice(1).map(e => `http://${e}:${info.porta}`).join(' · ')}</div>` : ''}` : html`<div class="badge warn">Este computador não está conectado a uma rede. Conecte no Wi-Fi ou cabo.</div>`}
      <p class="small muted" style="margin:0">No iPhone (Safari) ou Android (Chrome): menu → "Adicionar à tela de início" para virar um ícone de app.</p>
      ${R.cozinha ? chk('c-estacao', estacaoImpressao(), 'Este computador é a estação de impressão (imprime os pedidos "pelo navegador")') : ''}
      ${chk('c-visor', localStorage.getItem('mp_visor') === '1', 'Este computador alimenta o visor do cliente')}</div>
    <div class="card pad stack"><h2>Rede e aplicativo</h2>
      <div class="lista-simples" style="padding:0">
        <div class="l"><span class="spacer">Versão</span><b>${info.versao}${info.nuvem ? ' · online' : rede?.app ? ' · aplicativo' : ' · modo script'}</b></div>
        ${info.nuvem ? '' : html`<div class="l"><span class="spacer">Computador</span><b>${rede?.hostname || '—'}</b></div>`}
        <div class="l"><span class="spacer">${info.nuvem ? 'Endereço da sua loja' : net ? 'Endereço no Wi-Fi' : 'Endereço principal'}</span><b>${info.nuvem ? base : baseSistema(info, 'wifi') || base}</b></div>
        ${net && net.ativo && net.url ? html`<div class="l"><span class="spacer">Endereço pela internet</span><b>${net.url}</b></div>` : ''}
        ${info.nuvem ? '' : html`<div class="l"><span class="spacer">Pasta dos dados</span><span class="small" style="font-family:var(--mono)">${rede?.dados || ''}</span></div>`}
        ${rede?.treino ? html`<div class="l"><span class="badge warn">MODO TREINO — os dados daqui não valem</span></div>` : ''}</div>
      ${rede?.windows ? html`<div class="rotulo" style="margin-top:8px">AJUSTES DO WINDOWS (pede permissão de administrador)</div>
        <div class="row wrap"><button class="btn" id="c-fw">🛡 Liberar celulares no firewall</button><button class="btn" id="c-startup">⏻ Iniciar junto com o Windows</button><button class="btn" id="c-atalho">🖥 Criar atalho na área de trabalho</button></div>
        <div class="small muted" id="c-startup-st"></div>` : info.nuvem ? '' : html`<div class="small muted">Os ajustes automáticos de firewall e inicialização só existem no Windows.</div>`}
      ${info.nuvem ? html`<div class="rotulo" style="margin-top:8px">PROBLEMAS DE CONEXÃO?</div><div class="small muted">Confira se o aparelho tem internet. Aparelho novo da equipe: escaneie o QR desta tela (ou entre com o e-mail e a senha da conta). Os dados ficam guardados no servidor, com cópia de segurança todo dia.</div>` : html`<div class="rotulo" style="margin-top:8px">PROBLEMAS DE CONEXÃO?</div>
      <div class="small muted">1) Celular e PC no mesmo Wi-Fi. 2) Firewall liberado (botão acima). 3) No roteador, desligue "isolamento de clientes / AP isolation". 4) Se o endereço mudar toda hora, fixe o IP do PC no roteador (reserva DHCP).</div>
      <div class="row wrap" style="margin-top:8px"><button class="btn" id="c-treino">🎓 Abrir modo treino (dados de mentira, porta 3001)</button><button class="btn danger" id="c-encerrar">Encerrar o MesaPronta neste computador</button></div>
      <div class="small muted">O modo treino é uma cópia separada do sistema para a equipe praticar. Nada do que fizer lá entra nas vendas de verdade.</div>`}</div></div>`;
  if (a === 'cardapio') corpo = html`<div class="card pad stack" style="max-width:760px"><h2>Cardápio digital por QR Code</h2>
      <p class="muted small" style="margin:0">Cada mesa tem um QR próprio. O cliente vê o cardápio com fotos e preços, pode pedir pelo celular, chamar o garçom e pedir a conta. Tudo chega no caixa e no celular do garçom.</p>
      ${chk('c-cd', cfg.cardapio_digital_ativo === '1', 'Cardápio digital ligado')}
      ${chk('c-cp', cfg.cliente_pode_pedir === '1', 'Cliente pode fazer pedidos pelo celular')}
      ${chk('c-ca', cfg.cliente_pedido_precisa_aprovacao === '1', 'Pedidos do cliente precisam de aprovação antes de ir para a cozinha (recomendado)')}
      ${info.internet ? html`<div class="rotulo" style="margin-top:6px">O QR DAS MESAS ABRE</div>
        <label class="check"><input type="radio" name="c-qrm" value="internet" ${info.internet.qr_mesas !== 'wifi' ? raw('checked') : ''}> <span><b>Pela internet</b> — o cliente usa o 4G, sem entrar no Wi-Fi (recomendado)</span></label>
        <label class="check"><input type="radio" name="c-qrm" value="wifi" ${info.internet.qr_mesas === 'wifi' ? raw('checked') : ''}> <span><b>Só pelo Wi-Fi do restaurante</b> — funciona sem internet, mas o cliente precisa entrar no Wi-Fi</span></label>
        <div class="small muted">Depois de mudar, imprima as plaquinhas de novo.</div>` : ''}
      <div class="row wrap"><button class="btn primary" id="c-plaq">🖨 Imprimir plaquinhas das mesas</button><a class="btn" href="/cardapio" target="_blank">Ver o cardápio</a></div></div>
    <div class="card pad stack" style="max-width:760px;margin-top:14px"><h2>🎨 Aparência do cardápio</h2>
      <p class="muted small" style="margin:0">Vale para o cardápio da mesa (QR), o cardápio online e o totem. O logo e o banner são salvos na hora.</p>
      <div class="cd-visual">
        <div><div class="rotulo">LOGO</div><div class="cd-img cd-logo" style="${cfg.online_logo ? raw(`background-image:url('${encodeURI(cfg.online_logo)}')`) : ''}">${cfg.online_logo ? '' : 'Seu logo'}</div>
          <div class="row" style="gap:6px;margin-top:6px"><button class="btn sm" data-cd-img="logo">${cfg.online_logo ? 'Trocar' : 'Escolher'}</button>${cfg.online_logo ? html`<button class="btn sm ghost danger" data-cd-tirar="logo">Tirar</button>` : ''}</div></div>
        <div style="flex:1;min-width:220px"><div class="rotulo">BANNER (FOTO DE FUNDO DO TOPO)</div><div class="cd-img cd-capa" style="${cfg.online_capa ? raw(`background-image:url('${encodeURI(cfg.online_capa)}')`) : ''}">${cfg.online_capa ? '' : 'Foto da fachada, do salão ou dos pratos'}</div>
          <div class="row" style="gap:6px;margin-top:6px"><button class="btn sm" data-cd-img="capa">${cfg.online_capa ? 'Trocar' : 'Escolher'}</button>${cfg.online_capa ? html`<button class="btn sm ghost danger" data-cd-tirar="capa">Tirar</button>` : ''}</div></div>
      </div>
      <div class="small muted">Logo: imagem quadrada (de preferência com fundo). Banner: foto deitada, de pelo menos 1200 px de largura.</div>
      <div class="rotulo" style="margin-top:6px">COR</div><div class="row wrap" style="gap:8px">${['#e3262f', '#f25c05', '#f2a900', '#2e9d4f', '#0f8b8d', '#2563eb', '#7c3aed', '#c2185b', '#3f3f46'].map(x => html`<button type="button" class="cd-cor ${(cfg.online_cor || '#e3262f') === x ? 'on' : ''}" data-cd-cor="${x}" style="background:${x}" aria-label="Cor ${x}"></button>`)}<input type="hidden" id="c-cd-cor" value="${cfg.online_cor || '#e3262f'}"></div>
      <div class="rotulo" style="margin-top:6px">FUNDO</div><div class="row wrap" style="gap:14px"><label class="check"><input type="radio" name="c-cd-tema" value="escuro" ${cfg.online_tema !== 'claro' ? raw('checked') : ''}> 🌙 Escuro</label><label class="check"><input type="radio" name="c-cd-tema" value="claro" ${cfg.online_tema === 'claro' ? raw('checked') : ''}> ☀️ Claro</label></div>
    </div>`;
  if (a === 'pix') corpo = html`<div class="card pad stack" style="max-width:760px"><h2>Pix na tela</h2>
      <p class="muted small" style="margin:0">Com a chave cadastrada, o caixa mostra um QR com o valor exato da conta. O dinheiro cai direto na sua conta, sem taxa. Sempre confira no app do banco antes de dar baixa.</p>
      ${cfg.pix_chave ? html`<div class="badge ok">✓ Chave configurada: ${cfg.pix_chave}</div>` : html`<div class="badge warn">Nenhuma chave cadastrada ainda</div>`}
      <div class="grid3"><label class="campo">Chave Pix<input type="text" id="c-pixk" value="${cfg.pix_chave}" placeholder="CPF/CNPJ, telefone, e-mail ou aleatória"></label><label class="campo">Nome do recebedor<input type="text" id="c-pixn" value="${cfg.pix_nome}" placeholder="${cfg.nome_estabelecimento}"></label><label class="campo">Cidade<input type="text" id="c-pixc" value="${cfg.pix_cidade}" placeholder="Itabuna"></label></div>
      <div><button class="btn" id="c-pixt">Salvar e testar com R$ 1,00</button></div></div>`;
  const setoresImp = a === 'impressora' && R.cozinha ? await GET('/api/cad/setores').catch(() => []) : [];
  if (a === 'impressora') corpo = html`<div class="card pad stack" style="max-width:760px"><h2>Impressora do caixa</h2><p class="muted small" style="margin:0">Usada para ${R.cozinha ? 'conferência de conta' : 'conferência'}, cupom e fechamento de caixa.${window.PRODUTO_IMPRESSORA_DICA ? ' ' + window.PRODUTO_IMPRESSORA_DICA : ''}</p>
      ${raw(camposImpressora(cfg.impressora_caixa || {}, 'caixa'))}</div>
    ${R.cozinha ? html`<div class="card pad stack" style="max-width:760px" id="imp-setores"><h2>Impressoras da cozinha e do bar</h2>
      <p class="muted small" style="margin:0">Cada setor de preparo (Cozinha, Bar, Pizzaria…) pode ter a sua impressora: o pedido sai separado em cada uma.${setoresImp.length ? '' : ' Ainda não há setores: crie em Cadastros › Setores e impressoras.'}</p>
      ${setoresImp.map(st => html`<div class="card pad stack" style="box-shadow:none;border:1px solid var(--line)" data-setor-imp="${st.id}"><h3 style="margin:0">${st.nome}</h3>${raw(camposImpressora(st.impressora || {}, 'st' + st.id))}</div>`)}
      ${raw(chk('c-estacao', estacaoImpressao(), 'Este computador é a estação de impressão (imprime os pedidos "pelo navegador")'))}
      <div><button type="button" class="btn sm ghost" id="c-ir-setores">Criar ou renomear setores</button></div></div>` : ''}`;
  if (a === 'licenca') {
    const wa = lic.vendedor_whatsapp ? linkWhatsApp(lic.vendedor_whatsapp, `Olá! Quero ativar o MesaPronta. Código do computador: ${lic.codigo_maquina}`) : '';
    const on = await GET('/api/atualizacao').catch(() => null);
    const up = on?.atualizacao;
    const nst = lic.nuvem || !info.internet ? null : await GET('/api/nuvem/status').catch(() => null);   // sem a parte da nuvem (modo treino) a rota não existe
    const cardConta = !nst ? '' : html`<div class="card pad stack" style="max-width:760px"><h2>Sua conta</h2>
      ${nst.email_em_uso ? raw(avisoEmailEmUso(nst.email_em_uso, 'conta-email-em-uso')) : nst.email ? html`<div>E-mail da conta: <b>${nst.email}</b></div>` : html`<div class="muted small">Este computador ainda não está ligado a uma conta.</div>`}
      <div class="muted small" style="margin:0">Com o e-mail e a senha da conta você entra em outro computador (seus dados vão junto) e acompanha o restaurante pelo site.</div>
      <div class="row wrap" style="gap:8px">${nst.email ? html`<button class="btn" id="c-senha-conta">Criar ou trocar a senha da conta</button>` : ''}${linkSuporte() ? html`<a class="btn ghost" target="_blank" href="${linkSuporte('Esqueci a senha da minha conta' + (nst.email ? '. Meu e-mail: ' + nst.email : ''))}">Esqueci a senha</a>` : ''}</div></div>`;
    corpo = html`${raw(cardConta)}${lic.nuvem ? raw('<!--') : ''}<div class="card pad stack" style="max-width:760px"><h2>Atualizações</h2>
      <div class="row wrap" style="align-items:center"><span>Versão instalada: <b>${info.versao}</b></span>${up?.disponivel ? html`<span class="badge warn">Nova versão ${up.versao} disponível</span>` : on?.ultima ? html`<span class="badge ok">✓ Você está na versão mais recente</span>` : ''}<span class="spacer"></span><button class="btn sm" id="c-verificar" ${on?.configurada ? '' : raw('disabled')}>⟳ Verificar agora</button></div>
      ${up?.disponivel ? html`<div class="card pad alerta-card ${up.importante ? 'vermelho' : ''}" style="box-shadow:none"><b>Versão ${up.versao}${up.importante ? ' — atualização importante' : ''}</b>${up.mensagem ? html`<div class="small" style="white-space:pre-wrap;margin-top:4px">${up.mensagem}</div>` : ''}<div class="row wrap" style="margin-top:8px">${up.download ? html`<a class="btn primary" href="${up.download}" target="_blank">⬇ Baixar o MesaPronta ${up.versao}</a>` : ''}<span class="muted small" style="align-self:center">Depois de baixar, abra o arquivo: ele atualiza sozinho mantendo seus dados.</span></div></div>` : ''}
      <div class="muted small">${!on?.configurada ? 'Verificação automática não configurada nesta versão.' : on?.ultima ? `Última verificação: ${dataBR(on.ultima.slice(0, 10))} ${hora(on.ultima)}. O sistema verifica sozinho algumas vezes por dia quando há internet.` : on?.erro ? `Ainda não foi possível verificar (${on.erro}). O sistema tenta de novo sozinho; ele funciona normalmente sem internet.` : 'Ainda não verificou. O sistema verifica sozinho alguns segundos depois de abrir.'}</div></div>
    ${lic.nuvem ? raw('-->') : ''}<div class="card pad stack" style="max-width:760px"><h2>Licença</h2>
      ${precisaComprar(lic) && linkCompra(lic) ? html`<div class="card pad row wrap" style="background:var(--accent-soft);border:0;box-shadow:none;gap:12px;align-items:center"><div style="flex:1;min-width:220px"><b>${lic.estado === 'teste' ? 'Gostou do sistema? Garanta o seu.' : 'Para continuar usando, compre a licença.'}</b><div class="small muted">${lic.compra_automatica && !lic.nuvem ? 'Pague com Pix ou cartão: a licença ativa sozinha neste computador em até 2 minutos (com internet). Nada do que você cadastrou se perde.' : 'Depois da compra, envie o código abaixo e receba a chave de ativação. Nada do que você cadastrou se perde.'}</div></div>${raw(botaoComprar(lic, 'btn primary lg'))}${lic.compra_automatica && !lic.nuvem ? html`<button class="btn" id="c-buscar">Já paguei — verificar</button>` : ''}${ofertaAdicionaisTxt(lic) ? html`<div class="small muted" style="flex-basis:100%">${ofertaAdicionaisTxt(lic)}</div>` : ''}</div>` : ''}
      ${lic.estado === 'ativada' ? html`<div class="card pad" style="background:var(--ok-soft);border:0;box-shadow:none"><b style="color:var(--ok)">✓ Ativado</b>${lic.cliente ? ' para ' + lic.cliente : ''} · ${lic.vitalicia ? 'licença vitalícia' : 'válida até ' + dataBR(lic.expira) + (lic.dias_para_expirar <= 15 ? ` (${lic.dias_para_expirar <= 0 ? 'vence hoje' : 'faltam ' + lic.dias_para_expirar + ' dia(s)'})` : '')}</div>`
        : html`<div class="card pad alerta-card ${lic.bloqueado ? 'vermelho' : ''}" style="box-shadow:none">${lic.estado === 'teste' ? textoTeste(lic) + (lic.termina_em ? ` (${dataBR(lic.termina_em)}).` : '.') + (lic.compra_automatica ? '' : ' Envie o código abaixo para ' + esc(lic.vendedor_nome || 'o vendedor') + ' e cole a chave que receber.') : lic.erro || 'O período de teste terminou.'}</div>`}
      ${lic.nuvem ? html`<div class="muted small">Na versão online a compra ativa sozinha: pague pelo botão acima e a licença aparece aqui em até 1 minuto.</div>${raw('<details class="mais-chave"><summary>Tenho uma chave de ativação</summary>')}` : lic.compra_automatica ? raw('<details class="mais-chave"><summary>Tenho uma chave de ativação</summary>') : ''}
      <div class="card pad" style="text-align:center"><div class="rotulo">${lic.nuvem ? 'CÓDIGO DA SUA CONTA' : 'CÓDIGO DESTE COMPUTADOR'}</div><div class="codigo-maquina">${lic.codigo_maquina}</div>
        <div class="row" style="justify-content:center;gap:8px"><button class="btn sm" id="c-copiar">Copiar código</button>${wa ? html`<a class="btn sm" href="${wa}" target="_blank">Enviar pelo WhatsApp</a>` : ''}</div></div>
      <label class="campo">Chave de ativação<textarea id="c-chave" rows="3" style="font-family:var(--mono);font-size:13px" placeholder="${PR.prefixo || 'MP'}1.xxxxx.xxxxx"></textarea></label>
      <div><button class="btn primary" id="c-ativar">Ativar</button></div>${lic.nuvem || lic.compra_automatica ? raw('</details>') : ''}</div>`;
  }
  const abaProduto = ((window.PRODUTO_CONFIG || {}).abas || []).find(x => x.id === a);
  if (abaProduto) corpo = raw(abaProduto.corpo(cfg, { info, lic, rede }));
  if (a === 'backup') corpo = html`<div class="rel-grid"><div class="card pad stack"><h2>Backup</h2>
      <p class="muted small" style="margin:0">Backup automático todo dia e a cada fechamento de caixa. Pasta: <code>${backups.pasta}</code></p>
      <div class="row wrap"><button class="btn primary" id="c-bk-down">⇩ Baixar backup (pendrive / nuvem)</button><button class="btn" id="c-backup">Fazer backup agora</button><span class="muted small">${backups.arquivos.length} cópia(s)</span></div>
      <label class="campo">Manter quantos backups<input type="number" id="c-bk" value="${cfg.backup_dias_manter}" style="max-width:140px"></label></div>
    <div class="card pad stack"><h2>Suporte</h2>
      ${linkSuporte() ? html`<div class="row wrap" style="align-items:center;gap:10px"><div>WhatsApp do suporte: <b>${telefoneSuporte()}</b><div class="muted small">Dúvidas, chave de ativação, atualização — responde em horário comercial.</div></div><a class="btn ok" target="_blank" href="${linkSuporte()}">💬 Falar com o suporte</a></div>` : html`<div class="muted small">Suporte não configurado nesta versão.</div>`}
      <label class="campo" hidden>WhatsApp do suporte (aparece na Ajuda)<input type="text" id="c-sup" value="${cfg.suporte_whatsapp}" placeholder="5573999990000"></label>
      <h3 style="margin-top:8px">Visor e painel</h3>
      <div class="grid2"><label class="campo">Mensagem do visor quando ocioso<input type="text" id="c-visormsg" value="${cfg.visor_mensagem}"></label><div style="padding-top:24px">${chk('c-painel', cfg.painel_senhas_ativo === '1', 'Painel de senhas ligado')}</div></div>
      <h3 style="color:var(--danger);margin-top:8px">🔒 Zona de perigo</h3>
      <p class="muted small" style="margin:0">Tudo aqui pede o PIN do gerente, mesmo já logado. Um backup é feito antes.</p>
      <div class="row wrap"><button class="btn danger" id="c-zerar">Zerar vendas e caixas</button><button class="btn danger" id="c-zerar2">Zerar TUDO (vendas + produtos + clientes)</button></div></div></div>`;
  c.innerHTML = html`<div class="cab"><h1>Configurações</h1></div>
    <div class="abas">${abas.map(([k, v]) => html`<button class="aba ${k === a ? 'on' : ''}" data-aba="${k}">${v}${k === 'licenca' && lic.estado !== 'ativada' ? ' ●' : ''}</button>`)}</div>${corpo}
    ${temSalvar ? html`<div class="salvar-barra" id="c-barra" style="max-width:760px"><span class="muted small" id="c-status" style="align-self:center">Nenhuma alteração</span><span class="spacer"></span><button class="btn primary lg" id="c-salvar">💾 Salvar</button></div>` : ''}`;
  let lerImp = null, chipsObs = null;
  if (abaProduto && abaProduto.aoMontar) abaProduto.aoMontar(c, cfg);
  if (a === 'geral' && (window.PRODUTO_CONFIG || {}).aoMontarGeral) window.PRODUTO_CONFIG.aoMontarGeral(c, cfg);
  if (a === 'impressora') lerImp = ligarImpressora(c, 'caixa');
  const lerSetores = setoresImp.map(st => [st, ligarImpressora(c, 'st' + st.id)]);
  if ($('#c-ir-setores')) $('#c-ir-setores').onclick = () => { S.abaCad = 'setores'; ir('cadastros'); };
  if (a === 'geral') chipsObs = montarChips($('#c-obsr-chips'), (cfg.obs_rapidas_gerais || '').split(';').map(v => v.trim()).filter(Boolean), 'Ex.: Para viagem');
  const on = (id, fn) => { const b = $('#' + id); if (b) b.onclick = fn; };
  let alterado = false;
  const marcar = () => { alterado = true; const st = $('#c-status'); if (st) { st.textContent = '● Alterações não salvas'; st.style.color = 'var(--warn)'; } $('#c-barra')?.classList.add('pendente'); };
  c.addEventListener('input', marcar); c.addEventListener('change', marcar);
  on('c-assist', () => { S.passoAssist = null; ir('assistente'); });
  on('c-backup', () => tentar(() => POST('/api/backup'), 'Backup feito').then(() => render()));
  on('c-bk-down', () => tentar(() => baixarArquivo('/api/backup/download')));
  on('c-plaq', () => window.open('/plaquinhas', '_blank'));
  on('c-copiar', () => navigator.clipboard?.writeText(lic.codigo_maquina).then(() => toast('Código copiado', 'ok')));
  on('c-senha-conta', async () => {
    const r = await modal({ titulo: 'Senha da sua conta', corpo: `<div class="stack"><label class="campo">Nova senha<input type="password" id="mp-s1" autocomplete="new-password" minlength="6"></label><label class="campo">Repita a senha<input type="password" id="mp-s2" autocomplete="new-password"></label><div class="muted small">Pelo menos 6 letras ou números. Ela vale para entrar em outro computador e no site.</div></div>`,
      botoes: [{ texto: 'Cancelar' }, { texto: 'Salvar senha', classe: 'primary', padrao: true, acao: (f) => {
        const a = $('#mp-s1', f).value, b = $('#mp-s2', f).value;
        if (a.length < 6) { toast('A senha precisa ter pelo menos 6 letras ou números', 'erro'); return false; }
        if (a !== b) { toast('As duas senhas não são iguais', 'erro'); return false; }
        return a; } }] });
    if (!r) return;
    await tentar(() => POST('/api/nuvem/senha', { senha: r }), 'Senha da conta salva');
  });
  on('c-verificar', async () => { const b = $('#c-verificar'); b.disabled = true; b.textContent = 'Verificando...'; const r = await POST('/api/atualizacao/verificar').catch(e => ({ ok: false, erro: e.message })); if (r.ok) toast(r.atualizacao?.disponivel ? `Nova versão ${r.atualizacao.versao} disponível` : 'Você já está na versão mais recente', 'ok'); else toast(r.erro || 'Não foi possível verificar', 'erro'); render(); });
  on('c-buscar', () => jaPagueiVerificar());
  on('c-ativar', async () => { await tentar(() => POST('/api/licenca/ativar', { chave: $('#c-chave').value }), 'Licença ativada! Obrigado.'); render(); });
  on('c-fw', () => tentar(() => POST('/api/sistema/firewall'), 'Firewall liberado para os celulares'));
  const cInt = $('#c-internet'); if (cInt) cInt.onchange = async () => { try { await POST('/api/nuvem/internet', { ativo: cInt.checked }); toast(cInt.checked ? 'Pronto: dá para usar pela internet' : 'Acesso pela internet desligado (o Wi-Fi continua)', 'ok'); } catch (e) { cInt.checked = !cInt.checked; toast(e.message, 'erro'); } setTimeout(render, 600); };
  on('c-convite', async () => { if (!(await confirmar('Desconectar aparelhos', 'Todos os aparelhos que usam pela internet vão precisar escanear o QR de novo. Os do Wi-Fi não mudam.', 'Desconectar todos'))) return; if (await tentar(() => POST('/api/nuvem/trocar-convite'), 'Pronto. Os QR da internet foram trocados.')) render(); });
  $$('input[name="c-qrm"]').forEach(r => { r.onchange = () => tentar(() => POST('/api/nuvem/internet', { qr_mesas: r.value }), r.value === 'wifi' ? 'O QR das mesas vai abrir pelo Wi-Fi' : 'O QR das mesas vai abrir pela internet'); });
  on('c-fwb', async () => { if (await tentar(() => POST('/api/sistema/firewall'), 'Pronto! Celulares e TV liberados')) render(); });
  on('c-treino', async () => { const r = await tentar(() => POST('/api/sistema/modo-treino'), 'Modo treino iniciado'); if (r?.url) setTimeout(() => window.open(r.url, '_blank'), 2500); });
  on('c-atalho', () => tentar(() => POST('/api/sistema/atalho-area-trabalho'), 'Atalho criado na área de trabalho'));
  on('c-encerrar', async () => { if (!(await confirmar('Encerrar', `Isso fecha o MesaPronta neste computador. ${R.cozinha ? 'Os celulares e a cozinha vão' : 'Os celulares e as outras telas vão'} parar de funcionar até abrir de novo.`, 'Encerrar', 'danger solid'))) return; await POST('/api/sistema/encerrar').catch(() => {}); document.body.innerHTML = '<div class="login"><div class="login-caixa"><div class="logo">Mesa<span>Pronta</span></div><p>Sistema encerrado. Pode fechar esta janela.</p></div></div>'; });
  if (rede?.windows && $('#c-startup')) {
    GET('/api/sistema/iniciar-com-windows').then(r => { $('#c-startup-st').textContent = r.ativo ? '✓ Iniciando junto com o Windows' : 'Não inicia automaticamente com o Windows'; $('#c-startup').dataset.ativo = r.ativo ? '1' : '0'; $('#c-startup').textContent = r.ativo ? '⏻ Não iniciar com o Windows' : '⏻ Iniciar junto com o Windows'; }).catch(() => {});
    on('c-startup', async () => { const ativar = $('#c-startup').dataset.ativo !== '1'; await tentar(() => POST('/api/sistema/iniciar-com-windows', { ativar }), ativar ? 'Vai iniciar com o Windows' : 'Removido da inicialização'); render(); });
  }
  const zerar = async (apagar) => {
    const a2 = await pinGerente(false, 'Digite o PIN do gerente para confirmar', true); if (!a2 || !a2.pin) return;
    if (!(await confirmar('Tem certeza?', apagar ? 'Apaga TODAS as vendas, caixas, produtos, categorias e clientes. Não dá para desfazer (só pelo backup).' : 'Apaga TODAS as vendas e caixas. Os cadastros ficam.', 'Sim, zerar', 'danger solid'))) return;
    await tentar(() => POST('/api/sistema/zerar', { pin_gerente: a2.pin, apagar_cadastros: apagar }), 'Dados zerados');
    await carregarBase(); ir('inicio');
  };
  on('c-zerar', () => zerar(false)); on('c-zerar2', () => zerar(true));
  const v = (id) => $('#' + id)?.value;
  const ck = (id) => { const e = $('#' + id); return e ? (e.checked ? '1' : '0') : undefined; };
  const salvar = async () => {
    const o = {};
    const put = (k, val) => { if (val !== undefined && val !== null) o[k] = val; };
    put('nome_estabelecimento', v('c-nome')); put('documento', v('c-doc')); put('telefone', v('c-tel')); put('endereco', v('c-end')); put('rodape_cupom', v('c-rod'));
    put('servico_pct', v('c-serv')); put('servico_padrao_ativo', ck('c-serv-on')); put('imprimir_preconta_ao_pedir_conta', ck('c-prec')); put('imprimir_cupom_ao_fechar', ck('c-cup'));
    if (chipsObs) put('obs_rapidas_gerais', chipsObs.get().join(';'));
    put('meio_a_meio_regra', v('c-meio')); put('cozinha_alerta_min', v('c-al')); put('cozinha_atraso_min', v('c-at')); put('tempo_entrega_min', v('c-te')); put('cozinha_som_repetir', ck('c-somrep')); put('cozinha_voz', ck('c-voz'));
    if (a === 'cardapio') { put('online_cor', v('c-cd-cor')); const tm = $('input[name=c-cd-tema]:checked'); if (tm) put('online_tema', tm.value); }
    put('cardapio_digital_ativo', ck('c-cd')); put('cliente_pode_pedir', ck('c-cp')); put('cliente_pedido_precisa_aprovacao', ck('c-ca'));
    put('pix_chave', v('c-pixk')); put('pix_nome', v('c-pixn')); put('pix_cidade', v('c-pixc')); put('backup_dias_manter', v('c-bk'));
    put('fechamento_cego', ck('c-cego')); put('desconto_max_caixa_pct', v('c-descmax')); put('suporte_whatsapp', v('c-sup')); put('visor_mensagem', v('c-visormsg')); put('painel_senhas_ativo', ck('c-painel'));
    if (lerImp) o.impressora_caixa = lerImp();
    for (const [st, ler] of lerSetores) { const nova = ler(); if (JSON.stringify(nova) !== JSON.stringify(st.impressora || {})) { await tentar(() => PUT(`/api/cad/setores/${st.id}`, { impressora: nova })); st.impressora = nova; } }
    const est = $('#c-estacao'); if (est) { try { localStorage.setItem('mp_estacao', est.checked ? '1' : '0'); } catch {} }
    const vis = $('#c-visor'); if (vis) { try { localStorage.setItem('mp_visor', vis.checked ? '1' : '0'); } catch {} }
    if (abaProduto && abaProduto.salvar) Object.assign(o, abaProduto.salvar(c) || {});
    if (a === 'geral' && (window.PRODUTO_CONFIG || {}).salvarGeral) Object.assign(o, window.PRODUTO_CONFIG.salvarGeral(c) || {});
    if (Object.keys(o).length) await tentar(() => PUT('/api/config', o), 'Configurações salvas ✓');
    S.cfg = await GET('/api/config'); alterado = false;
    const st = $('#c-status'); if (st) { st.textContent = '✓ Salvo'; st.style.color = 'var(--ok)'; } $('#c-barra')?.classList.remove('pendente');
  };
  on('c-salvar', salvar);
  if (a === 'cardapio') c.addEventListener('click', async (e) => {
    const cor = e.target.closest('[data-cd-cor]');
    if (cor) { $('#c-cd-cor').value = cor.dataset.cdCor; $$('[data-cd-cor]', c).forEach(x => x.classList.toggle('on', x === cor)); marcar(); return; }
    const tir = e.target.closest('[data-cd-tirar]');
    if (tir) { if (alterado) await salvar(); await tentar(() => POST('/api/online/imagem', { tipo: tir.dataset.cdTirar, dados: null }), 'Imagem retirada'); return render(); }
    const im = e.target.closest('[data-cd-img]');
    if (im) {
      const inp = document.createElement('input'); inp.type = 'file'; inp.accept = 'image/*';
      inp.onchange = async () => { const f = inp.files[0]; if (!f) return; if (alterado) await salvar(); const dados = await redimensionarImagem(f, im.dataset.cdImg === 'capa' ? 1600 : 500); await tentar(() => POST('/api/online/imagem', { tipo: im.dataset.cdImg, dados }), 'Imagem salva ✓'); render(); };
      inp.click();
    }
  });
  on('c-pixt', async () => { await salvar(); mostrarPix(100, 'TESTE'); });
  const estC = $('#c-estacao'); if (estC) estC.onchange = () => { try { localStorage.setItem('mp_estacao', estC.checked ? '1' : '0'); } catch {} toast('Salvo', 'ok'); };
  const visC = $('#c-visor'); if (visC) visC.onchange = () => { try { localStorage.setItem('mp_visor', visC.checked ? '1' : '0'); } catch {} toast('Salvo', 'ok'); };
  c.onclick = async (e) => { const ab = e.target.closest('[data-aba]'); if (ab) { if (alterado && !(await confirmar('Alterações não salvas', 'Sair sem salvar?', 'Sair sem salvar', 'danger solid'))) return; S.abaConfig = ab.dataset.aba; render(); } };
}

// ---------------- Assistente de configuração ----------------
async function vAssistente(c) {
  const cfg = S.cfg = await GET('/api/config');
  if (!S.passoAssist) S.passoAssist = Math.max(1, Number(cfg.assist_passo) || 1);
  const PASSOS_BASE = [
    { id: 'estabelecimento', nome: 'Estabelecimento' }, { id: 'ambientes', nome: 'Ambientes e mesas', se: R.mesas }, { id: 'cardapio', nome: R.mesas ? 'Cardápio' : (T.produtos || 'Produtos') },
    { id: 'equipe', nome: T.equipe || 'Equipe' }, { id: 'setores', nome: 'Setores e impressoras', se: R.setores }, { id: 'pix', nome: 'Pix e pagamento' }, { id: 'rede', nome: 'Celulares e rede' }, { id: 'pronto', nome: 'Pronto!' },
  ];
  const LISTA = [];
  for (const pb of PASSOS_BASE) {
    for (const pp of (window.PRODUTO_ASSISTENTE || []).filter(x => x.antes === pb.id)) LISTA.push(pp);
    const sub = (window.PRODUTO_ASSISTENTE || []).find(x => x.substitui === pb.id);
    if (sub) LISTA.push(sub); else if (pb.se !== false) LISTA.push(pb);
    for (const pp of (window.PRODUTO_ASSISTENTE || []).filter(x => x.depois === pb.id)) LISTA.push(pp);
  }
  // Online: só o essencial (3 passos). O resto vira "Mais ajustes (opcional)" no fim.
  const COMPLETA = LISTA.slice();
  const EXTRAS = [];
  if (S.nuvem && !S.assistCompleto) {
    const essencial = (x) => ['estabelecimento', 'cardapio', 'pix', 'pronto'].includes(x.id) || x.substitui === 'cardapio';
    for (const x of COMPLETA) if (!essencial(x)) EXTRAS.push(x);
    LISTA.splice(0, LISTA.length, ...COMPLETA.filter(essencial));
  }
  if (S.passoAssist > LISTA.length) S.passoAssist = 1;
  const passo = S.passoAssist;
  const passos = LISTA.map(x => x.nome);
  const ID = LISTA[passo - 1].id;
  const PASSO_PRODUTO = LISTA[passo - 1].montar ? LISTA[passo - 1] : null;
  let rascunho = {}; try { rascunho = JSON.parse(cfg.assist_rascunho || '{}'); } catch {}
  const salvarRascunho = adiar((obj) => { rascunho = { ...rascunho, ...obj }; PUT('/api/config', { assist_rascunho: JSON.stringify(rascunho) }).catch(() => {}); }, 400);
  const tipos = new Set((cfg.tipos_operacao || '').split(',').filter(Boolean));
  const TIPOS_OP = window.PRODUTO_ASSISTENTE_TIPOS || (R.mesas ? [['mesas', '🍽 Mesas com garçom', 'taxa de serviço, comanda no celular'], ['bar', '🍺 Bar / choperia', 'comandas numeradas (cartão)'], ['lanchonete', '🍔 Lanchonete / balcão', 'venda no balcão, painel de senhas'], ['pizzaria', '🍕 Pizzaria', 'pizza meio a meio, tamanhos'], ['delivery', '🛵 Delivery', 'bairros, entregadores, WhatsApp']] : []);
  const cab = html`<div class="cab"><h1>🧭 ${TX.assist_h1 || 'Configurar meu negócio'}</h1><span class="muted">Passo ${passo} de ${passos.length} · tudo é salvo automaticamente</span><span class="spacer"></span><button class="btn" id="as-sair">Sair (continua depois)</button></div>
    <div class="assist"><div class="passos-barra">${passos.map((p, i) => html`<div class="pb ${i + 1 === passo ? 'on' : i + 1 < passo ? 'ok' : ''}" data-ps="${i + 1}">${i + 1}. ${p}</div>`)}</div>`;
  const rodape = () => html`<div class="rodape">${passo > 1 ? html`<button class="btn" id="as-ant">← Anterior</button>` : ''}<span class="spacer"></span><span class="muted small" id="as-status" style="align-self:center"></span><button class="btn primary lg" id="as-prox">${passo === passos.length ? 'Concluir' : 'Continuar →'}</button></div>`;
  let corpo = '', aoAvancar = async () => {}, autosalvar = null;
  const statusOk = () => { const e = $('#as-status'); if (e) { e.textContent = '✓ salvo'; setTimeout(() => { if (e.textContent === '✓ salvo') e.textContent = ''; }, 2000); } };

  if (ID === 'estabelecimento') {
    corpo = html`<h2>Seu estabelecimento</h2><div class="sub">Esses dados saem no cupom${R.cardapio_qr ? ' e no cardápio digital' : ''}. Só o nome é obrigatório.</div>
      <div class="stack"><label class="campo">Nome do ${T.estabelecimento || 'estabelecimento'}<input type="text" id="a-nome" value="${cfg.nome_estabelecimento === 'Meu Restaurante' ? '' : cfg.nome_estabelecimento}" placeholder="${esc(TX.exemplo_nome || (R.mesas ? 'Ex.: Bar do Zé' : 'Ex.: ' + (PR.nome === 'MesaPronta' ? 'Bar do Zé' : 'Nome do seu negócio')))}"></label>
      <div class="grid2"><label class="campo">Telefone / WhatsApp<input type="text" id="a-tel" value="${cfg.telefone}"></label><label class="campo">CNPJ / CPF (opcional)<input type="text" id="a-doc" value="${cfg.documento}"></label></div>
      <label class="campo">Endereço (sai no cupom)<input type="text" id="a-end" value="${cfg.endereco}"></label>
      ${TIPOS_OP.length ? html`<div class="rotulo" style="margin-top:6px">COMO VOCÊ TRABALHA? <span class="muted" style="text-transform:none;font-weight:500">(marque todos que valem)</span></div>
      <div class="opcoes-grandes" id="a-tipo">${TIPOS_OP.map(([k, t, d]) => html`<button type="button" class="opc ${tipos.has(k) ? 'on' : ''}" data-tipo="${k}">${t}<br><span class="muted small" style="font-weight:500">${d}</span></button>`)}</div>` : ''}</div>`;
    const salvar1 = async (exigirNome) => {
      const nome = $('#a-nome').value.trim(); if (exigirNome && !nome) throw new Error('Informe o nome do estabelecimento');
      const sel = $$('#a-tipo .opc.on').map(b => b.dataset.tipo);
      const o = { telefone: $('#a-tel').value, documento: $('#a-doc').value, endereco: $('#a-end').value, tipos_operacao: sel.join(',') };
      if (nome) { o.nome_estabelecimento = nome; o.pix_nome = nome; }
      o.servico_padrao_ativo = (sel.includes('mesas') || sel.includes('bar')) ? '1' : (sel.includes('lanchonete') && sel.length === 1 ? '0' : cfg.servico_padrao_ativo);
      if (sel.includes('lanchonete')) o.painel_senhas_ativo = '1';
      await PUT('/api/config', o); statusOk();
    };
    autosalvar = () => salvar1(false).catch(() => {});
    aoAvancar = () => salvar1(true);
  }
  if (ID === 'ambientes') {
    const mesas = await GET('/api/cad/mesas?todos=1');
    const ativas = mesas.filter(m => m.ativo);
    const areasAtuais = [...new Set(ativas.map(m => m.area || 'Salão'))];
    corpo = html`<h2>Ambientes e mesas</h2><div class="sub">Diga como é o seu salão: quais ambientes existem, quantas mesas e quantas cadeiras em cada. Dá para ajustar depois em Cadastros → Mesas.</div>
      ${ativas.length ? html`<div class="card pad" style="background:var(--surface-2);box-shadow:none;margin-bottom:12px"><b>Hoje você tem ${ativas.length} mesa(s)</b> em: ${areasAtuais.map(a => `${a} (${ativas.filter(m => (m.area || 'Salão') === a).length})`).join(', ')}.<br><label class="check" style="margin-top:6px"><input type="checkbox" id="a-subst" ${rascunho.substituir ? raw('checked') : ''}> Apagar o mapa atual e criar do zero com o que eu preencher abaixo</label></div>` : ''}
      <div id="a-ambientes" class="stack"></div>
      <div class="row" style="margin-top:8px"><button type="button" class="btn" id="a-add-amb">+ Outro ambiente</button><span class="muted small">Sugestões: Salão, Varanda, Área externa, Mezanino, Calçada, VIP</span></div>
      ${tipos.has('lanchonete') && tipos.size === 1 ? html`<div class="muted small" style="margin-top:8px">Lanchonete sem mesas? Deixe zerado e siga — você usa o Balcão.</div>` : ''}`;
    aoAvancar = async () => {
      const areas = $$('.ambiente-linha').map(l => ({ nome: $('[data-k=nome]', l).value.trim(), qtd: Number($('[data-k=qtd]', l).value) || 0, lugares: Number($('[data-k=lug]', l).value) || 4 })).filter(a => a.nome && a.qtd > 0);
      const substituir = !!$('#a-subst')?.checked;
      if (areas.length) await POST('/api/mesas/gerar', { areas, substituir });
      rascunho.ambientes = []; rascunho.substituir = false; await PUT('/api/config', { assist_rascunho: JSON.stringify(rascunho) });
    };
  }
  if (ID === 'cardapio') {
    const [card, categorias, setores, bairros] = await Promise.all([GET('/api/cardapio'), GET('/api/cad/categorias'), GET('/api/cad/setores'), GET('/api/cad/bairros')]);
    const ex = card.produtos.some(p => p.nome === 'X-Burguer' && p.codigo === '1');
    corpo = html`<h2>${R.mesas ? 'Cardápio' : (T.produtos || 'Produtos')}</h2><div class="sub">${card.produtos.length} item(ns) em ${card.categorias.length} categoria(s)${ex ? ' — ainda são os exemplos que vêm com o sistema' : ''}. Cadastre aqui mesmo; depois dá para mudar em Cadastros.</div>
      <div class="stack">
        ${ex ? html`<div class="card pad alerta-card" style="box-shadow:none"><b>Os produtos atuais são de exemplo.</b> <button type="button" class="btn danger sm" id="a-limpar">🗑 Apagar exemplos e começar do zero</button> <span class="muted small">ou mantenha e edite abaixo</span></div>` : ''}
        ${R.mesas ? html`<a class="card pad row wrap cm-foto" style="gap:12px;box-shadow:none;text-decoration:none;color:inherit" href="${linkFotoCardapio()}" target="_blank" rel="noopener"><span style="font-size:28px">📸</span><span style="flex:1;min-width:200px"><b>Mandar a foto do cardápio no WhatsApp</b><br><span class="small muted">A gente cadastra os seus produtos para você, sem custo. Enquanto isso, use os exemplos.</span></span><span class="btn ok">Mandar foto</span></a>` : ''}
        <div class="row wrap"><button type="button" class="btn primary" id="a-novo-prod">+ Novo produto</button><button type="button" class="btn" id="a-nova-cat">+ Nova categoria</button><button type="button" class="btn" id="a-catalogo">🥤 Catálogo de bebidas</button><button type="button" class="btn" id="a-importar">⇧ Importar de planilha</button></div>
        <div class="card"><table class="tab"><thead><tr><th></th><th>Produto</th><th>Categoria</th><th class="r">Preço</th><th></th></tr></thead><tbody>${card.produtos.slice(0, 200).map(p => html`<tr class="click" data-pid="${p.id}"><td>${fotoHtml(p.foto, p.nome, 'thumb', categorias.find(k => k.id === p.categoria_id)?.nome)}</td><td><b>${p.nome}</b>${p.descricao ? html`<br><span class="small muted">${p.descricao}</span>` : ''}</td><td>${categorias.find(k => k.id === p.categoria_id)?.nome || '—'}</td><td class="r num">${p.tamanhos.length ? p.tamanhos.map(t => t.nome + ' ' + brlCurto(t.preco)).join(' / ') : brl(p.preco)}</td><td class="r"><span class="muted small">editar ✎</span></td></tr>`)}</tbody></table>${card.produtos.length ? '' : html`<div class="vazio">Nenhum produto ainda. Clique em "+ Novo produto".</div>`}</div>
        <div class="muted small">Pizzas: crie a categoria "Pizzas" marcando "permite meio a meio" e cadastre cada sabor com os tamanhos P/M/G. O sistema monta o botão "Montar pizza" sozinho.</div></div>`;
    S._assistD = { categorias, setores, bairros, produtos: card.produtos };
    aoAvancar = async () => {};
  }
  if (ID === 'equipe') {
    const us = await GET('/api/cad/usuarios?todos=1');
    corpo = html`<h2>Equipe e senhas (PIN)</h2><div class="sub">Cada pessoa entra com um PIN de 4 a 6 números. <b>Troque os PINs de exemplo</b> (1234, 1111, 2222) — qualquer um que conheça o sistema sabe eles.</div>
      <div class="stack" id="a-users">${us.filter(u => u.ativo).map(u => html`<div class="grid3 a-user" data-id="${u.id}" style="align-items:end"><label class="campo">Nome<input type="text" data-k="nome" value="${u.nome}"></label><label class="campo">Perfil<select data-k="perfil"><option value="garcom" ${u.perfil === 'garcom' ? raw('selected') : ''}>${T.profissional || 'Garçom'}</option><option value="caixa" ${u.perfil === 'caixa' ? raw('selected') : ''}>Caixa</option><option value="gerente" ${u.perfil === 'gerente' ? raw('selected') : ''}>Gerente</option>${R.delivery ? html`<option value="entregador" ${u.perfil === 'entregador' ? raw('selected') : ''}>Entregador</option>` : ''}</select></label><label class="campo">Novo PIN ${['1234', '1111', '2222'].includes(u.pin) ? html`<span style="color:var(--danger)">(troque!)</span>` : html`<span class="muted">(vazio = manter)</span>`}<input type="password" inputmode="numeric" data-k="pin" placeholder="${['1234', '1111', '2222'].includes(u.pin) ? 'exemplo — troque' : '••••'}" autocomplete="new-password"></label></div>`)}</div>
      <div class="row" style="margin-top:8px"><button type="button" class="btn" id="a-add-user">+ Adicionar pessoa</button><span class="muted small">${R.mesas ? 'Garçom: só a comanda no celular. Caixa: mesas, balcão, delivery e caixa. Gerente: tudo.' : `${T.profissional || 'Equipe'}: ${T.perfil_profissional || 'lança itens e acompanha o serviço'}. Caixa / recepção: atende, recebe e fecha o caixa. Gerente: tudo.`}</span></div>`;
    aoAvancar = async () => {
      for (const l of $$('.a-user')) {
        const dados = { nome: $('[data-k=nome]', l).value.trim(), perfil: $('[data-k=perfil]', l).value };
        const pin = $('[data-k=pin]', l).value.trim(); if (pin) dados.pin = pin;
        if (!dados.nome) continue;
        if (l.dataset.id) await PUT(`/api/cad/usuarios/${l.dataset.id}`, dados); else if (pin) await POST('/api/cad/usuarios', { ...dados, ativo: 1, comissao: 0 });
      }
    };
  }
  if (ID === 'setores') {
    const st = await GET('/api/cad/setores?todos=1');
    const sug = PRESETS_SETOR.slice(); if (tipos.has('pizzaria') && !sug.includes('Pizzaria')) sug.push('Pizzaria');
    corpo = html`<h2>Setores de preparo e impressoras</h2><div class="sub">Setor = onde o pedido é preparado. Cada setor tem sua tela na cozinha e, se quiser, uma impressora. Marque os que existem:</div>
      <div class="chips" style="gap:8px">${sug.map(p => { const tem = st.find(x => x.nome.toLowerCase() === p.toLowerCase() && x.ativo); return html`<button type="button" class="chip ${tem ? 'on' : ''}" data-set="${p}" style="font-size:16px;padding:10px 16px">${p}</button>`; })}</div>
      <label class="campo" style="margin-top:10px">Outro setor<input type="text" id="a-outro-setor" placeholder="Ex.: Confeitaria"></label>
      <div class="card pad" style="margin-top:10px;background:var(--surface-2);box-shadow:none"><b>Impressoras</b> <span class="muted small">— opcional; a tela da cozinha funciona sem nenhuma.</span><div class="row wrap" style="margin-top:6px">${st.filter(x => x.ativo).map(x => html`<button type="button" class="btn sm" data-imp="${x.id}">🖨 ${x.nome}: ${(TIPOS_IMP.find(t => t[0] === x.impressora?.tipo) || TIPOS_IMP[0])[1]}</button>`)}</div></div>`;
    aoAvancar = async () => {
      const marcados = $$('[data-set].on').map(b => b.dataset.set);
      const outro = $('#a-outro-setor').value.trim(); if (outro) marcados.push(outro);
      for (const nome of marcados) { const ex = st.find(x => x.nome.toLowerCase() === nome.toLowerCase()); if (ex) { if (!ex.ativo) await PUT(`/api/cad/setores/${ex.id}`, { ativo: 1 }); } else await POST('/api/cad/setores', { nome, impressora: { tipo: 'nenhuma', largura: 48 }, ativo: 1 }); }
      for (const x of st.filter(x => x.ativo && !marcados.some(m => m.toLowerCase() === x.nome.toLowerCase()))) await PUT(`/api/cad/setores/${x.id}`, { ativo: 0 });
    };
  }
  if (ID === 'pix') {
    const formas = await GET('/api/cad/formas_pagamento?todos=1');
    corpo = html`<h2>Pix e formas de pagamento</h2><div class="sub">Com a chave Pix, o caixa mostra um QR com o valor exato para o cliente pagar. Sem taxa, sem maquininha.</div>
      <div class="stack"><div class="grid2"><label class="campo">Chave Pix (opcional)<input type="text" id="a-pix" value="${cfg.pix_chave}" placeholder="CPF, CNPJ, telefone, e-mail ou aleatória"></label><label class="campo">Cidade<input type="text" id="a-cid" value="${cfg.pix_cidade}" placeholder="Itabuna"></label></div>
      <div class="rotulo">FORMAS DE PAGAMENTO QUE VOCÊ ACEITA</div><div class="chips">${formas.map(f => html`<button type="button" class="chip ${f.ativo ? 'on' : ''}" data-forma="${f.id}">${f.nome}</button>`)}</div>
      <div class="grid2" ${R.mesas ? '' : raw('hidden')}><label class="campo">Taxa de serviço (%)<input type="number" id="a-serv" value="${cfg.servico_pct}"></label><div style="padding-top:24px"><label class="check"><input type="checkbox" id="a-serv-on" ${cfg.servico_padrao_ativo === '1' ? raw('checked') : ''}> Cobrar serviço nas mesas por padrão</label></div></div></div>`;
    const salvar6 = async () => {
      await PUT('/api/config', { pix_chave: $('#a-pix').value.trim(), pix_cidade: $('#a-cid').value.trim(), servico_pct: $('#a-serv').value, servico_padrao_ativo: $('#a-serv-on').checked ? '1' : '0' });
      for (const b of $$('[data-forma]')) { const f = formas.find(x => x.id === Number(b.dataset.forma)); const on = b.classList.contains('on') ? 1 : 0; if (f.ativo !== on) { await PUT(`/api/cad/formas_pagamento/${f.id}`, { ativo: on }); f.ativo = on; } }
      statusOk();
    };
    autosalvar = () => salvar6().catch(() => {});
    aoAvancar = salvar6;
  }
  if (ID === 'rede') {
    const [info, rede] = await Promise.all([GET('/api/info'), GET('/api/sistema/rede').catch(() => null)]);
    const base = baseSistema(info);
    corpo = html`<h2>Celulares e rede</h2>${rede?.so_local ? html`<div class="card pad stack" style="background:var(--warn-soft);border:0;box-shadow:none;gap:8px"><b>📵 Os celulares e as outras telas ainda não estão liberados</b><div class="small">Por enquanto o sistema só abre neste computador. Para usar celulares, tablet ou TV, clique no botão abaixo. O Windows vai perguntar se permite alterações: clique em <b>Sim</b> (só uma vez).</div><div><button type="button" class="btn primary" id="a-fwb">📱 Liberar celulares e TV</button></div></div>` : ''}<div class="sub">${R.garcom ? 'Os garçons usam o próprio celular; a cozinha, uma TV ou tablet.' : 'A equipe usa o próprio celular ou outro computador.'} ${info.nuvem ? 'Funciona em qualquer aparelho com internet — sem instalar nada.' : 'Tudo no mesmo Wi-Fi deste computador — sem instalar nada.'}</div>
      ${base ? html`<div class="row wrap" style="gap:18px;align-items:flex-start;margin-bottom:12px">${(PR.telas || []).slice(0, 4).map(([, n, u]) => html`<div class="stack" style="text-align:center;align-items:center;gap:2px"><div class="qr">${raw(qrImg(linkEquipe(info, u), 3))}</div><b class="small">${n}</b><div class="small muted" style="font-size:11px">${base + u}</div></div>`)}</div>
        <div class="row wrap" style="margin-bottom:10px"><a class="btn" href="/qrcodes" target="_blank">📱 Abrir a página com todos os QR Codes</a></div>` : html`<div class="badge warn">Este computador não está em nenhuma rede. Conecte no Wi-Fi e volte aqui.</div>`}
      ${rede?.windows ? html`<div class="row wrap"><button type="button" class="btn primary" id="a-fw">🛡 Liberar celulares no firewall do Windows</button><button type="button" class="btn" id="a-startup">⏻ Iniciar o ${PR.nome} junto com o Windows</button><button type="button" class="btn" id="a-atalho">🖥 Atalho na área de trabalho</button></div><div class="muted small" style="margin-top:6px">O Windows vai pedir permissão de administrador uma vez.</div>` : ''}
      <div class="muted small" style="margin-top:10px">Teste agora: pegue um celular, ${info.nuvem ? 'com internet,' : 'conecte no Wi-Fi'} e escaneie o QR ${R.garcom ? '"Garçom"' : '"Caixa (outro PC/tablet)"'}. Se não abrir, veja Configurações → Rede.</div>`;
    aoAvancar = async () => {};
  }
  if (ID === 'pronto' && S.nuvem && !S.assistCompleto) {
    corpo = html`<h2>Tudo pronto! 🎉</h2><div class="sub">Seu ${PR.nome} já funciona. Agora o melhor jeito de entender é fazer um pedido de teste — leva 2 minutos.</div>
      <div class="stack">${TEM_TOUR() ? html`<button type="button" class="btn ok lg" id="a-tour">▶ Fazer um pedido de teste agora</button>` : ''}
      ${EXTRAS.length ? html`<div class="rotulo" style="margin-top:8px">MAIS AJUSTES (OPCIONAL)</div><div class="row wrap" style="gap:8px">${EXTRAS.map(x => html`<button type="button" class="btn" data-extra="${x.id}">${x.nome}</button>`)}</div><div class="muted small">Dá para fazer depois, a qualquer momento, em Configurações e Cadastros.</div>` : ''}</div>`;
    aoAvancar = async () => { await PUT('/api/config', { configurado: '1', assist_passo: '1' }); S.cfg = await GET('/api/config'); };
  } else if (ID === 'pronto') {
    corpo = html`<h2>Tudo pronto! 🎉</h2><div class="sub">Seu ${PR.nome} está configurado. Você pode mudar qualquer coisa depois em Cadastros e Configurações.</div>
      <div class="stack"><div class="lista-simples" style="padding:0">
        <div class="l">✓ Treine a equipe sem medo: Configurações → Rede → "Abrir modo treino" (uma cópia separada, com dados de mentira).</div>
        <div class="l">✓ Quando for começar de verdade, em Configurações → Backup e sistema use "Zerar vendas" para limpar os testes.</div>
        <div class="l">✓ ${R.mesas ? 'Imprima as plaquinhas QR das mesas (Cadastros → Mesas → Plaquinhas QR) e deixe a página de QR Codes aberta para a equipe entrar.' : 'Deixe a página de QR Codes (menu QR Codes) aberta para a equipe entrar pelo celular.'}</div>
        <div class="l">✓ Ative a licença em Configurações → Licença antes de acabar o período de teste.</div></div></div>`;
    aoAvancar = async () => { await PUT('/api/config', { configurado: '1', assist_passo: '1' }); S.cfg = await GET('/api/config'); };
  }
  let depoisProduto = null;
  if (PASSO_PRODUTO) { const r = await PASSO_PRODUTO.montar({ cfg, rascunho, salvarRascunho, statusOk, S, html, raw, esc }); corpo = r.corpo || ''; aoAvancar = r.aoAvancar || (async () => {}); autosalvar = r.autosalvar || null; depoisProduto = r.depois || null; }
  const AULA_PASSO = { estabelecimento: 0, ambientes: 2, cardapio: 1, equipe: 0, setores: 4, pix: 8, rede: 0 };
  let faixaAula = '';
  if (R.aulas && ID === 'pronto') faixaAula = `<div class="assist-aulas"><div class="rotulo">APRENDA COM AS AULAS EM VÍDEO</div><div class="small muted" style="margin-bottom:8px">${AULAS().length} aulas curtas mostrando cada parte do sistema. Dá para ver agora ou quando tiver dúvida (menu "Aulas em vídeo" ou o botão ▶ no canto de cada tela).</div>
      <div class="assist-aulas-grade">${AULAS().slice(0, 4).map((a, i) => `<button type="button" class="aula-mini" data-as-aula="${i}">${capaHtml(i, true)}<span>Aula ${String(i + 1).padStart(2, '0')} — ${esc(a[1])}</span></button>`).join('')}</div>
      <button type="button" class="btn" id="as-todas-aulas" style="margin-top:8px">Ver todas as ${AULAS().length} aulas →</button></div>`;
  else if (R.aulas && AULA_PASSO[ID] != null && AULAS()[AULA_PASSO[ID]]) { const i = AULA_PASSO[ID]; faixaAula = `<button type="button" class="assist-aula" data-as-aula="${i}">${capaHtml(i, true)}<span class="aa-txt"><span class="small muted">Dúvida neste passo? Veja o vídeo</span><b>▶ Aula ${String(i + 1).padStart(2, '0')} — ${esc(AULAS()[i][1])}</b></span></button>`; }
  c.innerHTML = cab.s + `<div class="card corpo">${faixaAula}${corpo.s || corpo}${rodape().s}</div></div>`;
  c.querySelectorAll('[data-as-aula]').forEach(b => b.addEventListener('click', (e) => { e.preventDefault(); abrirAula(Number(b.dataset.asAula)); }));
  const ta = $('#as-todas-aulas', c); if (ta) ta.onclick = () => ir('aulas');
  if (depoisProduto) depoisProduto(c);
  if (c._autoFn) { c.removeEventListener('input', c._autoFn); c.removeEventListener('change', c._autoFn); c._autoFn = null; }
  if (autosalvar) { const meuPasso = passo; const f = adiar(() => { if (S.view === 'assistente' && passo === meuPasso && c._autoFn === f) { try { autosalvar(); } catch {} } }, 700); c._autoFn = f; c.addEventListener('input', f); c.addEventListener('change', f); }
  if (ID === 'estabelecimento') $('#a-tipo').onclick = (e) => { const b = e.target.closest('.opc'); if (b) { b.classList.toggle('on'); autosalvar(); } };
  if (ID === 'ambientes') {
    const box = $('#a-ambientes');
    const lerLinhas = () => $$('.ambiente-linha').map(l => ({ nome: $('[data-k=nome]', l).value, qtd: $('[data-k=qtd]', l).value, lug: $('[data-k=lug]', l).value }));
    const linha = (nome = '', qtd = '', lug = 4) => { const d = document.createElement('div'); d.className = 'ambiente-linha'; d.innerHTML = `<label class="campo">Ambiente<input type="text" data-k="nome" value="${esc(nome)}" placeholder="Salão" list="a-sug"></label><label class="campo">Quantas mesas<input type="number" data-k="qtd" value="${esc(qtd)}" min="0"></label><label class="campo">Cadeiras por mesa<input type="number" data-k="lug" value="${esc(lug)}" min="1"></label><button type="button" class="btn ghost danger" data-rm style="margin-bottom:0">✕</button>`; box.appendChild(d); };
    const sug = document.createElement('datalist'); sug.id = 'a-sug'; sug.innerHTML = ['Salão', 'Varanda', 'Área externa', 'Mezanino', 'Calçada', 'VIP', '2º andar'].map(x => `<option value="${x}">`).join(''); box.appendChild(sug);
    if (rascunho.ambientes?.length) for (const a of rascunho.ambientes) linha(a.nome, a.qtd, a.lug);
    else { const ativas = (await GET('/api/cad/mesas')).filter(m => m.ativo); if (ativas.length) for (const a of [...new Set(ativas.map(m => m.area || 'Salão'))]) linha(a, ativas.filter(m => (m.area || 'Salão') === a).length, 4); else { linha('Salão', 10, 4); linha('Varanda', 4, 4); } }
    $('#a-add-amb').onclick = () => { linha('', 4, 4); salvarRascunho({ ambientes: lerLinhas() }); };
    box.addEventListener('click', (e) => { const b = e.target.closest('[data-rm]'); if (b) { b.closest('.ambiente-linha').remove(); salvarRascunho({ ambientes: lerLinhas() }); } });
    c.addEventListener('input', () => salvarRascunho({ ambientes: lerLinhas(), substituir: !!$('#a-subst')?.checked }));
    c.addEventListener('change', () => salvarRascunho({ ambientes: lerLinhas(), substituir: !!$('#a-subst')?.checked }));
  }
  if (ID === 'cardapio' || (PASSO_PRODUTO && LISTA[passo - 1].substitui === 'cardapio')) { const av0 = aoAvancar; aoAvancar = async () => { await av0(); await PUT('/api/config', { produtos_ok: '1' }).catch(() => {}); }; }
  if (ID === 'pronto') { const t = $('#a-tour'); if (t) t.onclick = async () => { await aoAvancar(); S.passoAssist = null; await carregarBase(); await ir('inicio'); Tour.iniciar(); };
    c.querySelectorAll('[data-extra]').forEach(b => b.onclick = async () => { S.assistCompleto = true; S.passoAssist = COMPLETA.findIndex(x => x.id === b.dataset.extra) + 1; render(); }); }
  if (ID === 'cardapio') {
    const d = S._assistD;
    $('#a-novo-prod').onclick = async () => { await editarCadastro('produtos', {}, d, true); render(); };
    $('#a-nova-cat').onclick = async () => { await editarCadastro('categorias', {}, d, true); render(); };
    $('#a-catalogo').onclick = async () => { await catalogoBebidas(); render(); };
    $('#a-importar').onclick = () => modal({ titulo: 'Importar produtos de planilha', largo: true, corpo: `<div class="stack"><p class="muted small">No Excel: <b>código; nome; categoria; setor; preço; custo</b>. Copie as linhas e cole aqui.</p><textarea id="imp-txt" rows="10" placeholder="1;X-Burguer;Lanches;Cozinha;18,00;7,00"></textarea></div>`,
      botoes: [{ texto: 'Cancelar' }, { texto: 'Importar', classe: 'primary', acao: async (f) => { const r = await POST('/api/cad/produtos/importar', { texto: $('#imp-txt', f).value }); toast(`${r.criados} criado(s), ${r.atualizados} atualizado(s)`, 'ok'); render(); } }] });
    const lim = $('#a-limpar'); if (lim) lim.onclick = async () => { const a2 = await pinGerente(false, 'PIN do gerente para apagar os exemplos', true); if (!a2?.pin) return; await tentar(() => POST('/api/cardapio/limpar', { pin_gerente: a2.pin }), 'Exemplos apagados'); S.cardapio = await GET('/api/cardapio'); render(); };
    c.querySelector('tbody')?.addEventListener('click', async (e) => { const tr = e.target.closest('[data-pid]'); if (!tr) return; const prods = await GET('/api/cad/produtos?todos=1'); await editarCadastro('produtos', prods.find(x => x.id === Number(tr.dataset.pid)), d, true); render(); });
  }
  if (ID === 'equipe') $('#a-add-user').onclick = () => { const d = document.createElement('div'); d.className = 'grid3 a-user'; d.style.alignItems = 'end'; d.innerHTML = '<label class="campo">Nome<input type="text" data-k="nome"></label><label class="campo">Perfil<select data-k="perfil"><option value="garcom">' + esc(T.profissional || 'Garçom') + '</option><option value="caixa">Caixa</option><option value="gerente">Gerente</option></select></label><label class="campo">PIN<input type="password" inputmode="numeric" data-k="pin" autocomplete="new-password"></label>'; $('#a-users').appendChild(d); $('[data-k=nome]', d).focus(); };
  if (ID === 'setores') { c.querySelectorAll('[data-set]').forEach(b => b.onclick = () => b.classList.toggle('on')); c.querySelectorAll('[data-imp]').forEach(b => b.onclick = async () => { S.abaCad = 'setores'; await aoAvancar(); ir('cadastros'); }); }
  if (ID === 'pix') c.querySelectorAll('[data-forma]').forEach(b => b.onclick = () => { b.classList.toggle('on'); autosalvar(); });
  if (ID === 'rede') { const on = (id, fn) => { const b = $('#' + id); if (b) b.onclick = fn; }; on('a-fw', () => tentar(() => POST('/api/sistema/firewall'), 'Firewall liberado')); on('a-fwb', async () => { if (await tentar(() => POST('/api/sistema/firewall'), 'Pronto! Celulares e TV liberados')) render(); }); on('a-startup', () => tentar(() => POST('/api/sistema/iniciar-com-windows', { ativar: true }), 'Vai iniciar com o Windows')); on('a-atalho', () => tentar(() => POST('/api/sistema/atalho-area-trabalho'), 'Atalho criado')); }
  const irPasso = async (n) => { S.passoAssist = n; await PUT('/api/config', { assist_passo: String(n) }).catch(() => {}); render(); window.scrollTo(0, 0); };
  $('#as-sair').onclick = async () => { if (autosalvar) await autosalvar(); await PUT('/api/config', { assist_passo: String(passo) }).catch(() => {}); S.passoAssist = null; S.assistCompleto = false; ir('inicio'); };
  $('#as-prox').onclick = async () => { try { await aoAvancar(); } catch (e) { return toast(e.message, 'erro'); } if (passo === passos.length) { toast('Configuração concluída!', 'ok'); S.passoAssist = null; S.assistCompleto = false; await carregarBase(); return ir('inicio'); } irPasso(passo + 1); };
  const ant = $('#as-ant'); if (ant) ant.onclick = () => irPasso(passo - 1);
  c.querySelector('.passos-barra').onclick = async (e) => { const b = e.target.closest('[data-ps]'); if (b) { try { if (autosalvar) await autosalvar(); } catch {} irPasso(Number(b.dataset.ps)); } };
}

// ---------------- Ajuda ----------------
const COMPRA_AUTO = (window.PRODUTO || {}).slug === 'restaurante';   // MesaPronta: comprar pelo botão ativa a licença sozinha
const FAQ = [
  ['Começando', [
    ['Por onde começo?', 'Entre como gerente e use o assistente (Início → "Começar configuração" ou Configurações → Geral). Ele configura estabelecimento, ' + (R.mesas ? 'ambientes e mesas, cardápio, equipe, setores' : (T.produtos_plural || 'produtos') + ', equipe') + ', Pix e celulares em uns 10 minutos.'],
    R.mesas ? ['O que são os perfis Gerente, Caixa e Garçom?', 'Garçom: só a comanda no celular (abrir mesa, lançar itens, pedir conta). Caixa: mesas, balcão, delivery, receber, abrir/fechar caixa, estoque. Gerente: tudo, inclusive cancelar, descontos, relatórios, cadastros e configurações.']
      : [`O que são os perfis Gerente, Caixa e ${T.profissional || 'Equipe'}?`, `${T.profissional || 'Equipe'}: ${T.perfil_profissional || 'lança itens e acompanha o serviço'}. Caixa / recepção: atende, recebe, abre e fecha o caixa, estoque. Gerente: tudo, inclusive cancelar, descontos, relatórios, cadastros e configurações.`],
    ['Como troco os PINs de exemplo?', 'Cadastros → ' + (R.profissionais ? (T.equipe || 'Equipe') : 'Usuários') + ' → clique na pessoa → digite o novo PIN (4 a 6 números). Os PINs 1234/1111/2222 vêm com o sistema e todo mundo conhece — troque antes de usar de verdade.'],
    ['Posso treinar a equipe sem bagunçar as vendas?', 'Sim. Configurações → Rede → "Abrir modo treino" (ou, sem o app, o arquivo "Treinar (dados de teste)"). Ele abre uma cópia separada na porta 3001 com dados de mentira. Quando quiser, apague a pasta "dados-treino".'],
    ['O sistema avisa quando tem versão nova?', COMPRA_AUTO ? 'Sim, e se atualiza sozinho. Com internet, ele baixa a versão nova e instala quando ninguém estiver usando (leva alguns segundos e mantém vendas, cadastros e configurações). O gerente também pode clicar em "Atualizar agora" no Início.' : 'Sim. Quando há internet, ele consulta algumas vezes por dia se existe uma versão mais nova. Se houver, aparece um aviso uma vez, um lembrete na barra lateral e o botão "Baixar" em Configurações → Licença e atualizações. Baixe o programa novo e abra: ele atualiza sozinho mantendo vendas, cadastros e configurações.'],
    ['Quanto tempo dura o teste e como ativo?', 'O teste dura 7 dias. O contador aparece no Início e na barra lateral. ' + (COMPRA_AUTO ? 'Para continuar, clique em "Comprar agora" e pague com Pix ou cartão (até 12x): a licença ativa sozinha neste computador em até 2 minutos. Se você recebeu uma chave de ativação, cole em Configurações → Licença.' : 'Para ativar, envie o "Código deste computador" (Configurações → Licença) ao vendedor e cole a chave que receber.') + ' Nada do que você cadastrou se perde na ativação.'],
    ['Apareceu "Licença cancelada". E agora?', 'O vendedor cancelou a licença deste computador (normalmente por compra cancelada ou estornada). Fale com ele; se for engano, assim que ele liberar, clique em "Verificar de novo" na própria tela. O sistema não apaga seus dados.'],
    ['O sistema para de funcionar sem internet?', 'Não. Sem internet, tudo funciona normalmente neste computador e nos aparelhos do Wi-Fi local. ' + (COMPRA_AUTO ? 'A internet é usada para o cardápio online, a cópia de segurança dos dados, o acesso pelos celulares fora do Wi-Fi, a nota fiscal, as atualizações e a licença.' : 'A internet é usada para checar versão nova e a situação da licença.')],
    ['Como instalo em outro computador ou atualizo?', (COMPRA_AUTO ? 'Trocou de computador? Instale no computador novo e, na primeira tela, entre com o e-mail e a senha da sua conta: os dados (última cópia) e a licença vão junto. ' : '') + 'Abra o MesaPronta.exe baixado: ele instala sozinho (pasta de programas do usuário, atalho na área de trabalho e no menu Iniciar) e, se já existir uma versão instalada, atualiza mantendo vendas, cadastros e configurações. Para desinstalar: Configurações do Windows → Aplicativos → MesaPronta. Para usar sem instalar (pendrive), crie um arquivo vazio "portatil.txt" ao lado do .exe.'],
    ['Parei o assistente no meio. Perdi o que fiz?', 'Não. Cada passo é salvo na hora (aparece "✓ salvo"). Ao voltar em Início → "Continuar configuração" ele abre no passo em que você parou.'],
    ['Como apago os produtos e vendas de teste?', 'Configurações → Backup e sistema → Zona de perigo → "Zerar vendas" (mantém cadastros) ou "Zerar tudo". Pede o PIN do gerente e faz um backup antes.'],
    ['Preciso de internet?', 'Não para vender: tudo roda no seu computador e no Wi-Fi local. ' + (COMPRA_AUTO ? 'Com internet você ganha o cardápio online, a cópia de segurança dos dados, os celulares fora do Wi-Fi (4G) e as atualizações automáticas.' : 'A internet serve para o WhatsApp, as atualizações e a licença.')],
  ]],
  ['Mesas, PDV e transferências', [
    ['Cliquei na mesa e ela ficou ocupada?', 'Não mais: ao clicar numa mesa livre o sistema pergunta "Abrir a mesa?" e quantas pessoas. A mesa só fica ocupada depois de confirmar. Mesa já ocupada abre a comanda direto.'],
    ['Como transfiro uma conta de mesa ou junto duas mesas?', 'Em Mesas, botão "⇄ Transferir / juntar mesas": escolha a mesa de origem e depois a de destino. Destino livre = a conta muda de mesa. Destino ocupado = as duas contas viram uma só (os itens vão para a mesa de destino). Dá para transferir só alguns itens. O mesmo botão existe dentro da comanda.'],
    ['O que é o PDV?', 'A tela "PDV (fechar contas)" (F5) mostra todas as contas em andamento com o total, o que já está pronto/entregue, quem pediu a conta, as contas fechadas hoje e o faturamento previsto (faturado + em aberto). É o lugar mais rápido para receber: clique em "Receber" no cartão da conta.'],
    ['Onde ficam todos os QR Codes?', 'Menu "QR Codes" (abre a página /qrcodes): garçom, cozinha, caixa em outro aparelho, painel de senhas, visor e o QR de cada mesa. Dá para imprimir a página inteira. Para plaquinhas bonitas de recortar, use "Plaquinhas".'],
    ['O alarme da cozinha fica tocando sem parar', 'Ele repete (uma versão curta, a cada 30 s) só enquanto existir pedido em "Aguardando" que ninguém tocou. Clicar no cartão, em "Começar" ou em "Pronto" para o alarme daquele pedido. Na tela da cozinha dá para escolher o toque (campainha, sino, xilofone, alarme forte, bipe) e testar. Para nunca repetir: Configurações → Geral → cozinha.'],
  ]],
  ['Mesas e pedidos', [
    ['Como lanço um pedido numa mesa?', 'Clique na mesa → toque nos produtos → "Enviar para a cozinha" (F10). No celular do garçom é igual. Itens enviados aparecem na cozinha e no visor do cliente.'],
    ['Como marco de quem é cada item (dividir por pessoa)?', 'Com a mesa em 2+ pessoas (botão 👥), aparece um botão 👤 em cada item. Clique para alternar entre pessoa 1, 2, 3... ou 👥 (compartilhado). No pagamento, "Conta por pessoa" mostra o total de cada um e imprime a conferência individual.'],
    ['Como divido a conta igualmente?', 'No pagamento, use "Dividir por" (−/+). O sistema sugere o valor por pessoa e você vai recebendo um por um, em formas diferentes se quiser.'],
    ['Como transfiro ou junto mesas?', 'Abra a mesa → "Transferir / juntar" → escolha a mesa inteira ou só alguns itens → clique na mesa de destino. Se a destino estiver ocupada, os itens se juntam.'],
    ['Como cancelo um item?', 'Clique no ✕ do item. Precisa do PIN de um gerente e do motivo. Se o item tinha estoque, volta. Fica registrado em Relatórios → Itens cancelados.'],
    ['Cliente desistiu da mesa toda', 'Abra a mesa → "Cancelar pedido" (PIN do gerente e motivo). Se a mesa estava vazia, cancela direto.'],
    ['O que é a taxa de serviço e a gorjeta?', 'Serviço: os 10% (configurável) somados automaticamente nas mesas; pode ser desmarcado no pagamento. Gorjeta: valor extra que o cliente dá, lançado no pagamento ("Gorjeta ✎"). Os dois aparecem no relatório por garçom.'],
    ['Para que serve o Balcão?', 'Venda sem mesa: cliente pede, paga e leva (lanchonete, açaí, pastelaria). O número do pedido aparece no painel de senhas quando a cozinha marca "Pronto".'],
    ['O que é comanda numerada?', 'O cartão que o cliente recebe na entrada (bares, choperias). Em Balcão → "Abrir comanda" digite o número; o garçom também abre pelo celular (botão 🎫). Tudo vai sendo lançado; na saída, abre pelo número e recebe.'],
    ['Como funciona a fila de espera?', 'Mesas → Fila de espera → "+ Adicionar". Quando liberar, "Chamar" (pode avisar por WhatsApp) e "Sentar" escolhendo a mesa.'],
    ['Como faço uma reserva?', 'Mesas → Reservas → "+ Reservar": nome, pessoas, data, hora e (opcional) mesa. No dia, aparece na lista; "Chegou → sentar" abre a mesa já com o nome.'],
  ]],
  ['Cardápio e pizzas', [
    ['Como cadastro pizzas com meio a meio?', 'Cadastros → Categorias → crie "Pizzas" marcando "permite meio a meio". Depois cadastre cada sabor como produto dessa categoria, com os tamanhos (P/M/G) e preços. O sistema cria sozinho o botão "Montar pizza": tamanho → 1 ou 2 sabores → sabores → borda.'],
    ['Meio a meio cobra qual preço?', 'Configurações → Geral → Cardápio: "o sabor mais caro" ou "a média dos dois".'],
    ['Como ponho foto no produto?', 'Cadastros → Produtos → clique no produto → "Escolher / tirar foto". No celular do gerente abre a câmera. Ou "Imagem do catálogo" para usar as ilustrações prontas.'],
    ['Como adiciono as bebidas rapidinho?', 'Cadastros → Produtos → "Catálogo de bebidas": marque as que vende, ajuste o preço e adicione. Vêm com imagem.'],
    ['O que são observações rápidas?', 'Bolinhas que o garçom toca na hora do pedido ("Sem cebola", "Bem passado"). Por categoria (Cadastros → Categorias) ou gerais (Configurações → Geral → Cardápio). Digite a palavra e aperte Enter.'],
    ['Produto acabou. E agora?', 'No pedido, clique no ⊘ do produto; ou Estoque → "Esgotado". Ele some do cardápio do cliente e avisa o garçom. Para voltar, clique de novo.'],
    ['Como faço promoção / happy hour?', 'No produto → "Promoção / happy hour": preço promocional, horário e dias da semana. No horário, o preço muda sozinho e aparece a etiqueta PROMO.'],
    ['Como importo meu cardápio do Excel?', 'Cadastros → Produtos → "Importar de planilha". Monte as colunas código; nome; categoria; setor; preço; custo, copie e cole. Categorias e setores novos são criados.'],
  ]],
  ['Pagamento e caixa', [
    ['Como recebo em Pix?', 'Configure a chave em Configurações → Pix e salve. No pedido, "QR Pix na tela" (ou no pagamento, forma Pix → "Mostrar QR"). O cliente escaneia; confira no app do banco e lance o pagamento.'],
    ['Posso receber parte em dinheiro e parte no cartão?', 'Sim. Lance um pagamento de cada vez com a forma e o valor. O sistema mostra quanto falta. Troco só em dinheiro.'],
    ['Como dou desconto?', 'No pagamento → "Desconto ✎" (valor ou %). Pede PIN do gerente, a não ser que Configurações → Geral → Caixa permita um % sem PIN.'],
    ['Como vendo fiado?', 'No pagamento escolha "Fiado (a prazo)", informe o nome e confirme com PIN do gerente. Depois, Caixa → aba "Fiado / a receber" para cobrar (WhatsApp) e receber.'],
    ['Lancei o pagamento errado', 'No pagamento, clique no ✕ ao lado do pagamento para estornar (PIN do gerente). Só funciona enquanto o caixa daquele dia estiver aberto.'],
    ['Como abro e fecho o caixa?', 'Caixa → "Abrir caixa" com o fundo de troco. Durante o dia: sangria (retirada) e suprimento (entrada). No fim: "Fechar caixa", conte e digite por forma; a diferença aparece. Imprime o relatório e faz backup.'],
    ['O que é fechamento cego?', 'O operador conta o dinheiro sem ver quanto o sistema espera; só depois vê a diferença. Evita "ajustar" a contagem. Ligue em Configurações → Geral → Caixa.'],
    ['O caixa não bateu. O que olhar?', 'Relatórios → Itens cancelados e Descontos; Caixa → movimentos (sangrias); vendas fiado (não entram na gaveta); troco dado errado. O histórico de caixas mostra esperado × contado por forma.'],
    ['O sistema caiu e vendi no papel', 'Pedidos → "Lançar venda manual": tipo, data/hora, itens (pode digitar qualquer coisa), forma de pagamento. Entra nos relatórios e no caixa atual marcado como ✍️ manual.'],
    R.nota_fiscal ? ['Emite nota fiscal?', 'Sim, com o módulo opcional de nota fiscal (NFC-e), no menu "Notas fiscais" (assinatura mensal, até 100 notas no mês). Precisa de CNPJ com inscrição estadual e certificado digital A1. Sem o módulo, os cupons são "conferência" e "cupom não fiscal".']
      : ['Emite nota fiscal?', 'Não. O sistema é não fiscal: os cupons são "conferência" e "cupom não fiscal". Para NFC-e é preciso certificado digital e integração com a SEFAZ.'],
  ]],
  ['Delivery', [
    ['Como lanço um delivery?', 'Delivery → "+ Novo delivery". Digite o telefone: se o cliente já comprou, aparece com endereço e "Repetir último pedido". Escolha o bairro (taxa automática), troco e agendamento.'],
    ['Como aviso o cliente que saiu para entrega?', 'No quadro, "Saiu para entrega →" escolhe o entregador e oferece mandar WhatsApp com mensagem pronta. No pedido também há o botão WhatsApp.'],
    ['Como cadastro bairros e taxas?', 'Cadastros → Bairros e taxas. Entregadores em Cadastros → Entregadores. O relatório mostra entregas por bairro e por entregador.'],
  ]],
  ['Cozinha', [
    ['Como funciona a tela da cozinha?', 'Abra /cozinha numa TV, tablet ou PC (QR em Configurações → Rede). Três colunas: Aguardando → Preparando → Pronto. "Começar" move para preparando; "Pronto" avisa o garçom e o painel de senhas. Toque num item para marcá-lo pronto sozinho.'],
    ['A cozinha não ouve o alerta', 'Na tela da cozinha, o botão 🔔 precisa estar "Som ligado" (o navegador exige um toque na tela antes de tocar som). Em Configurações → Geral → Cozinha, ligue "repetir o alerta" e "anunciar por voz". Toque no aviso vermelho para confirmar que viu.'],
    ['Pedido fica vermelho na cozinha', 'Passou do tempo de "atrasado" (Configurações → Geral → Cozinha). Amarelo é o alerta. Os tempos valem para o relatório de tempo médio.'],
    ['Cada setor vê só o seu?', 'Sim: na tela da cozinha escolha o setor (Cozinha, Bar...). Cada produto pertence a um setor (Cadastros → Produtos).'],
    ['Impressora da cozinha não imprime', 'Configurações → Impressoras → "Impressoras da cozinha e do bar" → "Imprimir teste" no setor. Térmica de rede: confira o IP (porta 9100). USB: escolha "Impressora instalada no Windows" e a impressora na lista (se não aparecer, instale o driver dela no Windows e clique em "Atualizar lista"). "Pelo navegador": o PC do caixa precisa estar marcado como estação de impressão (Configurações → Rede).'],
  ]],
  ['Estoque', [
    ['Como dou entrada de mercadoria?', 'Estoque → "Entrada de mercadoria": digite o nome (se não existir, cria na hora, inclusive insumos como farinha ou embalagem), quantidade, custo unitário e nota. O custo alimenta o relatório de lucro.'],
    ['Como corrijo o saldo?', 'Estoque → clique no número do saldo → "Contagem": informe o saldo real. Perdas e quebras: "− Perda".'],
    ['Como recebo aviso de estoque baixo?', 'Clique no "Mínimo" do produto e defina. Abaixo disso, fica vermelho e aparece no Início.'],
  ]],
  ['Celulares, rede e aplicativo', [
    ['O celular não abre o sistema', '1) Celular e PC no MESMO Wi-Fi. 2) Configurações → Rede → "Liberar celulares no firewall". 3) No roteador, desligue "isolamento de clientes". 4) Confira se o endereço (http://192.168...) é o mesmo mostrado em Configurações → Rede.'],
    ['O endereço mudou e os QR pararam', R.mesas ? 'O roteador deu outro IP ao PC. Fixe o IP (reserva DHCP no roteador) ou reimprima as plaquinhas. O QR dos garçons está em Configurações → Rede.' : 'O roteador deu outro IP ao PC. Fixe o IP (reserva DHCP no roteador) e escaneie de novo os QR em Configurações → Rede (ou na página QR Codes).'],
    ['Como deixo o sistema como app no celular?', 'Abra o endereço no Safari (iPhone) ou Chrome (Android) → menu → "Adicionar à tela de início". Vira um ícone, sem loja de apps.'],
    ['Posso usar o caixa em dois computadores?', 'Sim. Abra o endereço do PC principal no outro (ou tablet). Só um precisa ser a "estação de impressão".'],
    ['Como faço o MesaPronta abrir sozinho quando ligo o PC?', 'Configurações → Rede → "Iniciar junto com o Windows".'],
    ['Visor do cliente e painel de senhas', 'Visor: um monitor virado para o cliente abrindo /visor (mostra pedido, total e QR Pix). Painel: TV no balcão abrindo /painel (Preparando / Pronto). Dê dois cliques para tela cheia.'],
  ]],
  ['Licença, backup e suporte', [
    ['Como ativo a licença?', COMPRA_AUTO ? 'Clique em "Comprar agora" (Pix ou cartão): a licença ativa sozinha e fica ligada à sua conta. Trocou de computador? No computador novo, entre com o e-mail e a senha da conta e a licença vai junto. Recebeu uma chave? Cole em Configurações → Licença.' : 'Configurações → Licença: copie o código do computador, mande para o vendedor e cole a chave recebida. Vale só para esse PC. Trocou de PC, peça outra chave.'],
    ['Onde fica o backup?', 'Pasta dados/backups, automático todo dia e a cada fechamento. Configurações → Backup → "Baixar backup" para guardar no pendrive ou nuvem. Para restaurar, veja o LEIA-ME.'],
    ['Perdi o PIN do gerente', 'Outro gerente pode trocar em Cadastros → ' + (R.profissionais ? (T.equipe || 'Equipe') : 'Usuários') + '. Se não houver outro, fale com o suporte com o código do computador.'],
    ['Como falo com o suporte?', 'Botão "Falar com o suporte" no topo desta tela (se o número estiver configurado em Configurações → Backup e sistema).'],
  ]],
];
// FAQ conforme o produto: temas de restaurante saem quando o recurso está desligado; o produto acrescenta os seus
function faqDoProduto() {
  const FLAG_TEMA = { 'Mesas, PDV e transferências': 'mesas', 'Mesas e pedidos': 'mesas', 'Cardápio e pizzas': 'pizza', 'Delivery': 'delivery', 'Cozinha': 'cozinha', 'Estoque': 'estoque' };
  let base = FAQ.filter(([g]) => !FLAG_TEMA[g] || R[FLAG_TEMA[g]] !== false);
  if (!R.mesas) base = base.map(([g, it]) => [g, it.filter(([t]) => !/mesa|garçom|garcom|cozinha|cardápio digital|pizza|delivery|comanda/i.test(t))]).filter(([, it]) => it.length);
  const out = [...base];
  for (const grupo of (window.PRODUTO_FAQ || [])) { const i = out.findIndex(([g]) => g === grupo[0]); if (i >= 0) out[i] = [grupo[0], [...grupo[1], ...out[i][1]]]; else out.splice(1, 0, grupo); }
  return out;
}
// ---------------- Aulas em vídeo (YouTube) ----------------
const AULAS = () => (R.aulas ? PR.aulas.lista : []);
const aulaDaTela = (view) => { const v = view === 'editor' ? (S.voltar === 'mesas' ? 'mesas' : S.voltar === 'delivery' ? 'delivery' : S.voltar === 'balcao' ? 'balcao' : 'editor') : view; const i = AULAS().findIndex(a => (a[2] || []).includes(v)); return i; };
function botaoAulaDaTela() {
  const b = $('#mp-aula'); if (!b) return;
  const i = R.aulas && S.view !== 'aulas' && S.view !== 'editor' ? aulaDaTela(S.view) : -1;
  b.hidden = i < 0;
  if (i >= 0) { b.title = `Assistir: Aula ${String(i + 1).padStart(2, '0')} — ${AULAS()[i][1]}`; b.onclick = () => abrirAula(i); }
}
const capaAula = (id) => `https://i.ytimg.com/vi/${id}/mqdefault.jpg`;
// capa desenhada (no estilo das miniaturas do canal) — aparece sem internet; com internet a miniatura do YouTube cobre por cima
function capaSvg(i) {
  const a = AULAS()[i]; if (!a) return '';
  const n = String(i + 1).padStart(2, '0');
  const pal = a[1].split(' '); const linhas = []; let l = '';
  for (const w of pal) { if ((l + ' ' + w).trim().length > 16 && l) { linhas.push(l); l = w; } else l = (l + ' ' + w).trim(); }
  if (l) linhas.push(l);
  const tx = linhas.slice(0, 3).map((t, k) => `<text x="22" y="${92 + k * 30}" font-size="26" font-weight="800" fill="#fff" font-family="Inter,Segoe UI,Arial,sans-serif">${esc(t)}</text>`).join('');
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 180"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#16244a"/><stop offset="1" stop-color="#2c4bb8"/></linearGradient></defs>
    <rect width="320" height="180" fill="url(#g)"/><circle cx="270" cy="70" r="70" fill="#ffffff" opacity=".06"/><circle cx="270" cy="70" r="44" fill="#ffffff" opacity=".06"/>
    <rect x="22" y="22" width="78" height="26" rx="6" fill="#ff7a59"/><text x="61" y="40" text-anchor="middle" font-size="14" font-weight="800" fill="#fff" font-family="Inter,Segoe UI,Arial,sans-serif">AULA ${n}</text>${tx}
    <rect y="156" width="320" height="24" fill="#ffd43b"/><text x="160" y="172" text-anchor="middle" font-size="10.5" font-weight="800" fill="#16244a" letter-spacing=".5" font-family="Inter,Segoe UI,Arial,sans-serif">SISTEMA PARA RESTAURANTE · PASSO A PASSO</text></svg>`;
  return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
}
const capaHtml = (i, soDesenho) => { const a = AULAS()[i]; return `<span class="aula-capa"><img class="capa-base" src="${capaSvg(i)}" alt="">${soDesenho || navigator.onLine === false ? '' : `<img class="capa-yt" src="${capaAula(a[0])}" alt="" loading="lazy" onerror="this.remove()">`}<span class="aula-play">▶</span></span>`; };
// primeira vez numa tela: um cartão no canto oferecendo a aula (uma vez por tela, neste aparelho)
const lsGet = (k) => { try { return localStorage.getItem(k); } catch { return null; } };
const lsSet = (k, v) => { try { localStorage.setItem(k, v); } catch {} };
// cardápio colocado pelo suporte (a partir da foto que o cliente mandou): aviso no Início e em Cadastros, com Desfazer
function inserirAvisoCardapio(c) {
  if (!c || !['inicio', 'cadastros'].includes(S.view) || !pode('gerente') || $('#mp-card-sup', c)) return;
  let reg = null; try { reg = JSON.parse((S.cfg && S.cfg.cardapio_suporte_ultimo) || 'null'); } catch {}
  if (!reg || reg.desfeito || reg.origem !== 'suporte' || lsGet('mp_card_sup_visto') === reg.quando) return;
  if (Date.now() - new Date(String(reg.quando).replace(' ', 'T')).getTime() > 14 * 864e5) return;
  const r = reg.resumo || {};
  const d = document.createElement('div'); d.id = 'mp-card-sup'; d.className = 'card pad mp-card-sup';
  d.innerHTML = `<div class="cs-ic">✓</div><div class="cs-txt"><b>O suporte colocou o seu cardápio</b><div class="small muted">${r.produtos || 0} produto(s) em ${r.categorias || 0} categoria(s)${r.adicionais ? ` e ${r.adicionais} adicional(is)` : ''}, a partir da foto que você mandou (${esc(dataHoraBR(reg.quando))}). Os produtos de exemplo saíram. Confira os preços e, se algo estiver errado, é só editar.</div>
    <div class="row wrap" style="gap:8px;margin-top:8px"><button class="btn primary sm" data-cs="ver">Ver os produtos</button><button class="btn sm" data-cs="ok">Está certo</button><button class="btn sm ghost danger" data-cs="desfazer">Desfazer</button></div></div>`;
  d.onclick = async (e) => {
    const b = e.target.closest('[data-cs]'); if (!b) return; e.stopPropagation();
    if (b.dataset.cs === 'ver') { S.abaCad = 'produtos'; return ir('cadastros'); }
    if (b.dataset.cs === 'ok') { lsSet('mp_card_sup_visto', reg.quando); d.remove(); return; }
    if (!(await confirmar('Desfazer o cardápio do suporte', 'Os produtos que o suporte colocou saem e o cardápio volta a ser como era antes. As vendas já feitas não mudam.', 'Desfazer', 'danger solid'))) return;
    await tentar(() => POST('/api/cad/cardapio/desfazer'), 'Cardápio desfeito');
    S.cfg = await GET('/api/config'); S.cardapio = await GET('/api/cardapio').catch(() => S.cardapio); render();
  };
  const cab = c.querySelector(':scope > .cab'); if (cab) cab.after(d); else c.prepend(d);
}
// localização do restaurante marcada pelo suporte (frete por km): aviso no Início e no Cardápio online, com Desfazer
function inserirAvisoLocalizacao(c) {
  if (!c || !['inicio', 'cardapio-online'].includes(S.view) || !pode('gerente') || $('#mp-loc-sup', c)) return;
  let reg = null; try { reg = JSON.parse((S.cfg && S.cfg.localizacao_suporte_ultima) || 'null'); } catch {}
  if (!reg || reg.desfeito || reg.origem !== 'suporte' || lsGet('mp_loc_sup_visto') === reg.quando) return;
  if (Date.now() - new Date(String(reg.quando).replace(' ', 'T')).getTime() > 14 * 864e5) return;
  const mapa = `https://www.google.com/maps?q=${reg.lat},${reg.lng}`;
  const d = document.createElement('div'); d.id = 'mp-loc-sup'; d.className = 'card pad mp-card-sup';
  d.innerHTML = `<div class="cs-ic">📍</div><div class="cs-txt"><b>O suporte marcou a localização do seu restaurante</b><div class="small muted">É o ponto usado para calcular a taxa de entrega por distância (${esc(dataHoraBR(reg.quando))}). Confira no mapa se está na porta da loja.</div>
    <div class="row wrap" style="gap:8px;margin-top:8px"><a class="btn primary sm" href="${mapa}" target="_blank" rel="noopener">Conferir no mapa ↗</a><button class="btn sm" data-ls="ok">Está certo</button><button class="btn sm ghost danger" data-ls="desfazer">Desfazer</button></div></div>`;
  d.onclick = async (e) => {
    const b = e.target.closest('[data-ls]'); if (!b) return; e.stopPropagation();
    if (b.dataset.ls === 'ok') { lsSet('mp_loc_sup_visto', reg.quando); d.remove(); return; }
    if (!(await confirmar('Desfazer a localização do suporte', 'A localização do restaurante volta a ser a que estava antes.', 'Desfazer', 'danger solid'))) return;
    await tentar(() => POST('/api/cfg/localizacao-suporte/desfazer'), 'Localização desfeita');
    S.cfg = await GET('/api/config'); render();
  };
  const ant = $('#mp-card-sup', c) || c.querySelector(':scope > .cab'); if (ant) ant.after(d); else c.prepend(d);
}
function fecharDicaAula() { S.dicaAula = null; const d = $('#mp-aula-dica'); if (d) d.remove(); }
// primeira vez numa tela: um aviso no topo da página (não cobre nada) oferecendo a aula — uma vez por tela, neste aparelho
function dicaPrimeiraVez() {
  if (S.dicaAula && S.dicaAula !== S.view) fecharDicaAula();
  if (!R.aulas || S.view === 'aulas' || S.view === 'editor' || S.view === 'assistente') return;
  if ((window.Tour && Tour.ativo) || lsGet('mp_aulas_dicas') === 'off') return;
  if (aulaDaTela(S.view) < 0) return;
  const k = 'mp_aula_vista_' + S.view; if (lsGet(k)) return;
  lsSet(k, '1');
  S.dicaAula = S.view;
  inserirDicaAula($('#conteudo'));
}
function inserirDicaAula(c) {
  if (!c || !S.dicaAula || S.dicaAula !== S.view || $('#mp-aula-dica', c)) return;
  const i = aulaDaTela(S.view); if (i < 0) return;
  const a = AULAS()[i]; const nomeTela = (MENU.find(m => m.id === S.view) || {}).nome || 'esta tela';
  const d = document.createElement('div'); d.id = 'mp-aula-dica'; d.className = 'mp-aula-dica';
  d.innerHTML = `<button class="dica-capa" data-dica="ver" aria-label="Assistir">${capaHtml(i, true)}</button>
    <div class="dica-txt"><div class="dica-topo">👋 Primeira vez em <b>${esc(nomeTela)}</b>? Veja como usar em vídeo.</div><div class="dica-tit">Aula ${String(i + 1).padStart(2, '0')} — ${esc(a[1])}</div>
    <div class="row wrap" style="gap:8px;margin-top:8px;align-items:center"><button class="btn primary sm" data-dica="ver">▶ Assistir agora</button><button class="btn sm" data-dica="fechar">Agora não</button><button class="dica-off" data-dica="off">Não mostrar mais essas dicas</button></div></div>
    <button class="dica-x" data-dica="fechar" aria-label="Fechar">✕</button>`;
  d.onclick = (e) => { const b = e.target.closest('[data-dica]'); if (!b) return; e.stopPropagation(); const ac = b.dataset.dica; fecharDicaAula(); if (ac === 'ver') abrirAula(i); if (ac === 'off') { lsSet('mp_aulas_dicas', 'off'); toast('Tudo bem. As aulas continuam no botão ▶ do canto e no menu "Aulas em vídeo".', 'ok'); } };
  const cab = c.querySelector(':scope > .cab'); if (cab) cab.after(d); else c.prepend(d);
}
function abrirAula(i) {
  fecharDicaAula();
  const L = AULAS(); const a = L[i]; if (!a) return;
  const n = String(i + 1).padStart(2, '0');
  const semNet = navigator.onLine === false;
  const prox = L[i + 1];
  return modal({ titulo: `Aula ${n} — ${a[1]}`, largo: true, corpo: html`<div class="stack">
      ${semNet ? html`<div class="card pad alerta-card" style="box-shadow:none">Sem internet agora. O sistema funciona normalmente, mas para assistir à aula este aparelho precisa estar conectado.</div>` : ''}
      <div class="aula-player"><iframe src="https://www.youtube-nocookie.com/embed/${a[0]}?autoplay=1&rel=0&modestbranding=1&cc_load_policy=1&cc_lang_pref=pt" title="${a[1]}" allow="autoplay; encrypted-media; picture-in-picture; fullscreen" allowfullscreen referrerpolicy="strict-origin-when-cross-origin"></iframe></div>
      <div class="small muted">Se o vídeo não abrir aqui, <a href="https://www.youtube.com/watch?v=${a[0]}&list=${PR.aulas.playlist}" target="_blank" rel="noopener">assista no YouTube</a>.</div></div>`.s,
    botoes: [...(i > 0 ? [{ texto: '← Aula anterior', acao: () => { setTimeout(() => abrirAula(i - 1), 0); return true; } }] : []), { texto: 'Todas as aulas', acao: () => { setTimeout(() => ir('aulas'), 0); return true; } },
      ...(prox ? [{ texto: `Próxima: ${prox[1]} →`, classe: 'primary', acao: () => { setTimeout(() => abrirAula(i + 1), 0); return true; } }] : [{ texto: 'Fechar', classe: 'primary', padrao: true }])] });
}
async function vAulas(c) {
  const L = AULAS();
  const semNet = navigator.onLine === false;
  c.innerHTML = html`<div class="cab"><div><span class="mp-page-label">Aprenda a usar</span><h1>Aulas em vídeo</h1></div><span class="muted">${L.length} aulas, do começo ao fim</span><span class="spacer"></span>
      <a class="btn" target="_blank" rel="noopener" href="https://www.youtube.com/playlist?list=${PR.aulas.playlist}">Abrir no YouTube ↗</a><button class="btn" id="au-ajuda">Perguntas e respostas</button></div>
    ${semNet ? html`<div class="card pad alerta-card" style="box-shadow:none;margin-bottom:12px">Sem internet agora. O sistema funciona normalmente, mas os vídeos precisam de internet para tocar.</div>` : ''}
    <p class="muted" style="margin:0 0 14px">Clique numa aula para assistir aqui mesmo. Em cada tela do sistema, o botão <b>▶ Aula desta tela</b> (no canto de baixo) abre a aula daquele assunto.</p>
    <div class="aulas-grade">${L.map((a, i) => html`<button class="card aula-card" data-aula="${i}">${raw(capaHtml(i))}
      <span class="aula-txt"><span class="small muted">Aula ${String(i + 1).padStart(2, '0')}</span><b>${a[1]}</b></span></button>`)}</div>`;
  $('#au-ajuda').onclick = () => ir('ajuda');
  c.onclick = (e) => { const b = e.target.closest('[data-aula]'); if (b) abrirAula(Number(b.dataset.aula)); };
}
async function vAjuda(c) {
  const lic = S.licenca || {};
  const zap = S.cfg.suporte_whatsapp || lic.vendedor_whatsapp;
  const q = (S.buscaAjuda || '').toLowerCase();
  const FAQP = faqDoProduto();
  const grupos = FAQP.map(([g, itens]) => [g, itens.filter(([t, d]) => !q || (t + ' ' + d).toLowerCase().includes(q))]).filter(([, it]) => it.length);
  c.innerHTML = html`<div class="cab"><h1>Ajuda</h1><span class="muted">${FAQP.reduce((n, [, it]) => n + it.length, 0)} perguntas</span><span class="spacer"></span>${zap ? html`<span class="muted small">Suporte: <b>${telefoneSuporte()}</b></span><a class="btn primary" target="_blank" href="${linkWhatsApp(zap, `Olá! Preciso de ajuda com o MesaPronta (${S.cfg.nome_estabelecimento}, código ${lic.codigo_maquina || ''}).`)}">💬 Falar com o suporte</a>` : ''}<button class="btn" id="aj-atalhos">Atalhos</button>${pode('gerente') ? html`<button class="btn" id="aj-assist">🧭 Assistente</button>` : ''}</div>
    ${R.aulas ? html`<div class="card pad aulas-banner"><div><b>▶ Aulas em vídeo</b><div class="small muted">${PR.aulas.lista.length} aulas curtas mostrando como usar cada parte do sistema, passo a passo.</div></div><span class="spacer"></span><button class="btn primary" id="aj-aulas">Ver as aulas</button></div>` : ''}
    <input type="text" class="faq-busca" id="aj-q" placeholder="Buscar na ajuda... (ex.: ${R.mesas ? 'pix, meio a meio, firewall' : 'pix, licença, firewall'})" value="${S.buscaAjuda || ''}">
    <div class="rel-grid" style="margin-top:14px">${grupos.map(([g, itens]) => html`<div class="card pad faq"><h3 style="padding:0 0 6px">${g}</h3>${itens.map(([t, d]) => html`<details ${q ? raw('open') : ''}><summary>${t}</summary><div class="resp">${d}</div></details>`)}</div>`)}</div>
    ${grupos.length ? '' : html`<div class="vazio">Nada encontrado. Tente outra palavra${zap ? ' ou fale com o suporte' : ''}.</div>`}
    <p class="muted small" style="margin-top:14px">O ${esc((window.PRODUTO || {}).nome || 'MesaPronta')} funciona sem internet.${R.nota_fiscal ? ' Nota fiscal (NFC-e): módulo opcional no menu "Notas fiscais".' : ' Não emite nota fiscal.'} Versão ${S.licenca?.versao || ''}</p>`;
  $('#aj-atalhos').onclick = mostrarAtalhos;
  const aa = $('#aj-aulas'); if (aa) aa.onclick = () => ir('aulas');
  const as = $('#aj-assist'); if (as) as.onclick = () => { S.passoAssist = null; ir('assistente'); };
  $('#aj-q').oninput = adiar((e) => { S.buscaAjuda = e.target.value; render().then(() => { const i = $('#aj-q'); if (i) { i.focus(); i.setSelectionRange(i.value.length, i.value.length); } }); }, 250);
}

iniciar();
