'use strict';
// Cardápio do cliente (mesa e delivery): peças visuais, folhas, escolha de produto e animações.
// Usa as utilidades de /js/comum.js (html, esc, raw, brl, $, $$, arteSvg, toast, vibrar).
const MC = (() => {
  const reduz = () => { try { return matchMedia('(prefers-reduced-motion: reduce)').matches; } catch { return false; } };
  const IC = {
    busca: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
    x: '<path d="M18 6 6 18M6 6l12 12"/>',
    mais: '<path d="M12 5v14M5 12h14"/>',
    menos: '<path d="M5 12h14"/>',
    lixo: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-12M9 7V4h6v3"/>',
    sacola: '<path d="M6 7h12l1 13H5L6 7Z"/><path d="M9 10V6a3 3 0 0 1 6 0v4"/>',
    moto: '<circle cx="6" cy="17" r="3"/><circle cx="18" cy="17" r="3"/><path d="M6 17h6l3-6h-4M15 11l3 6M13 7h3l2 4"/>',
    relogio: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    pino: '<path d="M12 21s-7-6.2-7-11a7 7 0 0 1 14 0c0 4.8-7 11-7 11Z"/><circle cx="12" cy="10" r="2.5"/>',
    sino: '<path d="M6 16v-5a6 6 0 0 1 12 0v5l2 2H4l2-2ZM10 20a2 2 0 0 0 4 0"/>',
    conta: '<path d="M6 3h12v18l-3-2-3 2-3-2-3 2V3Z"/><path d="M9 8h6M9 12h6M9 16h3"/>',
    zap: '<path d="M20 12a8 8 0 0 1-11.6 7.1L4 20l1-4.3A8 8 0 1 1 20 12Z"/><path d="M9 9.5c0 3 2.5 5.5 5.5 5.5"/>',
    compartilhar: '<path d="M12 3v12M7 8l5-5 5 5"/><path d="M5 13v6h14v-6"/>',
    check: '<path d="m5 12.5 4.5 4.5L19 7"/>',
    voltar: '<path d="M15 18 9 12l6-6"/>',
    seta: '<path d="m9 6 6 6-6 6"/>',
    estrela: '<path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1 6.2L12 17.3 6.5 20.2l1-6.2L3 9.6l6.2-.9L12 3Z"/>',
    fogo: '<path d="M12 21c4 0 7-2.7 7-6.6 0-3.3-2-5.4-3.4-7.1-.4 2-1.5 3-2.6 3.4.3-3-1-5.7-4-7.7.3 3-1.8 5.1-3.3 7C4.6 11.6 5 13 5 14.4 5 18.3 8 21 12 21Z"/>',
    loja: '<path d="M4 10v10h16V10M3 10l2-6h14l2 6M3 10a3 3 0 0 0 6 0 3 3 0 0 0 6 0 3 3 0 0 0 6 0"/>',
    pix: '<path d="m12 3 9 9-9 9-9-9 9-9Z"/><path d="m8.5 12 3.5-3.5 3.5 3.5-3.5 3.5L8.5 12Z"/>',
    cartao: '<rect x="3" y="5" width="18" height="14" rx="3"/><path d="M3 10h18M7 15h3"/>',
    dinheiro: '<rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="2.5"/><path d="M6 9v.01M18 15v.01"/>',
    tag: '<path d="M3 12V4h8l10 10-8 8L3 12Z"/><circle cx="7.5" cy="7.5" r="1.5"/>',
    pessoa: '<circle cx="12" cy="7" r="3.5"/><path d="M5 21a7 7 0 0 1 14 0"/>',
    nota: '<path d="M5 4h14v16H5z"/><path d="M8 8h8M8 12h8M8 16h5"/>',
    camera: '<path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/>',
    qr: '<path d="M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4z"/><path d="M14 14h2v2h-2zM18 14h2M14 18h2v2M18 18h2v2h-2"/>',
  };
  const ic = (n, extra = '') => raw(`<svg class="i ${extra}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${IC[n] || ''}</svg>`);

  // ---------- cor e tema do restaurante ----------
  function contraste(hex) {
    const n = parseInt(String(hex).slice(1), 16), r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
    const l = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
    return l > 0.68 ? '#141414' : '#ffffff';
  }
  function aplicarMarca({ cor, tema }) {
    const r = document.documentElement;
    const c = /^#[0-9a-f]{6}$/i.test(cor || '') ? cor : '#e3262f';
    r.style.setProperty('--c', c); r.style.setProperty('--c-txt', contraste(c));
    r.dataset.mcTema = tema === 'escuro' ? 'escuro' : 'claro';
    const m = document.querySelector('meta[name=theme-color]'); if (m) m.content = c;
  }

  // ---------- fotos e desenhos ----------
  const arte = (nome, cat) => raw(`<span class="arte">${typeof arteSvg === 'function' ? arteSvg(nome, cat) : ''}</span>`);
  const imgOuArte = (foto, nome, cat) => foto ? raw(`<img src="${esc(foto)}" alt="${esc(nome)}" loading="lazy" decoding="async">`) : arte(nome, cat);
  const iniciais = (nome) => String(nome || '?').trim().split(/\s+/).slice(0, 2).map(x => x[0] || '').join('').toUpperCase();

  // ---------- preços ----------
  const precoBase = (p, tam) => tam ? (p.tamanhos.find(t => t.nome === tam)?.preco ?? p.preco) : p.preco;
  const aPartir = (p) => p.tamanhos && p.tamanhos.length ? Math.min(...p.tamanhos.map(t => t.preco)) : null;
  function precoCartao(p) {
    const ap = aPartir(p);
    if (ap != null) return html`<span class="preco num"><small>a partir de</small>${brl(ap)}</span>`;
    return html`<span class="preco num ${p.promo_ativa ? 'promo' : ''}">${brl(p.preco)}${p.promo_ativa ? html`<s>${brl(p.preco_normal)}</s>` : ''}</span>`;
  }

  // ---------- herói ----------
  const DOODLES = ['lanche', 'pizza', 'copo', 'doce', 'prato'];
  function heroi({ nome, logo, capa, aberto, texto, topo = '', extra = '' }) {
    const pos = [[8, 18, -8], [72, 10, 10], [84, 52, -4], [30, 62, 6], [56, 34, -12]];
    const doodles = capa ? '' : pos.map(([x, y, r], i) => `<svg viewBox="0 0 64 64" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linejoin="round" stroke-linecap="round" style="left:${x}%;top:${y}%;transform:rotate(${r}deg);animation-delay:-${i * 2.3}s"><path d="${(typeof ARTE !== 'undefined' && ARTE[DOODLES[i]]) || ''}"/></svg>`).join('');
    const bolhas = capa ? '' : [[-10, -20, 220], [70, 40, 180], [30, 80, 140]].map(([x, y, s], i) => `<span style="left:${x}%;top:${y}%;width:${s}px;height:${s}px;animation-delay:-${i * 4}s"></span>`).join('');
    return html`<section class="mc-heroi" id="mc-heroi">
      <div class="fundo ${capa ? 'foto' : ''}" style="${capa ? raw(`background-image:url('${encodeURI(capa)}')`) : ''}"></div>
      <div class="bolhas">${raw(bolhas)}</div><div class="doodles">${raw(doodles)}</div>
      <div class="topo">${raw(String(topo))}</div>
      <div class="loja"><div class="mc-logo" style="${logo ? raw(`background-image:url('${encodeURI(logo)}')`) : ''}">${logo ? '' : iniciais(nome)}</div>
        <div style="min-width:0"><h1>${nome}</h1><div class="sub"><span class="mc-pilula ${aberto ? '' : 'fechado'}"><span class="ponto"></span>${texto}</span></div></div></div>
      ${raw(String(extra))}
    </section>`;
  }
  function barraCompacta({ nome, logo, direita = '' }) {
    return html`<header class="mc-barra" id="mc-barra"><button class="mc-ic" data-topo aria-label="Voltar ao topo">${ic('voltar')}</button>
      <span class="logo-p" style="${logo ? raw(`background-image:url('${encodeURI(logo)}')`) : ''}">${logo ? '' : iniciais(nome)}</span><b>${nome}</b>${raw(String(direita))}</header>`;
  }
  // barra que aparece ao rolar + efeito de profundidade na capa
  function ligarRolagem() {
    const barra = $('#mc-barra'), heroi = $('#mc-heroi'), fundo = heroi && $('.fundo', heroi), cats = $('.mc-cats');
    if (!heroi) return;
    let pend = false;
    const fazer = () => {
      pend = false;
      const y = window.scrollY, h = heroi.offsetHeight;
      if (barra) barra.classList.toggle('on', y > h - 70);
      if (cats) cats.classList.toggle('solto', !(barra && y > h - 70));
      if (fundo && !reduz() && y < h + 50) fundo.style.transform = `translate3d(0, ${y * 0.38}px, 0) scale(${1 + Math.min(y, 300) / 1600})`;
    };
    window.addEventListener('scroll', () => { if (!pend) { pend = true; requestAnimationFrame(fazer); } }, { passive: true });
    if (barra) barra.addEventListener('click', (e) => { if (e.target.closest('[data-topo]')) window.scrollTo({ top: 0, behavior: 'smooth' }); });
    fazer();
  }

  // ---------- categorias (pílulas com destaque deslizante + segue a rolagem) ----------
  function navCats(lista) {
    return html`<nav class="mc-cats solto" aria-label="Categorias"><div class="trilho"><span class="lampada"></span>${lista.map((k, i) => html`<button data-cat="${k.id}" class="${i === 0 ? 'on' : ''}"><span class="arte">${raw(typeof arteSvg === 'function' ? arteSvg(k.nome, k.nome) : '')}</span>${k.nome}</button>`)}</div></nav>`;
  }
  let pararCats = null;
  function ligarCats() {
    if (pararCats) pararCats();
    const nav = $('.mc-cats'); if (!nav) return;
    const trilho = $('.trilho', nav), lamp = $('.lampada', nav);
    const botoes = $$('button[data-cat]', nav);
    let travado = 0, atual = null;
    const ativar = (id, rolarTrilho = true) => {
      if (id === atual) return; atual = id;
      const b = botoes.find(x => x.dataset.cat === String(id)); if (!b) return;
      botoes.forEach(x => x.classList.toggle('on', x === b));
      lamp.style.width = b.offsetWidth + 'px'; lamp.style.transform = `translateX(${b.offsetLeft}px)`;
      if (rolarTrilho) trilho.scrollTo({ left: b.offsetLeft - trilho.clientWidth / 2 + b.offsetWidth / 2, behavior: reduz() ? 'auto' : 'smooth' });
    };
    const espiar = () => {
      if (Date.now() < travado) return;
      const lim = (nav.getBoundingClientRect().bottom || 0) + 40;
      let id = botoes[0]?.dataset.cat;
      for (const b of botoes) { const s = document.getElementById('cat-' + b.dataset.cat); if (s && s.getBoundingClientRect().top < lim) id = b.dataset.cat; }
      ativar(id);
    };
    const onClick = (e) => {
      const b = e.target.closest('button[data-cat]'); if (!b) return;
      const s = document.getElementById('cat-' + b.dataset.cat); if (!s) return;
      travado = Date.now() + 900; ativar(b.dataset.cat);
      const off = nav.offsetHeight + ($('#mc-barra')?.offsetHeight || 0) + 8;
      window.scrollTo({ top: s.getBoundingClientRect().top + window.scrollY - off, behavior: reduz() ? 'auto' : 'smooth' });
    };
    let pend = false;
    const onScroll = () => { if (!pend) { pend = true; requestAnimationFrame(() => { pend = false; espiar(); }); } };
    nav.addEventListener('click', onClick); window.addEventListener('scroll', onScroll, { passive: true });
    requestAnimationFrame(() => { atual = null; ativar(botoes[0]?.dataset.cat, false); espiar(); });
    pararCats = () => { nav.removeEventListener('click', onClick); window.removeEventListener('scroll', onScroll); };
  }

  // ---------- aparecer ao rolar ----------
  let obs = null;
  function revelar(raiz = document) {
    const els = $$('.mc-revelar:not(.in)', raiz);
    if (reduz() || !('IntersectionObserver' in window)) { els.forEach(e => e.classList.add('in')); return; }
    if (!obs) obs = new IntersectionObserver((ents) => {
      let n = 0;
      for (const en of ents) if (en.isIntersecting) { const el = en.target; el.style.transitionDelay = (n++ % 8) * 55 + 'ms'; el.classList.add('in'); obs.unobserve(el); setTimeout(() => { el.style.transitionDelay = ''; }, 1200); }
    }, { rootMargin: '0px 0px -6% 0px', threshold: 0.06 });
    els.forEach(e => obs.observe(e));
  }

  // ---------- cartões ----------
  function cartaoProduto(p, { cat = '', qtd = 0, pode = true, rapido = false } = {}) {
    const selo = p.esgotado ? html`<span class="mc-selo esg">Esgotado</span>` : p.promo_ativa ? html`<span class="mc-selo promo">${ic('tag')} Promo</span>` : p.destaque ? html`<span class="mc-selo">${ic('fogo')} Top</span>` : '';
    const acao = !pode || p.esgotado ? '' : (rapido && qtd ? html`<span class="mc-passo" data-passo="${p.id}"><button data-menos="${p.id}" aria-label="Menos">${ic(qtd === 1 ? 'lixo' : 'menos')}</button><b class="num">${qtd}</b><button data-mais="${p.id}" aria-label="Mais">${ic('mais')}</button></span>`
      : html`<span class="mc-mais" data-mais="${p.id}" role="button" aria-label="Adicionar">${ic('mais')}</span>`);
    return html`<div class="mc-prod mc-revelar ${p.esgotado ? 'esgotado' : ''}" data-prod="${p.id}" role="button" tabindex="0">
      ${qtd ? html`<span class="qt num">${qtd}</span>` : ''}
      <div class="info"><b>${p.nome}</b>${p.descricao ? html`<span class="desc">${p.descricao}</span>` : ''}<div class="baixo">${precoCartao(p)}${acao}</div></div>
      <div class="foto">${imgOuArte(p.foto, p.nome, cat)}${selo}</div></div>`;
  }
  function cartaoDestaque(p, cat = '') {
    const ap = aPartir(p);
    return html`<button class="mc-dest mc-revelar" data-prod="${p.id}"><span class="img">${imgOuArte(p.foto, p.nome, cat)}</span>
      ${p.promo_ativa ? html`<span class="mc-selo promo">${ic('tag')} Promoção</span>` : html`<span class="mc-selo">${ic('fogo')} Mais pedido</span>`}
      <span class="txt"><b>${p.nome}</b>${p.descricao ? html`<span>${p.descricao}</span>` : ''}<span class="preco num">${ap != null ? html`a partir de ${brl(ap)}` : html`${brl(p.preco)}${p.promo_ativa ? html`<s>${brl(p.preco_normal)}</s>` : ''}`}</span></span></button>`;
  }
  function esqueleto() {
    const b = (w, h, extra = '') => `<div class="b" style="width:${w};height:${h}px;${extra}"></div>`;
    return raw(`<div class="mc-esq"><div class="b" style="height:250px;border-radius:0"></div><div class="mc-larg" style="margin-top:22px">${b('60%', 26)}<div style="display:flex;gap:8px;margin:18px 0">${b('90px', 40)}${b('110px', 40)}${b('80px', 40)}</div>
      ${[0, 1, 2, 3].map(() => `<div style="display:flex;gap:14px;margin-bottom:14px"><div style="flex:1">${b('70%', 18)}${b('95%', 12, 'margin-top:10px')}${b('40%', 18, 'margin-top:18px')}</div>${b('112px', 112)}</div>`).join('')}</div></div>`);
  }

  // ---------- folhas (sobem de baixo; no computador, janela no meio) ----------
  const pilha = [];
  function folha({ conteudo, classe = '', aoAbrir, arrastar = true }) {
    return new Promise((resolve) => {
      const fundo = document.createElement('div'); fundo.className = 'mc-fundo';
      fundo.innerHTML = `<div class="mc-folha ${classe}" role="dialog" aria-modal="true">${arrastar ? '<div class="alca"></div>' : ''}${String(conteudo)}</div>`;
      document.body.appendChild(fundo); document.body.classList.add('travado');
      const el = $('.mc-folha', fundo);
      let fechada = false;
      const fechar = (valor = null, { semHistorico = false } = {}) => {
        if (fechada) return; fechada = true;
        const i = pilha.indexOf(item); if (i >= 0) pilha.splice(i, 1);
        if (!semHistorico && history.state && history.state.mcFolha === id) { ignorarPop++; history.back(); }
        fundo.classList.add('saindo'); document.removeEventListener('keydown', tecla);
        setTimeout(() => { fundo.remove(); if (!pilha.length) document.body.classList.remove('travado'); }, 290);
        resolve(valor);
      };
      const id = Date.now() + Math.random();
      const item = { fechar, id };
      pilha.push(item);
      try { history.pushState({ ...(history.state || {}), mcFolha: id }, ''); } catch {}
      const tecla = (e) => { if (e.key === 'Escape' && pilha[pilha.length - 1] === item) fechar(null); };
      document.addEventListener('keydown', tecla);
      fundo.addEventListener('click', (e) => { if (e.target === fundo || e.target.closest('[data-x]')) fechar(null); });
      // arrastar para baixo fecha
      if (arrastar) {
        let y0 = null, dy = 0, t0 = 0;
        el.addEventListener('pointerdown', (e) => {
          if (e.pointerType === 'mouse' || e.target.closest('input,textarea,select,button')) return;
          const rolar = $('.rolar', el);
          if (rolar && rolar.scrollTop > 0 && rolar.contains(e.target)) return;
          y0 = e.clientY; dy = 0; t0 = Date.now(); el.style.transition = 'none';
        });
        el.addEventListener('pointermove', (e) => { if (y0 == null) return; dy = Math.max(0, e.clientY - y0); if (dy > 4) el.style.transform = `translateY(${dy}px)`; });
        const soltar = () => {
          if (y0 == null) return; y0 = null; el.style.transition = 'transform .35s cubic-bezier(.22,1,.36,1)';
          const vel = dy / Math.max(1, Date.now() - t0);
          if (dy > 130 || (dy > 50 && vel > 0.6)) { el.style.transform = 'translateY(100%)'; setTimeout(() => fechar(null), 120); } else el.style.transform = '';
        };
        el.addEventListener('pointerup', soltar); el.addEventListener('pointercancel', soltar);
      }
      aoAbrir && aoAbrir(el, fechar);
    });
  }
  let ignorarPop = 0;
  window.addEventListener('popstate', (e) => {
    if (ignorarPop > 0) { ignorarPop--; e.mcTratado = true; return; }
    if (pilha.length) { pilha[pilha.length - 1].fechar(null, { semHistorico: true }); e.mcTratado = true; }
  });
  const folhaAberta = () => pilha.length > 0;

  // ---------- escolher produto ----------
  const obsDaCat = (cat) => [...new Map(String(cat?.obs_rapidas || '').split(';').map(s => s.trim()).filter(Boolean).map(s => [s.toLowerCase(), s])).values()];
  const adsDe = (prod, ctx) => (ctx.adicionais || []).filter(a => !a.categoria_id || a.categoria_id === prod.categoria_id);
  function ehSimples(prod, ctx) {
    const cat = (ctx.categorias || []).find(c => c.id === prod.categoria_id);
    // o "+" põe direto na sacola quando não há escolha obrigatória (tamanho, meio a meio); adicionais e observações ficam no toque no produto
    return !(prod.tamanhos && prod.tamanhos.length) && !cat?.meio_a_meio && !(prod.escolha && prod.escolha.opcoes && prod.escolha.opcoes.length);
  }
  const itemSimples = (p) => ({ produto_id: p.id, produto2_id: null, tamanho: null, qtd: 1, obs: '', adicionais: [], _nome: p.nome, _preco: p.preco, _ads: [], _foto: p.foto || null });
  const chaveItem = (x) => [x.produto_id, x.produto2_id, x.tamanho, x.obs, JSON.stringify(x.adicionais)].join('|');

  function escolher(prod, ctx) {
    const cat = (ctx.categorias || []).find(c => c.id === prod.categoria_id) || {};
    const tamanhos = prod.tamanhos || [];
    const ads = adsDe(prod, ctx);
    const obsR = obsDaCat(cat);
    const irmaos = cat.meio_a_meio ? (ctx.produtos || []).filter(p => p.categoria_id === prod.categoria_id && p.id !== prod.id && !p.esgotado) : [];
    const regra = ctx.regra || 'maior';
    const E = { tam: tamanhos.length ? (tamanhos[1] || tamanhos[0]).nome : null, seg: null, ads: new Set(), qtd: 1, obs: new Set(), esc: null };
    const escolha = prod.escolha && Array.isArray(prod.escolha.opcoes) && prod.escolha.opcoes.length ? prod.escolha : null;
    const unit = () => {
      let pr = precoBase(prod, E.tam);
      const p2 = E.seg ? irmaos.find(p => p.id === E.seg) : null;
      if (p2) { const b = precoBase(p2, E.tam); pr = regra === 'media' ? Math.round((pr + b) / 2) : Math.max(pr, b); }
      return pr + ads.filter(a => E.ads.has(a.id)).reduce((s, a) => s + a.preco, 0);
    };
    const pode = ctx.pode !== false && !prod.esgotado;
    const ap = aPartir(prod);
    const conteudo = html`<button class="x" data-x aria-label="Fechar">${ic('x')}</button>
      <div class="rolar">
        <div class="mc-pd-img ${prod.foto ? '' : 'sem'}">${imgOuArte(prod.foto, prod.nome, cat.nome)}</div>
        <div class="mc-pd"><h2>${prod.nome}</h2>${prod.descricao ? html`<div class="d">${prod.descricao}</div>` : ''}
          <div class="p num">${ap != null ? html`a partir de ${brl(ap)}` : html`${brl(prod.preco)}${prod.promo_ativa ? html`<s>${brl(prod.preco_normal)}</s>` : ''}`}</div>
          ${escolha ? html`<div class="mc-grupo" id="mc-g-esc"><div class="tit"><b>${escolha.titulo}</b><span class="tag obr">Escolha 1</span></div>
            <div data-g="esc">${escolha.opcoes.map(o => html`<button class="mc-opc radio" data-esc="${o}"><span class="mk">${ic('check')}</span><span class="t">${o}</span></button>`)}</div></div>` : ''}
          ${tamanhos.length ? html`<div class="mc-grupo"><div class="tit"><b>${(window.PRODUTO?.termos?.tamanho || 'Tamanho')}</b><span class="tag obr">Escolha 1</span></div>
            <div class="${tamanhos.length <= 3 ? 'mc-segmento' : ''}" data-g="tam">${tamanhos.map(t => html`<button class="mc-opc radio ${t.nome === E.tam ? 'on' : ''}" data-tam="${t.nome}"><span class="mk">${ic('check')}</span><span class="t">${t.nome}</span><span class="v num">${brl(t.preco)}</span></button>`)}</div></div>` : ''}
          ${irmaos.length ? html`<div class="mc-grupo"><div class="tit"><b>Meio a meio?</b><small>${regra === 'media' ? 'cobra a média' : 'cobra o maior'}</small><span class="tag">Opcional</span></div>
            <div data-g="seg"><button class="mc-opc radio on" data-seg=""><span class="mk">${ic('check')}</span><span class="t">Inteira<small>Só ${prod.nome}</small></span></button>
            ${irmaos.map(p => html`<button class="mc-opc radio" data-seg="${p.id}"><span class="mk">${ic('check')}</span><span class="mini">${imgOuArte(p.foto, p.nome, cat.nome)}</span><span class="t">½ ${p.nome}${p.descricao ? html`<small>${p.descricao}</small>` : ''}</span></button>`)}</div></div>` : ''}
          ${ads.length ? html`<div class="mc-grupo"><div class="tit"><b>Adicionais</b><span class="tag">Opcional</span></div>
            <div data-g="ads">${ads.map(a => html`<button class="mc-opc" data-ad="${a.id}"><span class="mk">${ic('check')}</span><span class="t">${a.nome}</span><span class="v num">${a.preco ? '+ ' + brl(a.preco) : 'grátis'}</span></button>`)}</div></div>` : ''}
          ${obsR.length ? html`<div class="mc-grupo"><div class="tit"><b>Como você prefere?</b><span class="tag">Opcional</span></div><div class="mc-chips">${obsR.map(o => html`<button data-obs="${o}">${o}</button>`)}</div></div>` : ''}
          ${pode ? html`<div class="mc-grupo"><div class="tit"><b>Alguma observação?</b></div><textarea class="mc-txt" id="mc-obs" maxlength="120" placeholder="Ex.: sem cebola, bem passado"></textarea></div>` : ''}
          <div style="height:10px"></div>
        </div></div>
      <div class="pe">${pode ? html`<div class="mc-qtd"><button data-q="-1" aria-label="Menos">${ic('menos')}</button><b class="num" id="mc-q">1</b><button data-q="1" aria-label="Mais">${ic('mais')}</button></div>
        <button class="mc-btn pri" data-add><span>Adicionar</span><span class="num" id="mc-tot">${brl(unit())}</span></button>`
        : (!prod.esgotado && ctx.aoMotivo) ? html`<button class="mc-btn pri centro" data-motivo>${ic('camera')} ${ctx.motivo || 'Fechar'}</button>` : html`<button class="mc-btn pri centro" data-x>${prod.esgotado ? 'Esgotado no momento' : (ctx.motivo || 'Fechar')}</button>`}</div>`;
    return folha({ conteudo, classe: 'mc-produto', aoAbrir: (el, fechar) => {
      const tot = $('#mc-tot', el);
      const atualizar = () => { if (tot) animarNumero(tot, unit() * E.qtd); };
      el.addEventListener('click', (e) => {
        const t = e.target.closest('[data-tam]'); if (t) { E.tam = t.dataset.tam; $$('[data-tam]', el).forEach(x => x.classList.toggle('on', x === t)); vibrar(15); atualizar(); return; }
        if (e.target.closest('[data-motivo]')) { fechar(null); setTimeout(() => ctx.aoMotivo(), 60); return; }
        const es = e.target.closest('[data-esc]'); if (es) { E.esc = es.dataset.esc; $$('[data-esc]', el).forEach(x => x.classList.toggle('on', x === es)); $('#mc-g-esc', el)?.classList.remove('falta'); vibrar(15); return; }
        const s = e.target.closest('[data-seg]'); if (s) { E.seg = s.dataset.seg ? Number(s.dataset.seg) : null; $$('[data-seg]', el).forEach(x => x.classList.toggle('on', x === s)); vibrar(15); atualizar(); return; }
        const a = e.target.closest('[data-ad]'); if (a) { const id = Number(a.dataset.ad); if (E.ads.has(id)) E.ads.delete(id); else E.ads.add(id); a.classList.toggle('on', E.ads.has(id)); vibrar(15); atualizar(); return; }
        const o = e.target.closest('[data-obs]'); if (o) { const v = o.dataset.obs; if (E.obs.has(v)) E.obs.delete(v); else E.obs.add(v); o.classList.toggle('on', E.obs.has(v)); vibrar(10); return; }
        const q = e.target.closest('[data-q]'); if (q) { E.qtd = Math.max(1, Math.min(50, E.qtd + Number(q.dataset.q))); const b = $('#mc-q', el); b.textContent = E.qtd; b.classList.remove('muda'); void b.offsetWidth; b.classList.add('muda'); atualizar(); return; }
        if (e.target.closest('[data-add]')) {
          if (escolha && !E.esc) { const g = $('#mc-g-esc', el); if (g) { g.classList.add('falta'); g.scrollIntoView({ behavior: reduz() ? 'auto' : 'smooth', block: 'center' }); } pular(e.target.closest('[data-add]'), 'treme'); vibrar([30, 40, 30]); return; }
          const p2 = E.seg ? irmaos.find(p => p.id === E.seg) : null;
          const adsSel = ads.filter(a => E.ads.has(a.id));
          const livre = ($('#mc-obs', el)?.value || '').trim();
          const obsTxt = [...(E.esc ? [`${escolha.titulo}: ${E.esc}`] : []), ...E.obs, ...(livre ? [livre] : [])].join(', ').slice(0, 120);
          const nome = (p2 ? `½ ${prod.nome} + ½ ${p2.nome}` : prod.nome) + (E.tam ? ` (${E.tam})` : '');
          const origem = $('.mc-pd-img', el);
          voar(origem, ctx.alvo);
          fechar({ produto_id: prod.id, produto2_id: p2 ? p2.id : null, tamanho: E.tam, qtd: E.qtd, obs: obsTxt, adicionais: adsSel.map(a => a.id), _nome: nome, _preco: unit(), _ads: adsSel.map(a => ({ id: a.id, nome: a.nome, preco: a.preco })), _foto: prod.foto || null });
        }
      });
    } });
  }

  // ---------- animações ----------
  function voar(origem, alvoFn) {
    if (!origem || !alvoFn || reduz()) return Promise.resolve();
    const alvo = alvoFn(); if (!alvo) return Promise.resolve();
    const r = origem.getBoundingClientRect();
    const tam = Math.max(44, Math.min(r.width, r.height, 150));
    const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
    const clone = document.createElement('div'); clone.className = 'mc-voando';
    const img = origem.querySelector('img'), art = origem.querySelector('.arte');
    clone.innerHTML = img ? `<img src="${esc(img.currentSrc || img.src)}" alt="">` : art ? `<span class="arte mc-arte-fundo">${art.innerHTML}</span>` : '';
    Object.assign(clone.style, { left: cx - tam / 2 + 'px', top: cy - tam / 2 + 'px', width: tam + 'px', height: tam + 'px' });
    document.body.appendChild(clone);
    const dx = alvo.x - cx, dy = alvo.y - cy;
    const a = clone.animate([
      { transform: 'translate(0,0) scale(1) rotate(0deg)', opacity: 1, borderRadius: '18px' },
      { transform: `translate(${dx * 0.3}px, ${Math.min(dy * 0.3, 0) - 110}px) scale(.8) rotate(-8deg)`, opacity: 1, offset: 0.42 },
      { transform: `translate(${dx}px, ${dy}px) scale(.14) rotate(14deg)`, opacity: .7, borderRadius: '50%' },
    ], { duration: 780, easing: 'cubic-bezier(.5,.05,.45,1)', fill: 'forwards' });
    return a.finished.then(() => clone.remove(), () => clone.remove());
  }
  function animarNumero(el, para, fmt = brl, dur = 420) {
    if (!el) return;
    const de = Number(el.dataset.v ?? para); el.dataset.v = para;
    if (reduz() || de === para) { el.textContent = fmt(para); return; }
    const t0 = performance.now();
    const passo = (t) => { const k = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - k, 3); el.textContent = fmt(Math.round(de + (para - de) * e)); if (k < 1 && el.dataset.v == para) requestAnimationFrame(passo); };
    requestAnimationFrame(passo);
  }
  function pular(el, cls = 'pula') { if (!el) return; el.classList.remove(cls); void el.offsetWidth; el.classList.add(cls); }
  function confete(qtd = 140) {
    if (reduz()) return;
    const cv = document.createElement('canvas'); cv.className = 'mc-confete'; document.body.appendChild(cv);
    const dpr = Math.min(2, window.devicePixelRatio || 1), W = innerWidth, H = innerHeight;
    cv.width = W * dpr; cv.height = H * dpr; const g = cv.getContext('2d'); g.scale(dpr, dpr);
    const cor = getComputedStyle(document.documentElement).getPropertyValue('--c').trim() || '#e3262f';
    const cores = [cor, '#fbbf24', '#34d399', '#60a5fa', '#f472b6', '#ffffff'];
    const ps = Array.from({ length: qtd }, (_, i) => ({ x: W / 2 + (Math.random() - .5) * 60, y: H * 0.42, vx: (Math.random() - .5) * 15, vy: -Math.random() * 15 - 5, r: Math.random() * 6 + 4, c: cores[i % cores.length], a: Math.random() * 6, va: (Math.random() - .5) * .35, f: Math.random() < .5 }));
    const t0 = performance.now();
    const quadro = (t) => {
      g.clearRect(0, 0, W, H);
      for (const p of ps) { p.vy += 0.42; p.vx *= 0.99; p.x += p.vx; p.y += p.vy; p.a += p.va; g.save(); g.translate(p.x, p.y); g.rotate(p.a); g.fillStyle = p.c; if (p.f) g.fillRect(-p.r / 2, -p.r / 4, p.r, p.r / 2); else { g.beginPath(); g.arc(0, 0, p.r / 2.4, 0, 7); g.fill(); } g.restore(); }
      if (t - t0 < 2600) requestAnimationFrame(quadro); else cv.remove();
    };
    requestAnimationFrame(quadro);
  }
  function sucesso({ titulo, texto, tempo = 2000 }) {
    return new Promise((resolve) => {
      const d = document.createElement('div'); d.className = 'mc-ok';
      d.innerHTML = `<div><svg viewBox="0 0 120 120"><circle cx="60" cy="60" r="54"/><path d="M36 62 53 78 86 44"/></svg><h2>${esc(titulo)}</h2><p>${esc(texto || '')}</p></div>`;
      document.body.appendChild(d); confete(); vibrar([60, 40, 90]);
      let foi = false;
      const sair = () => { if (foi) return; foi = true; d.classList.add('saindo'); setTimeout(() => { d.remove(); resolve(); }, 330); };
      d.addEventListener('click', sair); setTimeout(sair, tempo);
    });
  }

  // ---------- gráficos ----------
  // rosca: segmentos [{v, cor}] e texto no meio
  function rosca(segs, centro) {
    const r = 26, C = 2 * Math.PI * r, tot = segs.reduce((s, x) => s + x.v, 0) || 1;
    let acc = 0;
    const arcos = segs.filter(s => s.v > 0).map(s => { const len = C * s.v / tot; const o = `<circle cx="32" cy="32" r="${r}" stroke="${s.cor}" stroke-dasharray="${Math.max(0, len - (segs.filter(x => x.v > 0).length > 1 ? 2.5 : 0))} ${C}" stroke-dashoffset="${-acc}"/>`; acc += len; return o; }).join('');
    return raw(`<div class="mc-rosca"><svg viewBox="0 0 64 64"><circle cx="32" cy="32" r="${r}" stroke="var(--sf2)"/>${arcos}</svg><div class="c num">${esc(centro)}</div></div>`);
  }
  function anel(frac, emoji, rotulo) {
    const r = 86, C = 2 * Math.PI * r;
    return raw(`<div class="mc-anel"><svg viewBox="0 0 200 200"><defs><linearGradient id="mc-grad" x1="0" y1="0" x2="1" y2="1"><stop offset="0" style="stop-color:color-mix(in srgb, var(--c) 45%, #fff)"/><stop offset="1" style="stop-color:var(--c)"/></linearGradient></defs>
      <circle class="trilha" cx="100" cy="100" r="${r}"/><circle class="prog" cx="100" cy="100" r="${r}" stroke-dasharray="${C}" stroke-dashoffset="${C}" data-alvo="${C * (1 - Math.max(0, Math.min(1, frac)))}"/></svg>
      ${frac < 1 ? '<span class="onda"></span>' : ''}<div class="c"><span class="em">${emoji}</span><b>${esc(rotulo)}</b></div></div>`);
  }
  function animarAneis(raiz = document) { requestAnimationFrame(() => requestAnimationFrame(() => $$('.mc-anel .prog[data-alvo]', raiz).forEach(c => { c.style.strokeDashoffset = c.dataset.alvo; }))); }

  return { ic, aplicarMarca, contraste, arte, imgOuArte, iniciais, precoBase, aPartir, precoCartao, heroi, barraCompacta, ligarRolagem, navCats, ligarCats, revelar,
    cartaoProduto, cartaoDestaque, esqueleto, folha, folhaAberta, escolher, ehSimples, itemSimples, chaveItem, voar, animarNumero, pular, confete, sucesso, rosca, anel, animarAneis, reduz };
})();
