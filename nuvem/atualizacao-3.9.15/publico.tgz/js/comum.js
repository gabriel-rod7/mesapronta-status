'use strict';
// Utilidades compartilhadas por todas as telas.

const $ = (sel, el = document) => el.querySelector(sel);
const $$ = (sel, el = document) => [...el.querySelectorAll(sel)];

function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
class Raw { constructor(s) { this.s = s; } toString() { return this.s; } }
const raw = (s) => new Raw(s);
function html(strings, ...vals) {
  let out = '';
  strings.forEach((s, i) => {
    out += s;
    if (i < vals.length) {
      const v = vals[i];
      if (v instanceof Raw) out += v.s;
      else if (Array.isArray(v)) out += v.map(x => (x instanceof Raw ? x.s : esc(x))).join('');
      else if (v === false || v == null) out += '';
      else out += esc(v);
    }
  });
  return raw(out);
}

const brl = (c) => 'R$ ' + (Number(c || 0) / 100).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const brlCurto = (c) => (Number(c || 0) / 100).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
function paraCentavos(s) {
  s = String(s ?? '').trim().replace(/[R$\s]/g, '');
  if (!s) return 0;
  if (s.includes(',')) s = s.replace(/\./g, '').replace(',', '.');
  const n = Number(s);
  return Number.isFinite(n) ? Math.round(n * 100) : 0;
}
const hora = (s) => (s ? s.slice(11, 16) : '');
const dataBR = (s) => (s ? `${s.slice(8, 10)}/${s.slice(5, 7)}/${s.slice(0, 4)}` : '');
const dataHoraBR = (s) => (s ? dataBR(s) + ' ' + hora(s) : '');
function minutosDesde(s, agoraStr) {
  if (!s) return 0;
  const d = new Date(s.replace(' ', 'T'));
  const ag = agoraStr ? new Date(agoraStr.replace(' ', 'T')) : new Date();
  return Math.max(0, Math.floor((ag - d) / 60000));
}
function hojeISO(d = new Date()) {
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}
const DIAS_SEMANA = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
const soDigitos = (s) => String(s || '').replace(/\D/g, '');
function linkWhatsApp(telefone, texto) {
  let d = soDigitos(telefone);
  if (d.length === 10 || d.length === 11) d = '55' + d;
  return `https://wa.me/${d}?text=${encodeURIComponent(texto)}`;
}

// ---------- Tema ----------
const Tema = {
  get() { try { return localStorage.getItem('mp_tema') || 'claro'; } catch { return 'claro'; } },
  aplicar(t) { document.documentElement.dataset.tema = t; try { localStorage.setItem('mp_tema', t); } catch {} },
  alternar() { this.aplicar(this.get() === 'escuro' ? 'claro' : 'escuro'); return this.get(); },
};
Tema.aplicar(Tema.get());

// ---------- Sessão e API ----------
const Sessao = {
  chave: 'mp_sessao',
  get() { try { return JSON.parse(localStorage.getItem(this.chave)) || null; } catch { return null; } },
  set(v) { try { localStorage.setItem(this.chave, JSON.stringify(v)); } catch {} },
  limpar() { try { localStorage.removeItem(this.chave); } catch {} },
};

async function api(metodo, caminho, corpo) {
  const s = Sessao.get();
  let res;
  try {
    res = await fetch(caminho, {
      method: metodo,
      headers: { 'Content-Type': 'application/json', ...(s?.token ? { Authorization: 'Bearer ' + s.token } : {}) },
      body: corpo !== undefined ? JSON.stringify(corpo) : undefined,
    });
  } catch {
    throw new Error('Sem conexão com o computador do caixa. Verifique o Wi-Fi.');
  }
  const dados = await res.json().catch(() => ({}));
  if (res.status === 401 && caminho !== '/api/login') {
    Sessao.limpar();
    if (typeof window.aoDeslogar === 'function') window.aoDeslogar();
  }
  if (res.status === 402 && typeof window.aoBloquearLicenca === 'function') window.aoBloquearLicenca(dados);
  if (!res.ok) { const e = new Error(dados.erro || 'Erro ' + res.status); e.status = res.status; e.dados = dados; e.silencioso = res.status === 402; throw e; }
  return dados;
}
const GET = (c) => api('GET', c);
const POST = (c, b = {}) => api('POST', c, b);
const PUT = (c, b = {}) => api('PUT', c, b);
const PATCH = (c, b = {}) => api('PATCH', c, b);
const DEL = (c) => api('DELETE', c);

async function baixarArquivo(caminho) {
  const s = Sessao.get();
  const res = await fetch(caminho, { headers: s?.token ? { Authorization: 'Bearer ' + s.token } : {} });
  if (!res.ok) throw new Error((await res.json().catch(() => ({}))).erro || 'Falha ao exportar');
  const blob = await res.blob();
  const nome = (res.headers.get('Content-Disposition') || '').match(/filename="([^"]+)"/)?.[1] || 'arquivo.csv';
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = nome; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
}

// ---------- Avisos ----------
function toast(msg, tipo = '', opcoes = {}) {
  if (tipo === 'erro' && /precisa ser ativado/.test(String(msg))) return; // a tela de bloqueio já explica
  let box = $('#toasts');
  if (!box) { box = document.createElement('div'); box.id = 'toasts'; document.body.appendChild(box); }
  const t = document.createElement('div');
  t.className = 'toast ' + tipo;
  t.textContent = msg;
  if (opcoes.acao) {
    const b = document.createElement('button'); b.className = 'toast-acao'; b.textContent = opcoes.acao.texto;
    b.onclick = () => { opcoes.acao.fn(); t.remove(); };
    t.appendChild(b);
  }
  t.onclick = () => t.remove();
  box.appendChild(t);
  setTimeout(() => t.remove(), opcoes.tempo || (tipo === 'erro' ? 6000 : tipo === 'alerta' ? 8000 : 3500));
  return t;
}
async function tentar(fn, msgOk) {
  try { const r = await fn(); if (msgOk) toast(msgOk, 'ok'); return r; }
  catch (e) { toast(e.message, 'erro'); throw e; }
}

let audioCtx;
function bip(vezes = 2, freq = 880) {
  try {
    audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
    if (audioCtx.state === 'suspended') audioCtx.resume();
    for (let i = 0; i < vezes; i++) {
      const o = audioCtx.createOscillator(), g = audioCtx.createGain();
      o.frequency.value = freq; o.type = 'sine';
      const t0 = audioCtx.currentTime + i * 0.25;
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.exponentialRampToValueAtTime(0.4, t0 + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.2);
      o.connect(g).connect(audioCtx.destination);
      o.start(t0); o.stop(t0 + 0.22);
    }
  } catch {}
}
function vibrar(padrao = 80) { try { navigator.vibrate?.(padrao); } catch {} }

// ---------- Modal ----------
function modal({ titulo, corpo, botoes = [], largo = false, aoAbrir, focar = true, semFechar = false }) {
  return new Promise((resolve) => {
    const anterior = document.activeElement;
    const fundo = document.createElement('div');
    fundo.className = 'modal-fundo';
    fundo.innerHTML = `<div class="modal ${largo ? 'largo' : ''}" role="dialog" aria-modal="true" aria-label="${esc(titulo)}">
      <div class="modal-cab"><h2>${esc(titulo)}</h2><span class="spacer"></span>${semFechar ? '' : '<button class="btn ghost sm" data-fechar aria-label="Fechar">✕</button>'}</div>
      <div class="modal-corpo">${corpo}</div>
      ${botoes.length ? `<div class="modal-rod">${botoes.map((b, i) => `<button class="btn ${b.classe || ''}" data-i="${i}">${esc(b.texto)}</button>`).join('')}</div>` : ''}
    </div>`;
    const fechar = (v) => { fundo.remove(); document.removeEventListener('keydown', tecla); if(anterior?.isConnected) anterior.focus(); resolve(v); };
    const tecla = (e) => {
      if ([...document.querySelectorAll('.modal-fundo')].at(-1) !== fundo) return;
      if (e.key === 'Tab') {
        const els=[...fundo.querySelectorAll('button:not(:disabled),input:not(:disabled),select:not(:disabled),textarea:not(:disabled),a[href],[tabindex="0"]')].filter(el=>el.getClientRects().length);
        const first=els[0],last=els.at(-1);
        if(e.shiftKey&&(document.activeElement===first||!fundo.contains(document.activeElement))){e.preventDefault();last?.focus();}
        else if(!e.shiftKey&&(document.activeElement===last||!fundo.contains(document.activeElement))){e.preventDefault();first?.focus();}
      }
      if (e.key === 'Escape' && !semFechar) fechar(null);
      if (e.key === 'Enter' && e.target.tagName !== 'TEXTAREA') {
        const padrao = botoes.findIndex(b => b.padrao);
        if (padrao >= 0) { e.preventDefault(); fundo.querySelector(`[data-i="${padrao}"]`).click(); }
      }
    };
    document.addEventListener('keydown', tecla);
    fundo.addEventListener('click', async (e) => {
      if ((e.target === fundo && !semFechar) || e.target.closest('[data-fechar]')) return fechar(null);
      const b = e.target.closest('[data-i]');
      if (!b) return;
      const def = botoes[Number(b.dataset.i)];
      if (def.acao) {
        b.disabled = true;
        try { const r = await def.acao(fundo); if (r !== false) fechar(r === undefined ? true : r); }
        catch (err) { toast(err.message, 'erro'); }
        finally { b.disabled = false; }
      } else fechar(def.valor ?? null);
    });
    document.body.appendChild(fundo);
    const foco = fundo.querySelector('input:not([type=checkbox]):not([type=radio]), select, textarea') || fundo.querySelector('button');
    if (foco && focar) setTimeout(() => foco.focus(), 30);
    if (aoAbrir) aoAbrir(fundo, fechar);
  });
}
function confirmar(titulo, texto, textoOk = 'Confirmar', classe = 'primary') {
  return modal({ titulo, corpo: `<p>${esc(texto)}</p>`, botoes: [{ texto: 'Voltar' }, { texto: textoOk, classe, valor: true, padrao: true }] });
}
function pedirTexto(titulo, rotulo, valor = '', tipo = 'text') {
  return modal({
    titulo, corpo: `<label class="campo">${esc(rotulo)}<input type="${tipo}" id="mp-txt" value="${esc(valor)}" ${tipo === 'number' ? 'inputmode="numeric"' : ''}></label>`,
    botoes: [{ texto: 'Cancelar' }, { texto: 'OK', classe: 'primary', padrao: true, acao: (f) => $('#mp-txt', f).value.trim() }],
  });
}
async function pinGerente(motivoObrigatorio = false, titulo = 'Autorização do gerente', forcar = false) {
  const s = Sessao.get();
  const ehGerente = s?.usuario?.perfil === 'gerente' && !forcar;
  if (ehGerente && !motivoObrigatorio) return { pin: null };
  return modal({
    titulo,
    corpo: `${motivoObrigatorio ? '<label class="campo">Motivo<input type="text" id="mp-motivo" placeholder="Ex.: cliente desistiu"></label><br>' : ''}
      ${ehGerente ? '' : '<label class="campo">PIN do gerente<input type="password" inputmode="numeric" id="mp-pin" autocomplete="off"></label>'}
      ${forcar ? '<div class="muted small">Por segurança, digite o PIN mesmo já estando logado como gerente.</div>' : ''}`,
    botoes: [{ texto: 'Cancelar' }, {
      texto: 'Autorizar', classe: 'primary', padrao: true, acao: (f) => {
        const motivo = $('#mp-motivo', f)?.value.trim();
        if (motivoObrigatorio && !motivo) throw new Error('Informe o motivo');
        return { pin: $('#mp-pin', f)?.value || null, motivo };
      },
    }],
  });
}

// ---------- Tela de login por PIN ----------
function telaLogin(container, { titulo = 'Entrar', subtitulo = '', aviso = '', licenca = null, suporte = '', dica = '', aoEntrar }) {
  let pin = '';
  const TXL = (window.PRODUTO && window.PRODUTO.textos) || {};
  container.innerHTML = `<div class="login"><section class="login-story" aria-label="MesaPronta"><div class="logo">Mesa<span>Pronta</span></div><div><div class="eyebrow">${esc(TXL.login_eyebrow || 'BOM SERVIÇO COMEÇA AQUI')}</div><h1>${TXL.login_titulo || 'Mais sabor.<br>Menos tarefas.<br><em>Tudo pronto.</em>'}</h1><p>${esc(TXL.login_sub || 'Do primeiro pedido à última mesa. Seu restaurante no ritmo certo.')}</p></div><div class="story-footer">${esc(TXL.login_rodape || 'Mesas · Balcão · Delivery · Cozinha')}</div></section><div class="login-caixa">
    <div class="logo">Mesa<span>Pronta</span></div>
    <div class="muted" style="margin-top:4px">${esc(subtitulo)}</div>
    <h2 style="margin-top:22px">${esc(titulo)}</h2>
    <div class="pin-pontos">${'<i></i>'.repeat(4)}</div>
    <div class="pin-teclas">${[1,2,3,4,5,6,7,8,9].map(n => `<button data-n="${n}">${n}</button>`).join('')}
      <button data-a="limpar" aria-label="Limpar">C</button><button data-n="0">0</button><button data-a="ok" style="background:var(--accent);color:#fff;border-color:var(--accent)">OK</button></div>
    <div class="pin-erro" role="alert" aria-live="polite"></div>
    ${dica ? `<div class="login-dica" style="margin-top:14px;background:var(--accent-soft,#eef3fb);border-radius:10px;padding:10px 12px;font-size:14px">${dica}</div>` : `<div class="muted small" style="margin-top:14px">Use seu PIN para começar o atendimento</div>`}
    ${aviso ? `<div class="badge warn" style="margin-top:10px;display:inline-block">${esc(aviso)}</div>` : ''}
    ${licenca && precisaComprar(licenca) && linkCompra(licenca) ? `<div style="margin-top:10px">${botaoComprar(licenca, 'btn primary sm')}</div>` : ''}
    ${suporte ? `<div style="margin-top:12px"><a class="small" href="${esc(linkWhatsApp(suporte, 'Olá! Preciso de ajuda com o MesaPronta.'))}" target="_blank" rel="noopener">Precisa de ajuda? Fale com o suporte</a></div>` : ''}
  </div></div>`;
  const erro = $('.pin-erro', container);
  const desenhar = () => {
    const n = Math.max(4, pin.length);
    if ($$('.pin-pontos i', container).length !== n) $('.pin-pontos', container).innerHTML = '<i></i>'.repeat(n);
    $$('.pin-pontos i', container).forEach((p, i) => p.classList.toggle('on', i < pin.length));
  };
  const enviar = async () => {
    if (pin.length < 4) return;
    try {
      const r = await POST('/api/login', { pin });
      Sessao.set(r);
      document.removeEventListener('keydown', tecla);
      aoEntrar(r);
    } catch (e) { erro.textContent = e.message; pin = ''; desenhar(); vibrar([60, 40, 60]); }
  };
  const tecla = (e) => {
    if (document.querySelector('.modal-fundo')) return;
    if (/^\d$/.test(e.key) && pin.length < 6) { pin += e.key; erro.textContent = ''; desenhar(); }
    else if (e.key === 'Backspace') { pin = pin.slice(0, -1); desenhar(); }
    else if (e.key === 'Enter') enviar();
  };
  document.addEventListener('keydown', tecla);
  container.querySelector('.pin-teclas').addEventListener('click', (e) => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.n && pin.length < 6) { pin += b.dataset.n; erro.textContent = ''; }
    if (b.dataset.a === 'limpar') pin = '';
    if (b.dataset.a === 'ok') return enviar();
    desenhar();
  });
}

// ---------- Ativação da licença ----------
// Texto curto do contador do teste ("termina em 3 dias" / "termina hoje").
// Link do botão "Comprar": checkout do vendedor (embutido ou vindo do arquivo de status); sem link, cai no WhatsApp.
function linkCompra(st) {
  if (!st) return '';
  if (st.url_compra && /^https:\/\//i.test(st.url_compra)) return st.url_compra;
  if (st.vendedor_whatsapp) return linkWhatsApp(st.vendedor_whatsapp, `Olá! Quero comprar o MesaPronta. Código do computador: ${st.codigo_maquina}`);
  return '';
}
// Mostra o botão de compra enquanto o cliente ainda não tem licença (teste, teste terminado, chave inválida/vencida).
// 3.9.1: adicionais opcionais oferecidos na compra (o servidor manda preço e se a conta já tem)
function ofertaAdicionaisTxt(st) {
  const a = st && st.adicionais; if (!a) return '';
  const it = [a.cardapio && !a.cardapio.tem ? `cardápio online (${brl(Math.round(a.cardapio.valor * 100))}/mês)` : '', a.nota && !a.nota.tem ? `nota fiscal (${brl(Math.round(a.nota.valor * 100))}/mês)` : ''].filter(Boolean);
  return it.length ? `Na compra você também pode escolher ${it.join(' e ')}: opcionais, cobrados à parte só se você marcar, e dá para cancelar quando quiser.` : '';
}
function precisaComprar(st) { return !!st && ['teste', 'expirada', 'invalida'].includes(st.estado); }
function botaoComprar(st, classe = 'btn primary') { const u = linkCompra(st); return u && precisaComprar(st) ? `<a class="${classe}" href="${esc(u)}" target="_blank" rel="noopener" data-comprar>🛒 Comprar agora</a>` : ''; }
function textoTeste(st) {
  if (!st || st.estado !== 'teste') return '';
  const n = Number(st.dias_restantes);
  return n <= 0 ? 'Seu período de teste termina hoje' : n === 1 ? 'Seu período de teste termina amanhã' : `Seu período de teste termina em ${n} dias`;
}
// Primeiro uso do MesaPronta no computador: o cadastro libera o teste grátis e liga o sistema à internet.
function telaRegistro(container, info, aoConcluir, modo = 'entrar', emailInicial = '', opcoes = {}) {
  const P = window.PRODUTO || {}; const nome = P.nome || 'MesaPronta';
  const lic = info.licenca || {};
  const pode_pular = lic.estado === 'ativada';
  const zapSuporte = lic.vendedor_whatsapp || '';
  const pular = pode_pular ? `<button type="button" class="btn ghost sm" id="rg-pular" style="align-self:center">Agora não</button>` : '';
  const olho = (id) => `<button type="button" class="btn ghost sm" data-olho="${id}" style="position:absolute;right:6px;bottom:6px;padding:4px 8px" aria-label="Mostrar a senha">Mostrar</button>`;
  if (modo === 'entrar') {
    container.innerHTML = `<div class="login"><div class="login-caixa stack" style="width:min(460px,100%);text-align:left">
      <div class="logo" style="text-align:center">Mesa<span>Pronta</span></div>
      <h2 style="margin-bottom:0">Entrar na sua conta</h2>
      <p class="muted" style="margin:0">Use o e-mail e a senha da sua conta ${esc(nome)}. Seus dados (cardápio, mesas, vendas e configurações) vêm junto para este computador. A conta fica em um computador por vez: se estiver aberta em outro, ela passa para este.</p>
      <form id="en" class="stack" style="gap:10px">
        <label class="campo" data-c="email">E-mail<input type="email" name="email" required autocomplete="email" placeholder="voce@email.com" value="${esc(emailInicial)}"></label>
        <label class="campo" data-c="senha" style="position:relative">Senha<input type="password" name="senha" id="en-senha" required autocomplete="current-password" style="padding-right:84px">${olho('en-senha')}</label>
        <button class="btn primary lg block" id="en-ok">Entrar</button>
        <div class="row" style="justify-content:space-between;gap:8px;flex-wrap:wrap"><a href="#" id="en-esqueci" class="small" style="color:var(--accent);font-weight:600;text-decoration:none">Esqueci a senha</a><span class="small muted">Precisa de internet para entrar.</span></div>
        <div class="pin-erro" id="erro"></div>
      </form>
      ${opcoes.voltar ? `<div style="text-align:center"><button type="button" class="btn ghost sm" id="en-voltar">Voltar</button></div>` : `<div style="border-top:1px solid var(--line);margin-top:6px;padding-top:14px;text-align:center" class="stack">
        <div class="muted">Ainda não tem conta?</div>
        <button type="button" class="btn block" id="en-criar">${pode_pular ? 'Criar minha conta' : 'Começar meu teste grátis de 7 dias'}</button>
        ${pular}
      </div>`}</div></div>`;
    $('#en').onsubmit = async (e) => {
      e.preventDefault();
      const bt = $('#en-ok'); bt.disabled = true; bt.textContent = 'Entrando e trazendo seus dados…'; $('#erro').textContent = '';
      $$('.campo.erro', container).forEach(x => x.classList.remove('erro'));
      try {
        const r = await POST('/api/nuvem/entrar', Object.fromEntries(new FormData(e.target)));
        if (r.restaurado) toast(`Pronto! Seus dados foram trazidos${r.copia && r.copia.em ? ' (cópia de ' + new Date(r.copia.em).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' }) + ')' : ''}. Entre com o seu PIN de sempre.`, 'ok', { tempo: 9000 });
        else if (r.erro_copia) toast('Você entrou na conta, mas a cópia dos dados não veio agora: ' + r.erro_copia + '. Fale com o suporte se precisar dos dados antigos.', 'alerta', { tempo: 12000 });
        else toast('Pronto! Você entrou na sua conta.', 'ok', { tempo: 6000 });
        aoConcluir();
      } catch (err) {
        $('#erro').textContent = err.message; bt.disabled = false; bt.textContent = 'Entrar';
        const c = err.dados && err.dados.campo && $(`[data-c="${err.dados.campo}"]`, container); if (c) c.classList.add('erro');
      }
    };
    $('#en-esqueci').onclick = (e) => {
      e.preventDefault();
      const em = $('#en [name=email]').value.trim();
      const msg = `Olá! Esqueci a senha da minha conta ${nome}.${em ? ' Meu e-mail: ' + em : ''}`;
      if (zapSuporte) window.open(linkWhatsApp(zapSuporte, msg), '_blank');
      else toast('Fale com o suporte do ' + nome + ' para criar uma senha nova.', 'alerta');
    };
    if ($('#en-criar')) $('#en-criar').onclick = () => telaRegistro(container, info, aoConcluir, 'criar');
    if ($('#en-voltar')) $('#en-voltar').onclick = () => opcoes.voltar();
  } else {
    container.innerHTML = `<div class="login"><div class="login-caixa stack" style="width:min(500px,100%);text-align:left">
      <div class="logo" style="text-align:center">Mesa<span>Pronta</span></div>
      <h2 style="margin-bottom:0">${pode_pular ? 'Complete seu cadastro' : 'Comece seu teste grátis de 7 dias'}</h2>
      <p class="muted" style="margin:0">${pode_pular ? 'Deixe seus dados para receber suporte e as novidades do ' + nome + '.' : 'Preencha uma vez e pronto. O ' + nome + ' funciona neste computador mesmo sem internet — e, com internet, ganha cardápio online, cópia de segurança dos dados e atualizações automáticas.'}</p>
      <form id="rg" class="stack" style="gap:10px">
        <label class="campo" data-c="nome_loja">Nome do restaurante<input type="text" name="nome_loja" required maxlength="60" value="${esc(info.nome && info.nome !== 'Meu Restaurante' ? info.nome : '')}" placeholder="Ex.: Restaurante do Zé"></label>
        <label class="campo" data-c="nome">Seu nome<input type="text" name="nome" required maxlength="60" autocomplete="name"></label>
        <div class="grid2"><label class="campo" data-c="whatsapp">WhatsApp<input type="tel" name="whatsapp" required inputmode="tel" placeholder="(00) 00000-0000" autocomplete="tel"></label>
          <label class="campo" data-c="email">E-mail<input type="email" name="email" required autocomplete="email" placeholder="voce@email.com"></label></div>
        <label class="campo" data-c="senha" style="position:relative">Crie uma senha<input type="password" name="senha" id="rg-senha" required minlength="6" autocomplete="new-password" placeholder="pelo menos 6 letras ou números" style="padding-right:84px">${olho('rg-senha')}</label>
        <button class="btn primary lg block" id="rg-ok">${pode_pular ? 'Salvar' : 'Começar meu teste grátis'}</button>
        <div class="small muted">Com este e-mail e esta senha você entra em outro computador e pelo site. Use o mesmo e-mail se for comprar: a licença libera sozinha.</div>
        <div class="pin-erro" id="erro"></div>
      </form>
      <div style="text-align:center" class="stack"><button type="button" class="btn ghost sm" id="rg-entrar" style="align-self:center">Já tenho conta — entrar</button>${pular}</div>
      </div></div>`;
    $('#rg').onsubmit = async (e) => {
      e.preventDefault();
      const b = $('#rg-ok'); b.disabled = true; b.textContent = 'Aguarde…'; $('#erro').textContent = '';
      $$('.campo.erro', container).forEach(x => x.classList.remove('erro'));
      try {
        const r = await POST('/api/nuvem/registrar', Object.fromEntries(new FormData(e.target)));
        toast(r.online ? '🎉 Pronto! Seu teste grátis começou.' : 'Pronto! Seu teste começou. Assim que tiver internet, o sistema termina o cadastro sozinho.', 'ok', { tempo: 6000 });
        aoConcluir();
      } catch (err) {
        $('#erro').textContent = err.message; b.disabled = false; b.textContent = pode_pular ? 'Salvar' : 'Começar meu teste grátis';
        const c = err.dados && err.dados.campo && $(`[data-c="${err.dados.campo}"]`, container); if (c) c.classList.add('erro');
        if (err.dados && err.dados.ja_tem_conta) {   // um e-mail = uma conta: leva para "Entrar" com o e-mail preenchido
          const bt = document.createElement('button'); bt.type = 'button'; bt.className = 'btn primary block'; bt.id = 'rg-ir-entrar'; bt.style.marginTop = '8px';
          bt.textContent = 'Entrar com este e-mail'; bt.onclick = () => telaRegistro(container, info, aoConcluir, 'entrar', err.dados.email || '');
          $('#erro').appendChild(bt);
        }
      }
    };
    $('#rg-entrar').onclick = () => telaRegistro(container, info, aoConcluir, 'entrar', ($('#rg [name=email]') || {}).value || '');
  }
  $$('[data-olho]', container).forEach(bt => bt.onclick = () => { const i = $('#' + bt.dataset.olho); const ver = i.type === 'password'; i.type = ver ? 'text' : 'password'; bt.textContent = ver ? 'Esconder' : 'Mostrar'; });
  const pl = $('#rg-pular'); if (pl) pl.onclick = async () => { await POST('/api/nuvem/registrar', { pular: true }).catch(() => null); aoConcluir(); };
  setTimeout(() => { const f = modo === 'entrar' ? (emailInicial ? $('#en-senha') : $('#en [name=email]')) : $('#rg [name=' + ($('#rg [name=nome_loja]').value ? 'nome' : 'nome_loja') + ']'); if (f) f.focus(); }, 50);
}
// Versão online: sem código nem chave — compra na Kirvano e a licença ativa sozinha.
function telaAtivacaoNuvem(container, st, aoAtivar) {
  const P = window.PRODUTO || {}; const nome = P.nome || 'MesaPronta';
  const wa = st.vendedor_whatsapp ? linkWhatsApp(st.vendedor_whatsapp, `Olá! ${st.estado === 'revogada' ? 'Minha licença do' : 'Meu teste do'} ${nome} online (${location.host}) ${st.estado === 'revogada' ? 'foi suspensa' : 'terminou'}. Pode me ajudar?`) : '';
  const revogada = st.estado === 'revogada';
  const vencida = !!st.vencida_em;
  const comprar = linkCompra(st); const o = st.oferta || {};
  container.innerHTML = `<div class="login"><div class="login-caixa stack" style="width:min(480px,100%);text-align:left">
    <div class="logo" style="text-align:center">Mesa<span>Pronta</span></div>
    <h2>${revogada ? 'Licença suspensa' : vencida ? 'Sua licença venceu' : 'Seu teste grátis terminou'}</h2>
    <p class="muted" style="margin:0">${revogada ? esc(st.erro || 'Fale com o suporte.') : 'Tudo o que você cadastrou continua guardado: produtos, mesas, vendas e configurações. É só comprar para continuar de onde parou.'}</p>
    ${!revogada && comprar ? `<div class="card pad stack" style="background:var(--accent-soft);border:0;box-shadow:none;gap:8px">${o.preco ? `<div><b style="font-size:26px">${esc(o.preco)}</b> <span class="muted">${esc(o.descricao || '')}</span></div>` : ''}
      <a class="btn primary lg block" href="${esc(comprar)}" target="_blank" rel="noopener">Comprar agora — Pix ou cartão</a>
      <div class="small muted">Pix ou cartão em até 12x. Assim que o pagamento for aprovado, o sistema libera sozinho nesta tela.</div>${ofertaAdicionaisTxt(st) ? `<div class="small muted">${esc(ofertaAdicionaisTxt(st))}</div>` : ''}</div>` : ''}
    ${wa ? `<a class="btn ok block" href="${wa}" target="_blank" rel="noopener">💬 Falar no WhatsApp</a>` : ''}
    ${!revogada && st.mais_dias_disponivel ? `<button class="btn block" id="mais-dias">Preciso de mais 3 dias para testar</button>` : ''}
    <button class="btn ghost block" id="reverificar">⟳ Já paguei — verificar</button>
    ${st.compra_online ? `<button class="btn ghost sm" id="tenho-chave" style="align-self:center">Tenho uma chave de ativação</button>` : ''}
    <div class="pin-erro" id="erro"></div></div></div>`;
  const tc = $('#tenho-chave'); if (tc) tc.onclick = () => telaAtivacao(container, st, aoAtivar, { chave: true });
  const conferir = async () => { await POST('/api/nuvem/verificar').catch(() => null); return GET('/api/licenca').catch(() => null); };
  const md = $('#mais-dias'); if (md) md.onclick = async () => { md.disabled = true; try { await POST('/api/licenca/mais-dias'); toast('Pronto! Você ganhou mais 3 dias de teste.', 'ok'); aoAtivar(null); } catch (e) { $('#erro').textContent = e.message; md.disabled = false; } };
  const rv = $('#reverificar'); rv.onclick = async () => { rv.disabled = true; const st2 = await conferir(); if (st2 && !st2.bloqueado) { toast('Licença ativa! Obrigado.', 'ok'); return aoAtivar(st2); } $('#erro').textContent = 'Ainda não recebemos a confirmação do pagamento. Pix costuma levar até 1 minuto; cartão, alguns minutos. Se já faz mais tempo, fale no WhatsApp.'; rv.disabled = false; };
  // confere sozinho a cada 20 s (a compra aprovada libera sem precisar clicar)
  const timer = setInterval(async () => { if (!document.body.contains(rv)) return clearInterval(timer); const st2 = await conferir(); if (st2 && !st2.bloqueado) { clearInterval(timer); toast('🎉 Pagamento aprovado! Licença ativa.', 'ok'); aoAtivar(st2); } }, 20000);
}
function telaAtivacao(container, st, aoAtivar, opcoes = {}) {
  if (st && (st.nuvem || st.compra_online) && !opcoes.chave) return telaAtivacaoNuvem(container, st, aoAtivar);
  const wa = st.vendedor_whatsapp ? linkWhatsApp(st.vendedor_whatsapp, `Olá! Quero ativar o MesaPronta. Código do computador: ${st.codigo_maquina}`) : '';
  const revogada = st.estado === 'revogada';
  const titulo = revogada ? 'Licença cancelada' : st.estado === 'expirada' ? 'O período de teste terminou' : st.estado === 'invalida' ? (st.expira && /expirada/i.test(st.erro || '') ? 'A licença venceu' : 'Chave de ativação inválida') : 'Ativar o MesaPronta';
  container.innerHTML = `<div class="login"><div class="login-caixa stack" style="width:min(520px,100%);text-align:left">
    <div class="logo" style="text-align:center">Mesa<span>Pronta</span></div>
    <h2>${titulo}</h2>
    ${st.erro ? `<p style="color:var(--danger)">${esc(st.erro)}</p>` : ''}
    ${revogada ? `<p class="muted">O sistema foi bloqueado a pedido de ${esc(st.vendedor_nome || 'o vendedor')} (compra cancelada ou estornada). Se você acha que isso é um engano, fale com ele${wa ? ' pelo botão abaixo' : ''}. Assim que ele liberar, clique em "Verificar de novo".</p>
      <div class="row wrap" style="gap:8px">${wa ? `<a class="btn primary" href="${wa}" target="_blank">Falar com ${esc(st.vendedor_nome || 'o vendedor')}</a>` : ''}<button class="btn" id="reverificar">⟳ Verificar de novo</button></div>
      <div class="card pad" style="text-align:center"><div class="muted small" style="font-weight:700">CÓDIGO DESTE COMPUTADOR</div><div class="codigo-maquina" id="cod">${esc(st.codigo_maquina)}</div></div>
      <div class="pin-erro" id="erro"></div></div></div>`
    : `${linkCompra(st) ? `<div class="card pad" style="background:var(--accent-soft);border:0;box-shadow:none"><b>${st.estado === 'teste' ? 'Gostou? Garanta o seu.' : 'Para continuar usando, compre a licença.'}</b>${st.oferta && st.oferta.preco ? `<div><b style="font-size:22px">${esc(st.oferta.preco)}</b></div>` : ''}<div class="small muted" style="margin:4px 0 8px">${st.compra_automatica ? 'Pix ou cartão. Depois do pagamento a licença <b>ativa sozinha</b> neste computador (com internet). Nada do que você cadastrou se perde.' : 'Depois da compra, envie o código deste computador e você recebe a chave de ativação. Nada do que você cadastrou se perde.'}</div>${botaoComprar(st, 'btn primary lg block')}${st.compra_automatica ? '<button class="btn block" id="buscar-lic" style="margin-top:8px">⟳ Já paguei — verificar</button>' : ''}</div>` : ''}
    <p class="muted">${st.estado === 'teste' ? textoTeste(st) + '. ' : ''}${st.compra_automatica ? 'Recebeu uma chave de ativação? Cole abaixo.' : `${st.estado === 'teste' ? 'Já comprou? ' : ''}Envie o código abaixo para ${esc(st.vendedor_nome || 'o vendedor')} e cole aqui a chave de ativação que você receber.`}</p>
    <div class="card pad" style="text-align:center"><div class="muted small" style="font-weight:700">CÓDIGO DESTE COMPUTADOR</div>
      <div class="codigo-maquina" id="cod">${esc(st.codigo_maquina)}</div>
      <div class="row" style="justify-content:center;gap:8px"><button class="btn sm" id="copiar">Copiar código</button>${wa ? `<a class="btn sm" href="${wa}" target="_blank">Enviar pelo WhatsApp</a>` : ''}</div></div>
    <label class="campo">Chave de ativação<textarea id="chave" rows="3" placeholder="${(window.PRODUTO && window.PRODUTO.prefixo) || 'MP'}1.xxxxx.xxxxx" style="font-family:var(--mono);font-size:13px"></textarea></label>
    <button class="btn primary lg block" id="ativar">Ativar</button>
    <div class="pin-erro" id="erro"></div>
    ${st.estado === 'teste' ? `<button class="btn ghost block" id="depois">Continuar o teste${Number(st.dias_restantes) > 0 ? ` (${st.dias_restantes} dia${st.dias_restantes > 1 ? 's' : ''} restante${st.dias_restantes > 1 ? 's' : ''})` : ' (termina hoje)'}</button>` : ''}
  </div></div>`}`;
  const cp = $('#copiar'); if (cp) cp.onclick = () => { navigator.clipboard?.writeText(st.codigo_maquina).then(() => toast('Código copiado', 'ok')); };
  const bl = $('#buscar-lic');
  if (bl) {
    const buscar = async (manual) => { if (manual) bl.disabled = true; const r = await POST('/api/licenca/buscar').catch(() => null); if (r && !r.bloqueado && r.estado === 'ativada') { clearInterval(tmr); toast('🎉 Pagamento aprovado! Licença ativa.', 'ok'); return aoAtivar(r); } if (manual) { bl.disabled = false; $('#erro').textContent = r && r.busca && r.busca.ok === false ? 'Sem internet para verificar. Confira a conexão do computador.' : 'Ainda não encontramos o pagamento. Pix leva alguns segundos; cartão, até 1 minuto. Continuamos verificando sozinhos.'; } };
    bl.onclick = () => buscar(true);
    const tmr = setInterval(() => { if (!document.body.contains(bl)) return clearInterval(tmr); buscar(false); }, 20000);
  }
  const at = $('#ativar'); if (at) at.onclick = async () => {
    try { const r = await POST('/api/licenca/ativar', { chave: $('#chave').value }); toast('Ativado! Obrigado.', 'ok'); aoAtivar(r); }
    catch (e) { $('#erro').textContent = e.message; }
  };
  const rv = $('#reverificar'); if (rv) rv.onclick = async () => {
    rv.disabled = true; rv.textContent = 'Verificando...';
    try { const r = await POST('/api/atualizacao/verificar'); if (!r.ok) throw new Error(r.erro || 'Sem conexão'); const st2 = await GET('/api/licenca'); if (!st2.bloqueado) { toast('Licença liberada!', 'ok'); return aoAtivar(st2); } $('#erro').textContent = 'A licença continua cancelada.'; }
    catch (e) { $('#erro').textContent = 'Não foi possível verificar agora (' + e.message + '). Confira a internet e tente de novo.'; }
    rv.disabled = false; rv.textContent = '⟳ Verificar de novo';
  };
  const d = $('#depois'); if (d) d.onclick = () => aoAtivar(null);
}

// ---------- Tempo real ----------
function conectarEventos(manipuladores) {
  let es;
  const abrir = () => {
    es = new EventSource('/api/eventos');
    let caiu = null;
    es.onopen = () => { clearTimeout(caiu); caiu = null; PeloWifi.aviso(false); manipuladores.conectado?.(); };
    es.onerror = () => { if (!caiu) caiu = setTimeout(() => PeloWifi.aviso(true), 10000); manipuladores.desconectado?.(); };
    for (const [tipo, fn] of Object.entries(manipuladores)) {
      if (tipo === 'conectado' || tipo === 'desconectado') continue;
      es.addEventListener(tipo, (ev) => { let d = {}; try { d = JSON.parse(ev.data); } catch {} fn(d); });
    }
  };
  abrir();
  return () => es && es.close();
}
function adiar(fn, ms = 150) {
  let t;
  return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
}
function imprimirTexto(texto) {
  let area = $('#area-impressao');
  if (!area) { area = document.createElement('div'); area.id = 'area-impressao'; document.body.appendChild(area); }
  area.innerHTML = '<pre></pre>';
  area.firstChild.textContent = texto;
  setTimeout(() => window.print(), 50);
}
function detalheItem(it) {
  const ads = typeof it.adicionais === 'string' ? JSON.parse(it.adicionais || '[]') : (it.adicionais || []);
  const partes = ads.map(a => '+ ' + (a.nome || a));
  if (it.obs) partes.push('Obs: ' + it.obs);
  return partes.join(' · ');
}

// ---------- Escolha de produto (tamanhos, meio a meio, adicionais, obs rápidas) ----------
// Retorna {produto_id, produto2_id, tamanho, qtd, obs, adicionais:[ids], _nome, _preco, _ads} ou null.
const PRECO_LIVRE = () => !!(window.PRODUTO && window.PRODUTO.recursos && window.PRODUTO.recursos.preco_livre);
function escolherProduto(produto, card, opcoes = {}) {
  if (produto.esgotado) { toast(`${produto.nome} está esgotado`, 'erro'); return Promise.resolve(null); }
  const cat = (card.categorias || []).find(c => c.id === produto.categoria_id) || {};
  const ads = (card.adicionais || []).filter(a => !a.categoria_id || a.categoria_id === produto.categoria_id);
  const tamanhos = produto.tamanhos || [];
  const obsRapidas = [...new Map([...String(cat.obs_rapidas || '').split(';'), ...String(card.obs_rapidas_gerais || '').split(';')].map(s => s.trim()).filter(Boolean).map(s => [s.toLowerCase(), s])).values()];
  const irmaos = cat.meio_a_meio ? (card.produtos || []).filter(p => p.categoria_id === produto.categoria_id && p.id !== produto.id && !p.esgotado) : [];
  const regra = card.meio_a_meio_regra || 'maior';
  const precoBase = (p, tam) => tam ? (p.tamanhos.find(t => t.nome === tam)?.preco ?? p.preco) : (p.preco_atual ?? p.preco);
  const tamPadrao = tamanhos.length && window.PRODUTO_TAMANHO_PADRAO ? window.PRODUTO_TAMANHO_PADRAO(produto, tamanhos) : null;
  let tamanho = tamanhos.length ? (tamanhos.find(t => t.nome === tamPadrao) || tamanhos[1] || tamanhos[0]).nome : null;
  let segundo = null;
  const escolha = produto.escolha && Array.isArray(produto.escolha.opcoes) && produto.escolha.opcoes.length ? produto.escolha : null;
  let opcaoEsc = null;

  return modal({
    titulo: produto.nome, focar: false,
    corpo: `<div class="stack">
      ${produto.foto ? `<img src="${esc(produto.foto)}" alt="" class="foto-modal">` : ''}
      ${produto.descricao ? `<div class="muted small">${esc(produto.descricao)}</div>` : ''}
      ${tamanhos.length ? `<div><div class="rotulo">${window.PRODUTO?.termos?.tamanho ? esc(window.PRODUTO.termos.tamanho).toUpperCase() : 'TAMANHO'}</div><div class="chips" id="mp-tam">${tamanhos.map(t => `<button class="chip ${t.nome === tamanho ? 'on' : ''}" data-tam="${esc(t.nome)}">${esc(t.nome)} <span class="muted">${brl(t.preco)}</span></button>`).join('')}</div></div>` : ''}
      ${escolha ? `<div><div class="rotulo">${esc(escolha.titulo).toUpperCase()} <span class="badge warn" style="text-transform:none">escolha 1</span></div><div class="chips" id="mp-esc">${escolha.opcoes.map(o => `<button class="chip" data-esc="${esc(o)}">${esc(o)}</button>`).join('')}</div></div>` : ''}
      ${irmaos.length ? `<div><div class="rotulo">MEIO A MEIO <span class="muted" style="text-transform:none;font-weight:500">(cobra ${regra === 'media' ? 'a média' : 'o maior'})</span></div>
        <div class="chips" id="mp-meio"><button class="chip on" data-meio="">Inteira</button>${irmaos.map(p => `<button class="chip" data-meio="${p.id}">½ ${esc(p.nome)}</button>`).join('')}</div></div>` : ''}
      <div class="row" style="justify-content:center;gap:16px">
        <button class="btn lg" data-q="-1" style="width:56px">−</button>
        <b id="mp-qtd" class="num" style="font-size:28px;min-width:40px;text-align:center">1</b>
        <button class="btn lg" data-q="1" style="width:56px">+</button>
        <span class="spacer"></span><b id="mp-preco" class="num" style="font-size:20px;color:var(--accent)"></b>
      </div>
      ${PRECO_LIVRE() ? `<label class="campo">Preço unitário (R$) <span class="muted small">— ajuste se precisar</span><input type="text" inputmode="decimal" id="mp-pl" value="${brlCurto(precoBase(produto, tamanho))}" style="font-size:18px;font-weight:700"></label>` : ''}
      ${ads.length ? `<div><div class="rotulo">ADICIONAIS</div>
        <div class="stack" style="gap:6px">${ads.map(a => `<label class="check card" style="padding:10px 12px;box-shadow:none">
          <input type="checkbox" value="${a.id}" data-preco="${a.preco}"> <span class="spacer">${esc(a.nome)}</span> <span class="num muted">${a.preco ? '+' + brl(a.preco) : 'grátis'}</span></label>`).join('')}</div></div>` : ''}
      ${obsRapidas.length ? `<div><div class="rotulo">OBSERVAÇÕES RÁPIDAS</div><div class="chips" id="mp-obsr">${obsRapidas.map(o => `<button class="chip" data-obs="${esc(o)}">${esc(o)}</button>`).join('')}</div></div>` : ''}
      <label class="campo">Observação<input type="text" id="mp-obs" placeholder="${esc(window.PRODUTO?.termos?.obs_exemplo || (window.PRODUTO?.recursos?.cozinha === false ? 'Ex.: detalhe do item' : 'Ex.: sem cebola, bem passado'))}" value="${esc(opcoes.obs || '')}"></label>
    </div>`,
    botoes: [{ texto: 'Cancelar' }, {
      texto: 'Adicionar', classe: 'primary', padrao: true, acao: (f) => {
        const qtd = Number($('#mp-qtd', f).textContent);
        if (escolha && !opcaoEsc) { const g = $('#mp-esc', f); if (g) { g.classList.remove('treme'); void g.offsetWidth; g.classList.add('treme'); } throw new Error(`Escolha ${escolha.titulo.toLowerCase()}`); }
        const sel = $$('input[type=checkbox]:checked', f);
        const adsSel = sel.map(c => ads.find(a => a.id === Number(c.value)));
        const p2 = segundo ? irmaos.find(p => p.id === segundo) : null;
        let preco = precoBase(produto, tamanho);
        if (p2) { const b = precoBase(p2, tamanho); preco = regra === 'media' ? Math.round((preco + b) / 2) : Math.max(preco, b); }
        const nome = (p2 ? `½ ${produto.nome} + ½ ${p2.nome}` : produto.nome) + (tamanho ? ` (${tamanho})` : '');
        const pl = $('#mp-pl', f); let livre = null;
        if (pl) { livre = paraCentavos(pl.value); if (!(livre >= 0) || pl.value.trim() === '') throw new Error('Informe o preço'); if (livre !== preco) preco = livre; else livre = null; }
        const obsEsc = [escolha ? `${escolha.titulo}: ${opcaoEsc}` : '', $('#mp-obs', f).value.trim()].filter(Boolean).join(', ').slice(0, 120);
        return { produto_id: produto.id, produto2_id: p2 ? p2.id : null, tamanho, qtd, obs: obsEsc, adicionais: adsSel.map(a => a.id), preco_livre: livre,
          _nome: nome, _preco: preco + adsSel.reduce((s, a) => s + a.preco, 0), _ads: adsSel };
      },
    }],
    aoAbrir: (f) => {
      const atualizarPreco = () => {
        const p2 = segundo ? irmaos.find(p => p.id === segundo) : null;
        let preco = precoBase(produto, tamanho);
        if (p2) { const b = precoBase(p2, tamanho); preco = regra === 'media' ? Math.round((preco + b) / 2) : Math.max(preco, b); }
        const pl = $('#mp-pl', f); if (pl) { if (pl.dataset.manual) preco = paraCentavos(pl.value) || 0; else pl.value = brlCurto(preco); }
        preco += $$('input[type=checkbox]:checked', f).reduce((s, c) => s + Number(c.dataset.preco), 0);
        $('#mp-preco', f).textContent = brl(preco * Number($('#mp-qtd', f).textContent));
      };
      f.addEventListener('change', atualizarPreco);
      const pl0 = $('#mp-pl', f); if (pl0) { pl0.addEventListener('input', () => { pl0.dataset.manual = '1'; atualizarPreco(); }); pl0.addEventListener('focus', () => pl0.select()); }
      f.addEventListener('click', (e) => {
        const q = e.target.closest('[data-q]');
        if (q) { const el = $('#mp-qtd', f); el.textContent = Math.max(1, Number(el.textContent) + Number(q.dataset.q)); }
        const t = e.target.closest('[data-tam]');
        if (t) { tamanho = t.dataset.tam; $$('[data-tam]', f).forEach(x => x.classList.toggle('on', x === t)); const pl = $('#mp-pl', f); if (pl) delete pl.dataset.manual; }
        const es = e.target.closest('[data-esc]');
        if (es) { opcaoEsc = es.dataset.esc; $$('[data-esc]', f).forEach(x => x.classList.toggle('on', x === es)); }
        const m = e.target.closest('[data-meio]');
        if (m) { segundo = m.dataset.meio ? Number(m.dataset.meio) : null; $$('[data-meio]', f).forEach(x => x.classList.toggle('on', x === m)); }
        const o = e.target.closest('[data-obs]');
        if (o) {
          const inp = $('#mp-obs', f);
          const partes = inp.value.split(',').map(s => s.trim()).filter(Boolean);
          const i = partes.findIndex(s => s.toLowerCase() === o.dataset.obs.toLowerCase());
          if (i >= 0) { partes.splice(i, 1); o.classList.remove('on'); } else { partes.push(o.dataset.obs); o.classList.add('on'); }
          inp.value = partes.join(', ');
        }
        if (q || t || m) atualizarPreco();
      });
      atualizarPreco();
    },
  });
}

// ---------- Campo de "bolinhas" (chips): digita, Enter, vira uma bolinha ----------
// montarChips(el, valores[]) -> { get(): string[] }
function montarChips(el, valores = [], placeholder = 'Digite e aperte Enter') {
  let lista = [...valores].filter(Boolean);
  el.classList.add('chips-campo');
  const desenhar = () => {
    el.innerHTML = lista.map((v, i) => `<span class="chip on">${esc(v)}<button type="button" data-rm="${i}" aria-label="Remover">✕</button></span>`).join('') + `<input type="text" placeholder="${esc(placeholder)}">`;
    const inp = $('input', el);
    inp.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ';' || e.key === ',') { e.preventDefault(); e.stopPropagation(); const val = inp.value; inp.value = ''; add(val); }
      else if (e.key === 'Backspace' && !inp.value && lista.length) { lista.pop(); desenhar(); $('input', el).focus(); }
    });
    inp.addEventListener('blur', () => { if (inp.value.trim() && inp.isConnected) { const val = inp.value; inp.value = ''; add(val); } });
  };
  const add = (v) => { v = String(v).trim(); if (!v) return; if (!lista.some(x => x.toLowerCase() === v.toLowerCase())) lista.push(v); desenhar(); $('input', el).focus(); };
  el.addEventListener('click', (e) => { const b = e.target.closest('[data-rm]'); if (b) { lista.splice(Number(b.dataset.rm), 1); desenhar(); } else if (e.target === el) $('input', el)?.focus(); });
  desenhar();
  return { get: () => lista.slice(), set: (v) => { lista = [...v]; desenhar(); } };
}

// ---------- Pizza "monte a sua": tamanho → 1 ou 2 sabores → sabores → borda/adicionais → obs ----------
// cat = categoria com meio_a_meio; card = cardápio; pre = produto pré-selecionado (opcional)
function montarPizza(cat, card, pre = null) {
  const sabores = (card.produtos || []).filter(p => p.categoria_id === cat.id);
  if (!sabores.length) return Promise.resolve(null);
  const tamanhos = (sabores.find(p => p.tamanhos?.length) || {}).tamanhos || [];
  const ads = (card.adicionais || []).filter(a => !a.categoria_id || a.categoria_id === cat.id);
  const obsRapidas = [...new Map([...String(cat.obs_rapidas || '').split(';'), ...String(card.obs_rapidas_gerais || '').split(';')].map(s => s.trim()).filter(Boolean).map(s => [s.toLowerCase(), s])).values()];
  const regra = card.meio_a_meio_regra || 'maior';
  const precoDe = (p, tam) => tam ? (p.tamanhos?.find(t => t.nome === tam)?.preco ?? p.preco) : (p.preco_atual ?? p.preco);
  const E = { tamanho: tamanhos.length ? (tamanhos[1] || tamanhos[0]).nome : null, qtdSabores: pre ? 1 : 0, sabores: pre ? [pre.id] : [], qtd: 1 };
  const nomeCat = cat.nome.replace(/s$/i, '');
  return modal({
    titulo: `🍕 ${nomeCat} — monte a sua`, largo: true, focar: false,
    corpo: '<div id="pz"></div>',
    botoes: [{ texto: 'Cancelar' }, { texto: 'Adicionar', classe: 'primary', acao: (f) => {
      if (!E.sabores.length) throw new Error('Escolha o sabor');
      if (E.qtdSabores === 2 && E.sabores.length < 2) throw new Error('Escolha o segundo sabor');
      const s1 = sabores.find(p => p.id === E.sabores[0]), s2 = E.sabores[1] ? sabores.find(p => p.id === E.sabores[1]) : null;
      let preco = precoDe(s1, E.tamanho);
      if (s2) { const b = precoDe(s2, E.tamanho); preco = regra === 'media' ? Math.round((preco + b) / 2) : Math.max(preco, b); }
      const adsSel = $$('input[type=checkbox]:checked', f).map(c => ads.find(a => a.id === Number(c.value)));
      const nome = (s2 ? `½ ${s1.nome} + ½ ${s2.nome}` : s1.nome) + (E.tamanho ? ` (${E.tamanho})` : '');
      return { produto_id: s1.id, produto2_id: s2 ? s2.id : null, tamanho: E.tamanho, qtd: E.qtd, obs: $('#pz-obs', f).value.trim(), adicionais: adsSel.map(a => a.id), _nome: nome, _preco: preco + adsSel.reduce((x, a) => x + a.preco, 0), _ads: adsSel };
    } }],
    aoAbrir: (f) => {
      const desenhar = () => {
        const passo = !E.qtdSabores ? 1 : E.sabores.length < E.qtdSabores ? 2 : 3;
        const s1 = E.sabores[0] ? sabores.find(p => p.id === E.sabores[0]) : null, s2 = E.sabores[1] ? sabores.find(p => p.id === E.sabores[1]) : null;
        let preco = s1 ? precoDe(s1, E.tamanho) : 0;
        if (s1 && s2) { const b = precoDe(s2, E.tamanho); preco = regra === 'media' ? Math.round((preco + b) / 2) : Math.max(preco, b); }
        const obsAtual = $('#pz-obs', f)?.value || '';
        $('#pz', f).innerHTML = `<div class="stack">
          ${tamanhos.length ? `<div><div class="rotulo">1. TAMANHO</div><div class="chips">${tamanhos.map(t => `<button type="button" class="chip ${t.nome === E.tamanho ? 'on' : ''}" data-tam="${esc(t.nome)}">${esc(t.nome)} <span class="muted">${brl(Math.min(...sabores.map(p => precoDe(p, t.nome))))}+</span></button>`).join('')}</div></div>` : ''}
          <div><div class="rotulo">${tamanhos.length ? '2' : '1'}. QUANTOS SABORES?</div><div class="opcoes-grandes"><button type="button" class="opc ${E.qtdSabores === 1 ? 'on' : ''}" data-ns="1">🍕 Um sabor</button><button type="button" class="opc ${E.qtdSabores === 2 ? 'on' : ''}" data-ns="2">🍕🍕 Dois sabores <span class="muted small">(cobra ${regra === 'media' ? 'a média' : 'o mais caro'})</span></button></div></div>
          ${E.qtdSabores ? `<div><div class="rotulo">${tamanhos.length ? '3' : '2'}. ${E.qtdSabores === 2 ? 'ESCOLHA OS DOIS SABORES' : 'ESCOLHA O SABOR'} ${E.sabores.length ? `<span class="muted" style="text-transform:none;font-weight:500">— ${E.sabores.map(id => sabores.find(p => p.id === id)?.nome).join(' + ')}</span>` : ''}</div>
            <div class="sabores">${sabores.map(p => `<button type="button" class="sabor ${E.sabores.includes(p.id) ? 'on' : ''} ${p.esgotado ? 'esgotado' : ''}" data-sab="${p.id}" ${p.esgotado ? 'disabled' : ''}>${p.foto ? `<img src="${esc(p.foto)}" alt="">` : ''}<span><b>${esc(p.nome)}</b>${p.descricao ? `<small>${esc(p.descricao)}</small>` : ''}</span><span class="num">${brl(precoDe(p, E.tamanho))}</span></button>`).join('')}</div></div>` : ''}
          ${passo === 3 ? `<div class="row" style="justify-content:center;gap:16px"><button type="button" class="btn lg" data-q="-1" style="width:56px">−</button><b id="pz-qtd" class="num" style="font-size:28px;min-width:40px;text-align:center">${E.qtd}</b><button type="button" class="btn lg" data-q="1" style="width:56px">+</button><span class="spacer"></span><b class="num" style="font-size:22px;color:var(--accent)">${brl(preco * E.qtd)}</b></div>
            ${ads.length ? `<div><div class="rotulo">BORDA / ADICIONAIS</div><div class="stack" style="gap:6px">${ads.map(a => `<label class="check card" style="padding:10px 12px;box-shadow:none"><input type="checkbox" value="${a.id}"> <span class="spacer">${esc(a.nome)}</span> <span class="num muted">${a.preco ? '+' + brl(a.preco) : 'grátis'}</span></label>`).join('')}</div></div>` : ''}
            ${obsRapidas.length ? `<div><div class="rotulo">OBSERVAÇÕES RÁPIDAS</div><div class="chips">${obsRapidas.map(o => `<button type="button" class="chip" data-obs="${esc(o)}">${esc(o)}</button>`).join('')}</div></div>` : ''}
            <label class="campo">Observação<input type="text" id="pz-obs" value="${esc(obsAtual)}" placeholder="Ex.: bem assada, sem cebola"></label>` : '<label class="campo hidden">Obs<input type="text" id="pz-obs"></label>'}
        </div>`;
      };
      f.addEventListener('click', (e) => {
        const t = e.target.closest('[data-tam]'); if (t) { E.tamanho = t.dataset.tam; desenhar(); }
        const n = e.target.closest('[data-ns]'); if (n) { E.qtdSabores = Number(n.dataset.ns); if (E.sabores.length > E.qtdSabores) E.sabores = E.sabores.slice(0, E.qtdSabores); desenhar(); }
        const sb = e.target.closest('[data-sab]');
        if (sb) { const id = Number(sb.dataset.sab); if (E.sabores.includes(id)) E.sabores = E.sabores.filter(x => x !== id); else { if (E.sabores.length >= E.qtdSabores) E.sabores.shift(); E.sabores.push(id); } desenhar(); }
        const q = e.target.closest('[data-q]'); if (q) { E.qtd = Math.max(1, E.qtd + Number(q.dataset.q)); desenhar(); }
        const o = e.target.closest('[data-obs]');
        if (o) { const inp = $('#pz-obs', f); const partes = inp.value.split(',').map(x => x.trim()).filter(Boolean); const i = partes.findIndex(x => x.toLowerCase() === o.dataset.obs.toLowerCase()); if (i >= 0) { partes.splice(i, 1); o.classList.remove('on'); } else { partes.push(o.dataset.obs); o.classList.add('on'); } inp.value = partes.join(', '); }
      });
      desenhar();
    },
  });
}

// ---------- Fotos de produtos ----------
// Desenho do produto sem foto: escolhido pela categoria e, se não der, pelo nome.
const ARTE = {
  copo: 'M22 14h20l-3 39H25ZM29 14l3-8h12M24 29h16',
  pizza: 'M13 17q19-13 38 0L32 55ZM16 22q16-10 32 0M26 28h.1M38 30h.1M31 40h.1',
  lanche: 'M13 28q2-18 19-18t19 18ZM11 34h42M14 40l8-3 10 5 10-5 8 3M14 46h36q0 9-8 9H22q-8 0-8-9ZM25 19h.1m10-3h.1m6 6h.1',
  doce: 'M20 30h24l-4 24H24ZM18 30q0-14 14-14t14 14M32 16v-6M27 38h10',
  prato: 'M32 53a21 21 0 1 0 0-42 21 21 0 0 0 0 42M32 45a13 13 0 1 0 0-26 13 13 0 0 0 0 26M5 16v15m-3-15v8q3 5 6 0v-8M5 31v20M59 16v35',
  tesoura: 'M20 46a7 7 0 1 0 0-14 7 7 0 0 0 0 14m24 0a7 7 0 1 0 0-14 7 7 0 0 0 0 14M25 36 46 12M39 36 18 12',
  ticket: 'M8 22h48v8a4 4 0 0 0 0 8v8H8v-8a4 4 0 0 0 0-8ZM24 22v24M30 30h18m-18 6h12',
  pata: 'M32 50c-7 0-11-3-11-8 0-4 4-8 11-8s11 4 11 8c0 5-4 8-11 8M20 30a4 4 0 1 0 0-8 4 4 0 0 0 0 8m24 0a4 4 0 1 0 0-8 4 4 0 0 0 0 8M11 37a4 4 0 1 0 0-8 4 4 0 0 0 0 8m42 0a4 4 0 1 0 0-8 4 4 0 0 0 0 8',
  chave: 'M38 12a10 10 0 0 0-9 14L12 43l9 9 17-17a10 10 0 0 0 14-9l-7 2-5-5 2-7Z',
  engrenagem: 'M32 44a12 12 0 1 0 0-24 12 12 0 0 0 0 24m0-36v8m0 32v8M8 32h8m32 0h8M15 15l6 6m22 22 6 6M15 49l6-6m22-22 6-6',
  banho: 'M14 32h36v6a16 16 0 0 1-16 16h-4A16 16 0 0 1 14 38ZM14 32V14a6 6 0 0 1 12 0M20 26h8M34 22h.1M42 26h.1M38 18h.1',
  frasco: 'M24 12h16v8l6 10v22a4 4 0 0 1-4 4H22a4 4 0 0 1-4-4V30l6-10ZM24 36h16',
};
function tipoArte(texto) {
  const t = String(texto || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  if (/pacote|clube|assinatura|plano/.test(t)) return 'ticket';
  if (/banho|tosa|hidrata|pet/.test(t)) return 'banho';
  if (/racao|petisco|brinquedo|coleira|areia/.test(t)) return 'pata';
  if (/cabelo|corte|barba|unha|manicure|pedicure|escova|sobrancelha|estetica|depila|cilios|penteado|colora|luzes|progressiva/.test(t)) return 'tesoura';
  if (/mao de obra|servico|revisao|troca de oleo|alinhamento|balanceamento|diagnostico|instalacao|montagem/.test(t)) return 'chave';
  if (/peca|pecas|filtro|pastilha|vela|correia|amortecedor|oleo|bateria|pneu/.test(t)) return 'engrenagem';
  if (/shampoo|condicionador|pomada|creme|esmalte|produto/.test(t)) return 'frasco';
  if (/bebida|refri|suco|agua|cerveja|chop|drink|caipi|vinho|dose|cafe|cha\b|energetic|lata|long ?neck|soda|refresco|milk ?shake/.test(t)) return 'copo';
  if (/pizza|esfirra|calzone/.test(t)) return 'pizza';
  if (/lanche|burg|\bx-|sanduich|hot ?dog|cachorro|misto|wrap|beirute/.test(t)) return 'lanche';
  if (/sobremesa|doce|sorvete|acai|pudim|bolo|torta|mousse|brigadeiro|pave/.test(t)) return 'doce';
  return null;
}
function arteSvg(nome, categoria) {
  const k = tipoArte(categoria) || tipoArte(nome) || 'prato';
  return `<svg viewBox="0 0 64 64" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linejoin="round" stroke-linecap="round" aria-hidden="true"><path d="${ARTE[k]}"/></svg>`;
}
function fotoHtml(foto, nome = '', cls = 'thumb', categoria = '') {
  if (foto) return html`<img class="${cls}" src="${foto}" alt="${nome}" loading="lazy">`;
  return html`<span class="${cls} sem-foto arte" role="img" aria-label="${nome}">${raw(arteSvg(nome, categoria))}</span>`;
}
// Reduz a imagem no próprio celular/PC antes de enviar (máx. 900px, JPEG). Retorna dataURL.
function redimensionarImagem(arquivo, max = 900) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(arquivo);
    img.onload = () => {
      const esc = Math.min(1, max / Math.max(img.width, img.height));
      const c = document.createElement('canvas');
      c.width = Math.round(img.width * esc); c.height = Math.round(img.height * esc);
      const ctx = c.getContext('2d'); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c.width, c.height); ctx.drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      resolve(c.toDataURL('image/jpeg', 0.85));
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('Não foi possível ler a imagem')); };
    img.src = url;
  });
}

// QR code (biblioteca qrcode-generator, MIT)
function qrImg(texto, tamanho = 4) {
  if (typeof qrcode !== 'function') return '';
  const q = qrcode(0, 'M'); q.addData(texto); q.make();
  return q.createImgTag(tamanho, 0);
}

// Endereço do sistema para os outros aparelhos: na versão online é o endereço da loja; no computador,
// o endereço pela internet (quando ligado) ou o do Wi-Fi do restaurante. via = 'wifi' força o do Wi-Fi.
const pelaInternet = (info) => !!(info && !info.base_url && info.internet && info.internet.ativo && info.internet.url);
function baseWifi(info) { const ip = info && info.enderecos && info.enderecos[0]; return ip && !info.nuvem ? `http://${ip}:${info.porta}` : null; }
function baseSistema(info, via) {
  if (info && info.base_url) return info.base_url;
  if (via !== 'wifi' && pelaInternet(info)) return info.internet.url;
  const ip = info && info.enderecos && info.enderecos[0];
  return ip ? `http://${ip}:${info.porta}` : null;
}
// QR das mesas: pela internet (o cliente usa o 4G) ou só pelo Wi-Fi, conforme Configurações
function baseMesas(info) { return baseSistema(info, info && info.internet && info.internet.qr_mesas === 'wifi' ? 'wifi' : undefined); }
// Link para um aparelho da EQUIPE (pela internet leva o convite que libera o aparelho; o cardápio do cliente não precisa).
function linkEquipe(info, caminho, via) {
  const b = baseSistema(info, via); if (!b) return null;
  const conv = info && (info.base_url ? info.convite : via !== 'wifi' && pelaInternet(info) ? info.internet.convite : null);
  return b + caminho + (conv ? (caminho.includes('?') ? '&' : '?') + 'k=' + encodeURIComponent(conv) : '');
}

// ---------- Pela internet: se a internet cair, oferece o caminho pelo Wi-Fi do restaurante ----------
const PeloWifi = {
  get() { try { return JSON.parse(localStorage.getItem('mp_wifi') || 'null'); } catch { return null; } },
  guardar(info) {
    try {
      if (!info || !info.via_internet || !info.enderecos || !info.enderecos.length) return;
      localStorage.setItem('mp_wifi', JSON.stringify({ base: `http://${info.enderecos[0]}:${info.porta}`, em: Date.now() }));
    } catch {}
  },
  aviso(mostrar) {
    let b = document.getElementById('aviso-wifi');
    const w = this.get();
    if (!mostrar || !w || location.protocol !== 'https:') { if (b) b.remove(); return; }
    if (b) return;
    b = document.createElement('div'); b.id = 'aviso-wifi';
    b.style.cssText = 'position:fixed;z-index:9999;left:12px;right:12px;bottom:calc(12px + env(safe-area-inset-bottom));max-width:520px;margin:0 auto;background:#1f2937;color:#fff;border-radius:16px;padding:12px 14px;display:flex;gap:10px;align-items:center;box-shadow:0 12px 30px rgba(0,0,0,.3);font:600 14px/1.35 system-ui,sans-serif';
    b.innerHTML = '<span style="flex:1">📶 Sem conexão pela internet. No Wi-Fi do restaurante, continue por lá.</span>';
    const a = document.createElement('a'); a.href = w.base + location.pathname + location.search; a.textContent = 'Usar pelo Wi-Fi';
    a.style.cssText = 'background:#fff;color:#111;border-radius:11px;padding:9px 12px;text-decoration:none;white-space:nowrap;font-weight:800';
    b.appendChild(a); document.body.appendChild(b);
  },
};
(function () {
  if (typeof window === 'undefined' || location.protocol !== 'https:') return;
  // página de reserva para quando a internet cair (só nos endereços pela internet)
  try { if ('serviceWorker' in navigator && !/^\/cardapio-online/.test(location.pathname)) navigator.serviceWorker.register('/sw.js').catch(() => {}); } catch {}
  if (/^\/(cardapio|fila|reservar)/.test(location.pathname)) return;   // páginas do cliente: não precisam do endereço do Wi-Fi
  setTimeout(() => { GET('/api/info').then(i => PeloWifi.guardar(i)).catch(() => {}); }, 1500);
})();
