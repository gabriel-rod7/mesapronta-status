'use strict';
// Tela "Cardápio online" (gerente): link para divulgar, QR, visual, horários, entrega/retirada, pagamento.
const ON = { info: null };
const DIAS_ON = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];
const CORES_ON = ['#e3262f', '#f25c05', '#f2a900', '#2e9d4f', '#0f8b8d', '#2563eb', '#7c3aed', '#c2185b', '#3f3f46'];

// teste grátis / assinatura mensal do cardápio online
function blocoAssinatura(a) {
  if (!a || !a.controlado || !a.conectado || a.carregando) return '';
  const forma = a.forma === 'pix' ? 'Pix' : a.forma === 'cartao' ? 'cartão' : '';
  const semAsaas = a.asaas === false;
  const bts = (principal) => semAsaas
    ? html`<a class="btn ok" target="_blank" rel="noopener" href="${linkWhatsApp(S.licenca && S.licenca.vendedor_whatsapp || '', 'Olá! Quero assinar o cardápio online do ' + PR.nome + '.')}">Assinar pelo WhatsApp</a>`
    : html`<button class="btn ${principal ? 'primary' : ''}" data-ass="cartao">💳 Assinar no cartão</button><button class="btn" data-ass="pix">⚡ Pagar com Pix</button>`;
  if (a.pago) {
    const atrasada = a.status === 'atrasada';
    return html`<div class="card pad row wrap on-ass" style="gap:10px;align-items:center;box-shadow:none;margin-bottom:12px;background:var(--ok-soft)">
      <div style="flex:1;min-width:220px">✅ <b>Assinatura do cardápio online ativa</b> <span class="muted small">· pago até ${dataBR(a.pago_ate)}${forma ? ' · ' + forma : ''}${a.forma === 'cartao' && !atrasada ? ' (renova sozinho)' : ''}</span>
        ${a.forma === 'pix' ? html`<div class="small muted">Todo mês aparece aqui o botão para pagar a mensalidade no Pix.</div>` : ''}</div>
      ${a.forma === 'pix' || atrasada ? html`<button class="btn" data-ass="mensalidade">Pagar mensalidade</button>` : ''}${a.assinatura ? html`<button class="btn sm ghost" data-ass="cancelar">Cancelar assinatura</button>` : ''}</div>`;
  }
  if (a.em_teste) {
    return html`<div class="card pad on-ass" style="box-shadow:none;margin-bottom:12px;background:var(--accent-soft);border:0">
      <div>🎁 <b>Cardápio online grátis no teste</b>${a.teste_ate ? html` <span class="muted">até ${dataBR(a.teste_ate)}</span>` : ''}. Depois, <b>${a.preco}</b> para continuar recebendo pedidos pelo link — sem comissão por pedido.</div>
      <div class="row wrap" style="gap:8px;margin-top:10px">${bts(false)}<span class="small muted" style="align-self:center">No cartão renova sozinho todo mês. Assinando agora, a 1ª cobrança é hoje.</span></div></div>`;
  }
  if (a.carencia) {
    return html`<div class="card pad alerta-card on-ass" style="box-shadow:none;margin-bottom:12px">⚠ <b>Mensalidade do cardápio online vencida${a.pago_ate ? ' em ' + dataBR(a.pago_ate) : ''}.</b> O link sai do ar em poucos dias se não for paga.
      <div class="row wrap" style="gap:8px;margin-top:10px">${a.assinatura ? html`<button class="btn primary" data-ass="mensalidade">Pagar mensalidade</button>` : bts(true)}</div></div>`;
  }
  return html`<div class="card pad on-ass" style="box-shadow:none;margin-bottom:12px;border:2px solid var(--danger)">
    <div>⛔ <b>Cardápio online pausado.</b> ${a.pago_ate ? html`A assinatura venceu em ${dataBR(a.pago_ate)}.` : 'O período de teste terminou.'} Seus clientes veem "cardápio indisponível". Assine por <b>${a.preco}</b> e ele volta na hora, com tudo como estava.</div>
    <div class="row wrap" style="gap:8px;margin-top:10px">${a.assinatura && a.status !== 'cancelada' ? html`<button class="btn primary" data-ass="mensalidade">Pagar mensalidade</button>` : bts(true)}</div></div>`;
}
async function acaoAssinatura(tipo) {
  if (tipo === 'cancelar') {
    if (!await confirmar('Cancelar a assinatura?', 'O cardápio online continua no ar até o fim do período pago. Depois, o link mostra "indisponível". Você pode assinar de novo quando quiser.', 'Cancelar assinatura', 'danger')) return;
  }
  if (S.nuvem) {
    if (tipo === 'cancelar') {
      const r = await fetch('/__assinatura/cancelar', { method: 'POST' }); const j = await r.json().catch(() => ({}));
      if (!r.ok) return toast(j.erro || 'Não foi possível cancelar agora', 'erro');
      toast('Assinatura cancelada', 'ok'); return render();
    }
    window.open(tipo === 'mensalidade' ? '/__mensalidade' : '/__assinar?forma=' + tipo, '_blank');
    ON.esperando = Date.now(); return;
  }
  const w = tipo === 'cancelar' ? null : window.open('', '_blank');
  const caminho = tipo === 'mensalidade' ? 'mensalidade' : tipo === 'cancelar' ? 'cancelar-assinatura' : 'assinar';   // programa ligado à internet: a nuvem gera o link
  try {
    let j;
    try { j = await POST('/api/nuvem/' + caminho, { forma: tipo }); }
    catch (e) {
      if (!(e.dados && e.dados.precisa_documento)) throw e;
      const doc = await pedirTexto('Assinatura no Pix', 'CPF ou CNPJ de quem vai pagar');
      if (!doc) { if (w) w.close(); return; }
      j = await POST('/api/nuvem/' + caminho, { forma: tipo, documento: doc });
    }
    if (j.url) { if (w) w.location.href = j.url; else window.open(j.url, '_blank'); ON.esperando = Date.now(); }
    else { if (w) w.close(); toast(tipo === 'cancelar' ? 'Assinatura cancelada' : 'Pronto ✓', 'ok'); render(); }
  } catch (e) { if (w) w.close(); toast(e.message, 'erro'); }
}

async function vCardapioOnline(c) {
  const [r, info, ass] = await Promise.all([GET('/api/online/resumo'), ON.info ? Promise.resolve(ON.info) : GET('/api/info'), GET('/api/cardapio/assinatura' + (ON.esperando && Date.now() - ON.esperando < 10 * 60e3 ? '?atualizar=1' : '')).catch(() => null)]);
  ON.info = info;
  S.cfg = await GET('/api/config');
  const cfg = S.cfg;
  const lg = r.ligacao;   // programa do computador ligado à nuvem
  const base = !S.nuvem && lg && lg.ligado ? lg.url : baseSistema(info);   // sem ligar à internet: endereço do Wi-Fi do restaurante
  const link = base ? base + '/cardapio-online' : '';
  let hs; try { hs = JSON.parse(cfg.online_horarios); } catch { hs = null; }
  if (!Array.isArray(hs) || hs.length !== 7) hs = Array.from({ length: 7 }, () => ({ aberto: true, de: '11:00', ate: '23:00' }));
  const pags = String(cfg.online_pagamentos || '').split(',');
  const ligado = cfg.online_ativo === '1';
  const msgZap = `Agora você pode pedir pelo nosso cardápio online! 🍔🛵\nEscolha, peça e acompanhe tudo pelo celular:\n${link}`;
  c.innerHTML = html`<div class="cab"><h1>Cardápio online</h1><span class="muted">Seu link de pedidos para delivery e retirada</span><span class="spacer"></span>
      ${link && ligado ? html`<a class="btn" href="${link}" target="_blank" rel="noopener">Ver como o cliente vê ↗</a>` : ''}</div>
    ${!S.nuvem && lg ? html`<div class="on-conexao ${lg.conectado ? 'ok' : 'off'}">${lg.conectado ? html`🟢 <b>Ligado à internet</b> <span class="muted">· ${lg.url.replace(/^https?:\/\//, '')} · tudo sincronizado</span>` : lg.ligado ? html`🟡 <b>Sem internet agora</b> <span class="muted">· o sistema continua funcionando normalmente aqui; o cardápio online aparece fechado até a internet voltar.</span>` : html`🟡 <b>Ligando à internet…</b> <span class="muted">· ${lg.erro || 'assim que houver conexão, o cardápio ganha o endereço na internet.'}</span>`}</div>` : ''}
    ${blocoAssinatura(ass)}
    <div class="on-liga card pad ${ligado ? 'on' : ''}">
      <div style="flex:1;min-width:220px"><h2 style="margin:0">${ligado ? '🟢 Recebendo pedidos online' : '⚪ Cardápio online desligado'}</h2>
        <div class="muted small">${ligado ? html`${r.situacao.texto}${cfg.online_pausado === '1' ? ' (pausado por você)' : ''} · hoje: <b>${r.hoje.n}</b> pedido(s), ${brl(r.hoje.t)} · no mês: <b>${r.mes.n}</b>, ${brl(r.mes.t)}` : 'Ligue para os clientes pedirem pelo link, sem ligar nem mandar mensagem.'}</div></div>
      ${ligado ? html`<button class="btn ${cfg.online_pausado === '1' ? 'ok' : ''}" id="on-pausa">${cfg.online_pausado === '1' ? '▶ Voltar a receber' : '⏸ Pausar agora'}</button>` : ''}
      <button class="btn ${ligado ? '' : 'primary lg'}" id="on-liga">${ligado ? 'Desligar' : 'Ligar cardápio online'}</button>
    </div>
    ${!r.produtos ? html`<div class="card pad alerta-card" style="box-shadow:none;margin-top:12px">⚠ Nenhum produto aparece no cardápio ainda. <button class="btn sm" data-ir-cad="produtos">Cadastrar produtos</button></div>` : ''}
    ${ligado && link ? html`<div class="on-grid">
      <div class="card pad on-link"><h3 style="margin-top:0">📣 Divulgue seu link</h3>
        <div class="on-url"><input type="text" readonly value="${link}" id="on-url"><button class="btn primary" id="on-copiar">Copiar</button></div>
        <div class="row wrap" style="gap:8px;margin-top:10px">
          <a class="btn ok" target="_blank" rel="noopener" href="https://wa.me/?text=${encodeURIComponent(msgZap)}">💬 Mandar no WhatsApp</a>
          <button class="btn" id="on-qr-imp">🖨 Imprimir QR Code</button>
          <button class="btn" id="on-copiar-msg">Copiar mensagem pronta</button></div>
        <div class="small muted" style="margin-top:10px">Dica: coloque o link na <b>bio do Instagram</b>, no <b>status do WhatsApp</b> e na resposta automática do WhatsApp Business. Cole o QR Code na embalagem e no balcão.</div></div>
      <div class="card pad on-qr">${raw(qrImg(link, 5))}<div class="small muted">Aponte a câmera do celular</div></div>
    </div>` : ''}
    ${window.PRODUTO?.recursos?.delivery !== false ? html`<div class="card pad on-ifood" id="on-ifood"><h3 style="margin-top:0">🛵 iFood</h3><div class="muted small">Carregando…</div></div>` : ''}
    <div class="on-config">
      <div class="card pad"><h3 style="margin-top:0">🎨 Aparência</h3>
        <div class="on-visual">
          <div><div class="rotulo">LOGO</div><div class="on-img on-logo" style="${cfg.online_logo ? raw(`background-image:url('${encodeURI(cfg.online_logo)}')`) : ''}">${cfg.online_logo ? '' : 'Logo'}</div>
            <div class="row" style="gap:6px;margin-top:6px"><button class="btn sm" data-img="logo">Escolher</button>${cfg.online_logo ? html`<button class="btn sm ghost" data-img-tirar="logo">Tirar</button>` : ''}</div></div>
          <div style="flex:1;min-width:200px"><div class="rotulo">FOTO DE CAPA</div><div class="on-img on-capa" style="${cfg.online_capa ? raw(`background-image:url('${encodeURI(cfg.online_capa)}')`) : ''}">${cfg.online_capa ? '' : 'Foto do restaurante ou dos pratos'}</div>
            <div class="row" style="gap:6px;margin-top:6px"><button class="btn sm" data-img="capa">Escolher</button>${cfg.online_capa ? html`<button class="btn sm ghost" data-img-tirar="capa">Tirar</button>` : ''}</div></div>
        </div>
        <div class="rotulo" style="margin-top:14px">COR</div><div class="on-cores">${CORES_ON.map(x => html`<button class="on-cor ${cfg.online_cor === x ? 'on' : ''}" data-cor="${x}" style="background:${x}" aria-label="Cor ${x}"></button>`)}</div>
        <div class="rotulo" style="margin-top:14px">FUNDO</div><div class="chips"><button class="chip ${cfg.online_tema !== 'claro' ? 'on' : ''}" data-tema-on="escuro">🌙 Escuro</button><button class="chip ${cfg.online_tema === 'claro' ? 'on' : ''}" data-tema-on="claro">☀️ Claro</button></div>
        <label class="campo" style="margin-top:14px">Aviso no topo do cardápio <span class="muted small">(opcional)</span><input type="text" id="on-aviso" value="${cfg.online_aviso}" placeholder="Ex.: Terça tem burger em dobro!"></label>
        <div class="small muted" style="margin-top:8px">As fotos dos produtos vêm de Cadastros › Produtos. Produto com foto vende mais.</div>
      </div>
      <div class="card pad"><h3 style="margin-top:0">🛵 Entrega e retirada</h3>
        <label class="check"><input type="checkbox" id="on-entrega" ${cfg.online_entrega === '1' ? 'checked' : ''}> Fazemos entrega</label>
        <label class="check"><input type="checkbox" id="on-retirada" ${cfg.online_retirada === '1' ? 'checked' : ''}> Cliente pode retirar no local</label>
        <div class="grid2" style="margin-top:10px"><label class="campo">Tempo de entrega (min)<input id="on-tent" type="number" inputmode="numeric" value="${cfg.tempo_entrega_min || 45}"></label><label class="campo">Tempo p/ retirada (min)<input id="on-tret" type="number" inputmode="numeric" value="${cfg.online_tempo_retirada || 20}"></label></div>
        <label class="check"><input type="checkbox" id="on-local" ${cfg.online_local === '1' ? 'checked' : ''}> Cliente pode pedir para comer no local <span class="muted small">(pede pelo link e come no restaurante)</span></label>
        <label class="check"><input type="checkbox" id="on-agendar" ${cfg.online_agendar === '1' ? 'checked' : ''}> Aceitar pedidos agendados <span class="muted small">(o cliente escolhe dia e hora; dá para agendar até com a loja fechada)</span></label>
        <div class="grid2" id="on-agendar-op" ${cfg.online_agendar === '1' ? '' : raw('hidden')}><label class="campo">Até quando dá para agendar<select id="on-ag-dias">${[[0, 'Só para hoje'], [1, 'Hoje e amanhã'], [2, 'Até 2 dias'], [3, 'Até 3 dias'], [7, 'Até 7 dias']].map(([v, t]) => html`<option value="${v}" ${String(cfg.online_agendar_dias || '2') === String(v) ? raw('selected') : ''}>${t}</option>`)}</select></label>
          <label class="campo">Horários de quanto em quanto<select id="on-ag-int">${[15, 30, 60].map(v => html`<option value="${v}" ${String(cfg.online_agendar_intervalo || '30') === String(v) ? raw('selected') : ''}>${v} min</option>`)}</select></label></div>
        <div class="small muted" id="on-agendar-dica" ${cfg.online_agendar === '1' ? '' : raw('hidden')}>Pedido agendado nunca entra direto na cozinha: aparece para aceitar, com o dia e a hora em destaque. Aceite perto da hora de preparar.</div>
        <label class="campo">Pedido mínimo (R$) <span class="muted small">0 = sem mínimo</span><input type="text" id="on-min" inputmode="decimal" value="${brlCurto(cfg.online_minimo)}"></label>
        <div class="campo"><span>Taxa de entrega</span>${window.ENT ? ENT.cfgEscolha(cfg) : ''}<div id="fr-bairro" ${window.ENT && ENT.modo(cfg) === 'distancia' ? raw('hidden') : ''}>${r.bairros ? html`<div class="small">Por bairro: <b>${r.bairros}</b> bairro(s) cadastrado(s). O cliente escolhe o bairro e a taxa entra sozinha. <button class="btn sm" data-ir-cad="bairros">Editar bairros e taxas</button></div>`
          : html`<div class="grid2"><label class="campo">Taxa única (R$)<input type="text" id="on-taxa" inputmode="decimal" value="${brlCurto(cfg.online_taxa_fixa)}"></label><div class="small muted" style="align-self:end">Prefere taxa por bairro? <button class="btn sm" data-ir-cad="bairros">Cadastrar bairros</button></div></div>`}</div>${window.ENT ? ENT.cfgBloco(cfg, r.bairros) : ''}</div>
      </div>
      <div class="card pad"><h3 style="margin-top:0">🕒 Horário de funcionamento</h3>
        <div class="on-horas">${hs.map((h, i) => html`<div class="on-hora"><label class="check"><input type="checkbox" data-hd="${i}" ${h.aberto ? 'checked' : ''}> ${DIAS_ON[i]}</label><input type="time" data-hde="${i}" value="${h.de}"><span class="muted">às</span><input type="time" data-hate="${i}" value="${h.ate}"></div>`)}</div>
        <div class="small muted" style="margin-top:8px">Fora do horário o cliente vê o cardápio, mas não consegue pedir. Passa da meia-noite? Ex.: 18:00 às 02:00 funciona.</div>
        <button class="btn sm" id="on-copiar-hora" style="margin-top:8px">Copiar o horário de segunda para todos os dias</button>
      </div>
      <div class="card pad"><h3 style="margin-top:0">🛍️ "Peça também" na sacola</h3>
        <div class="small muted" style="margin-bottom:8px">Antes de fechar o pedido, o cliente vê sugestões de bebida, sobremesa ou acompanhamento. Aumenta o valor dos pedidos.</div>
        <div class="chips" id="on-sug-modo">${[['auto', 'Automático (os mais vendidos)'], ['escolher', 'Eu escolho'], ['off', 'Desligado']].map(([v, t]) => html`<button class="chip ${(cfg.online_sugestoes === 'off' ? 'off' : cfg.online_sugestoes && cfg.online_sugestoes !== 'auto' ? 'escolher' : 'auto') === v ? 'on' : ''}" data-sug-modo="${v}">${t}</button>`)}</div>
        <div id="on-sug-lista" style="margin-top:10px;max-height:260px;overflow:auto" ${cfg.online_sugestoes && !['auto', 'off'].includes(cfg.online_sugestoes) ? '' : raw('hidden')}>${(S.cardapio?.produtos || []).filter(p => !p.por_quilo).map(p => html`<label class="check"><input type="checkbox" data-sug="${p.id}" ${String(cfg.online_sugestoes || '').split(',').includes(String(p.id)) ? 'checked' : ''}> ${p.nome} <span class="muted small">${brl(p.preco_atual ?? p.preco)}</span></label>`)}</div>
      </div>
      <div class="card pad"><h3 style="margin-top:0">💳 Pagamento e pedidos</h3>
        <label class="check"><input type="checkbox" data-pag="pix" ${pags.includes('pix') ? 'checked' : ''}> Pix (aparece o QR Code para o cliente pagar) ${r.pix ? '' : html`<button class="btn sm" id="on-ir-pix">Cadastrar chave Pix</button>`}</label>
        <label class="check"><input type="checkbox" data-pag="cartao" ${pags.includes('cartao') ? 'checked' : ''}> Cartão na entrega (maquininha)</label>
        <label class="check"><input type="checkbox" data-pag="dinheiro" ${pags.includes('dinheiro') ? 'checked' : ''}> Dinheiro (cliente informa o troco)</label>
        <hr style="border:0;border-top:1px solid var(--line);margin:12px 0">
        <label class="check"><input type="checkbox" id="on-auto" ${cfg.online_aceitar_auto === '1' ? 'checked' : ''}> Aceitar pedidos automaticamente <span class="muted small">(vão direto para a cozinha)</span></label>
        <div class="small muted">Desligado: o caixa recebe um aviso com som e toca em <b>Aceitar</b> (recomendado no começo).</div>
      </div>
    </div>
    <div class="on-salvar"><button class="btn primary lg" id="on-salvar">Salvar configurações</button></div>`;

  const lerSug = () => { const m = $('#on-sug-modo .chip.on')?.dataset.sugModo || 'auto'; if (m !== 'escolher') return m === 'off' ? 'off' : ''; return $$('[data-sug]:checked').map(x => x.dataset.sug).join(',') || 'off'; };
  const salvar = async (extra = {}, msg = 'Salvo ✓') => {
    const horarios = hs.map((h, i) => ({ aberto: $(`[data-hd="${i}"]`).checked, de: $(`[data-hde="${i}"]`).value || '11:00', ate: $(`[data-hate="${i}"]`).value || '23:00' }));
    const corpo = {
      online_entrega: $('#on-entrega').checked ? '1' : '0', online_retirada: $('#on-retirada').checked ? '1' : '0',
      tempo_entrega_min: String(Math.max(5, Number($('#on-tent').value) || 45)), online_tempo_retirada: String(Math.max(5, Number($('#on-tret').value) || 20)),
      online_minimo: String(paraCentavos($('#on-min').value)), online_horarios: JSON.stringify(horarios),
      online_pagamentos: $$('[data-pag]').filter(x => x.checked).map(x => x.dataset.pag).join(','), online_aceitar_auto: $('#on-auto').checked ? '1' : '0',
      online_aviso: $('#on-aviso').value.trim(), online_local: $('#on-local').checked ? '1' : '0', online_agendar: $('#on-agendar').checked ? '1' : '0',
      online_agendar_dias: $('#on-ag-dias').value, online_agendar_intervalo: $('#on-ag-int').value, online_sugestoes: lerSug(), ...($('#on-taxa') ? { online_taxa_fixa: String(paraCentavos($('#on-taxa').value)) } : {}), ...extra,
    };
    if (corpo.online_entrega === '0' && corpo.online_retirada === '0' && corpo.online_local === '0') { toast('Marque entrega, retirada ou comer no local', 'erro'); return false; }
    if (!corpo.online_pagamentos) { toast('Marque pelo menos uma forma de pagamento', 'erro'); return false; }
    if (window.ENT) { const fr = ENT.cfgLer(c); if (!fr) return false; Object.assign(corpo, fr); }   // frete por bairro ou por distância (entrega.js)
    await PUT('/api/config', corpo); toast(msg, 'ok'); render(); return true;
  };
  const on = (sel, fn) => { const el = $(sel); if (el) el.onclick = fn; };
  if (window.ENT) ENT.cfgLigar(c);
  on('#on-salvar', () => tentar(() => salvar()));
  on('#on-liga', () => tentar(() => salvar({ online_ativo: ligado ? '0' : '1', online_pausado: '0' }, ligado ? 'Cardápio online desligado' : '🎉 Cardápio online ligado! Agora é só divulgar o link.')));
  on('#on-pausa', () => tentar(() => salvar({ online_pausado: cfg.online_pausado === '1' ? '0' : '1' }, cfg.online_pausado === '1' ? 'Voltou a receber pedidos' : 'Pedidos pausados')));
  on('#on-copiar', async () => { try { await navigator.clipboard.writeText(link); toast('Link copiado ✓', 'ok'); } catch { $('#on-url').select(); document.execCommand('copy'); toast('Link copiado', 'ok'); } if (window.marcarDivulgado) marcarDivulgado(); });
  const zapLink = c.querySelector('.on-link a[href^="https://wa.me/"]'); if (zapLink) zapLink.addEventListener('click', () => { if (window.marcarDivulgado) marcarDivulgado(); });   // 3.12: conta como "divulguei" no roteiro do Início
  on('#on-copiar-msg', async () => { try { await navigator.clipboard.writeText(msgZap); toast('Mensagem copiada ✓', 'ok'); } catch { toast('Não deu para copiar', 'erro'); } });
  on('#on-ir-pix', () => { S.abaConfig = 'pix'; ir('config'); });
  on('#on-copiar-hora', () => { const h = { aberto: $('[data-hd="1"]').checked, de: $('[data-hde="1"]').value, ate: $('[data-hate="1"]').value }; for (let i = 0; i < 7; i++) { $(`[data-hd="${i}"]`).checked = h.aberto; $(`[data-hde="${i}"]`).value = h.de; $(`[data-hate="${i}"]`).value = h.ate; } toast('Copiado. Lembre de salvar.'); });
  on('#on-qr-imp', () => {
    const w = window.open('', '_blank'); if (!w) return toast('Permita pop-ups para imprimir', 'erro');
    w.document.write(`<!doctype html><meta charset="utf-8"><title>QR Code do cardápio</title><style>body{font-family:system-ui,sans-serif;text-align:center;padding:40px}img{width:320px;height:320px;image-rendering:pixelated}h1{font-size:34px;margin:0 0 6px}p{font-size:20px;margin:6px 0}small{color:#555;font-size:14px}</style>
      <h1>${esc(cfg.nome_estabelecimento)}</h1><p>📱 Peça pelo celular — delivery e retirada</p>${qrImg(link, 8)}<p><b>Aponte a câmera aqui</b></p><small>${esc(link)}</small><script>setTimeout(()=>print(),300)<\/script>`);
    w.document.close();
  });
  // depois de abrir o pagamento, confere sozinho por alguns minutos se a assinatura foi aprovada
  if (ON.esperando && Date.now() - ON.esperando < 10 * 60e3 && ass && !ass.pago) setTimeout(() => { if (S.view === 'cardapio-online') render(); }, 15000);
  if ($('#on-ifood')) cardIfood($('#on-ifood'));
  const ag = $('#on-agendar'); if (ag) ag.onchange = () => { $('#on-agendar-op').hidden = !ag.checked; $('#on-agendar-dica').hidden = !ag.checked; };
  c.onclick = async (e) => {
    const sm = e.target.closest('[data-sug-modo]'); if (sm) { $$('#on-sug-modo .chip').forEach(x => x.classList.toggle('on', x === sm)); $('#on-sug-lista').hidden = sm.dataset.sugModo !== 'escolher'; return; }
    const as = e.target.closest('[data-ass]'); if (as) return acaoAssinatura(as.dataset.ass);
    const cad = e.target.closest('[data-ir-cad]'); if (cad) { S.abaCad = cad.dataset.irCad; return ir('cadastros'); }
    const cor = e.target.closest('[data-cor]'); if (cor) return tentar(() => salvar({ online_cor: cor.dataset.cor }, 'Cor salva ✓'));
    const tm = e.target.closest('[data-tema-on]'); if (tm) return tentar(() => salvar({ online_tema: tm.dataset.temaOn }, 'Fundo salvo ✓'));
    const tir = e.target.closest('[data-img-tirar]'); if (tir) { await tentar(() => POST('/api/online/imagem', { tipo: tir.dataset.imgTirar, dados: null })); return render(); }
    const im = e.target.closest('[data-img]');
    if (im) {
      const inp = document.createElement('input'); inp.type = 'file'; inp.accept = 'image/*';
      inp.onchange = async () => { const f = inp.files[0]; if (!f) return; const dados = await redimensionarImagem(f, im.dataset.img === 'capa' ? 1600 : 500); await tentar(() => POST('/api/online/imagem', { tipo: im.dataset.img, dados }), 'Imagem salva ✓'); render(); };
      inp.click();
    }
  };
}
// ---------- 3.10: iFood (src/ifood.js) ----------
async function cardIfood(el, est) {
  try { est = est || await GET('/api/ifood/estado'); } catch (e) { el.innerHTML = html`<h3 style="margin-top:0">🛵 iFood</h3><div class="muted small">${e.message}</div>`; return; }
  const cab = html`<h3 style="margin-top:0">🛵 iFood <span class="badge ${est.ligado ? 'ok' : ''}">${est.ligado ? 'ligado' : 'desligado'}</span></h3>`;
  if (est.espelho) { el.innerHTML = html`${cab}<div class="small muted">Ligue o iFood no computador do restaurante (Cardápio online › iFood). Os pedidos chegam lá.</div>`; return; }
  if (est.ligado) {
    const st = Array.isArray(est.status) ? est.status : [];
    const aberto = st.some(x => x.disponivel);
    el.innerHTML = html`${cab}
      <div class="small">${est.merchants.length ? html`Loja no iFood: <b>${est.merchants.map(m => m.nome).join(', ')}</b>` : 'Loja no iFood: conferindo…'}</div>
      ${st.length ? html`<div class="small" style="margin-top:4px">${aberto ? '🟢' : '🔴'} <b>${st[0].titulo || (aberto ? 'Loja aberta no iFood' : 'Loja fechada no iFood')}</b> <span class="muted">${st[0].detalhe || ''}</span></div>` : ''}
      <div class="small muted" style="margin-top:4px">Hoje: <b>${est.hoje.n}</b> pedido(s), ${brl(est.hoje.t)}${est.ultimo ? ` · última conferência às ${hora(est.ultimo)}` : ''}</div>
      ${est.erro ? html`<div class="small" style="color:var(--danger);margin-top:4px">⚠ ${est.erro}</div>` : ''}
      <label class="check" style="margin-top:10px"><input type="checkbox" id="if-auto" ${est.aceitar_auto ? 'checked' : ''}> Aceitar pedidos do iFood automaticamente <span class="muted small">(confirma no iFood e manda para a cozinha na hora)</span></label>
      <div class="small muted">Desligado: o pedido aparece com aviso e som para tocar em <b>Aceitar</b>. O iFood cancela sozinho o que não for aceito em 8 minutos.</div>
      <div class="small muted" style="margin-top:8px">Os pedidos chegam no <b>Delivery</b>. Quando a cozinha marca pronto (ou o pedido sai), o iFood é avisado sozinho. Ligue os produtos ao cardápio do iFood colocando no iFood o <b>código PDV</b> igual ao código do produto aqui.</div>
      <div class="small muted" style="margin-top:4px">A loja só fica aberta no iFood com este ${S.nuvem ? 'sistema' : 'computador'} ligado e com internet.</div>
      <button class="btn sm ghost" id="if-desligar" style="margin-top:10px">Desligar o iFood</button>`;
    $('#if-auto', el).onchange = (e) => tentar(() => PUT('/api/ifood/config', { aceitar_auto: e.target.checked }), 'Salvo ✓');
    $('#if-desligar', el).onclick = async () => { const ok = await modal({ titulo: 'Desligar o iFood?', corpo: '<p>Os pedidos do iFood param de chegar aqui e a loja fecha no iFood em alguns minutos.</p>', botoes: [{ texto: 'Voltar' }, { texto: 'Desligar', classe: 'danger', acao: () => true }] }); if (ok) { await tentar(() => POST('/api/ifood/desligar'), 'iFood desligado'); cardIfood(el); } };
    return;
  }
  if (est.disponivel === false) { el.innerHTML = html`${cab}<div class="small muted">A ligação com o iFood ainda não foi ativada pelo MesaPronta. Fale com o suporte no WhatsApp para ativar.</div>`; return; }
  const v = est.vinculo;
  el.innerHTML = html`${cab}
    <div class="small muted">Receba os pedidos do iFood aqui no sistema, com impressão na cozinha e aviso de pronto para o iFood.</div>
    ${v ? html`<ol class="small if-passos">
        <li>Abra o <a href="${v.url || 'https://portal.ifood.com.br/apps/code'}" target="_blank" rel="noopener"><b>Portal do Parceiro do iFood</b></a> (entre com o usuário da sua loja).</li>
        <li>Digite este código: <b class="if-cod">${v.codigo}</b> <button class="btn sm" id="if-copiar">Copiar</button> e autorize o MesaPronta.</li>
        <li>O iFood mostra um <b>código de autorização</b>. Cole aqui:</li></ol>
      <div class="row" style="gap:8px"><input type="text" id="if-aut" placeholder="Código de autorização" style="flex:1" autocomplete="off"><button class="btn primary" id="if-vincular">Ligar</button></div>
      <div class="small muted" style="margin-top:6px">O código vale 10 minutos. <button class="btn sm ghost" id="if-gerar">Gerar outro código</button></div>`
      : html`<button class="btn primary" id="if-gerar" style="margin-top:10px">Ligar com o iFood</button>`}`;
  $('#if-gerar', el).onclick = async () => { const r = await tentar(() => POST('/api/ifood/codigo')); if (r) cardIfood(el, { ...est, vinculo: r }); };
  const cp = $('#if-copiar', el); if (cp) cp.onclick = async () => { try { await navigator.clipboard.writeText(v.codigo); toast('Código copiado ✓', 'ok'); } catch { toast(v.codigo); } };
  const vb = $('#if-vincular', el);
  if (vb) vb.onclick = async () => { const cod = $('#if-aut', el).value.trim(); if (!cod) return toast('Cole o código de autorização do iFood', 'erro'); const r = await tentar(() => POST('/api/ifood/vincular', { codigo: cod })); if (r) { toast('🎉 iFood ligado! Os pedidos vão chegar aqui.', 'ok', { tempo: 7000 }); cardIfood(el); } };
}
window.PRODUTO_VIEWS = { ...(window.PRODUTO_VIEWS || {}), 'cardapio-online': vCardapioOnline };
