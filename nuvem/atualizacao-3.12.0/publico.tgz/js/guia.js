'use strict';
// ============================================================================
// Primeiros minutos e celular: faixa do teste, "Comece por aqui", pedido de teste
// guiado, navegação de celular e barra do pedido. Carregado ANTES do caixa.js
// (as funções só rodam depois, quando S, R, T etc. já existem).
// ============================================================================
const TOQUE = matchMedia('(pointer: coarse)').matches;
const CELULAR = () => matchMedia('(max-width: 760px)').matches;
if (TOQUE) document.documentElement.classList.add('toque');

// ---------------------------------------------------------------- licença
const precoOferta = () => (S.licenca && S.licenca.oferta && S.licenca.oferta.preco) || '';
function linkJaComprei() {
  const l = S.licenca || {};
  const txt = l.nuvem
    ? `Olá! Já comprei o ${PR.nome} online (${S.cfg.nome_estabelecimento || ''} — ${location.host}). A licença ainda não ativou.`
    : `Olá! Já comprei o ${PR.nome}. Código do computador: ${l.codigo_maquina || ''}`;
  return l.vendedor_whatsapp ? linkWhatsApp(l.vendedor_whatsapp, txt) : '';
}
// Faixa fina no topo do Início (no lugar do cartão grande com 4 botões)
function faixaTeste() {
  const l = S.licenca; if (!l) return '';
  if (MPPlanos.ativo(l)) return faixaPlano(l);
  if (l.estado === 'teste') {
    const n = Number(l.dias_restantes), urg = n <= 2;
    const dias = n <= 0 ? 'termina hoje' : n === 1 ? 'falta 1 dia' : `faltam ${n} dias`;
    const comprar = linkCompra(l);
    return `<div class="faixa-teste ${urg ? 'urgente' : ''}"><div class="ft-txt"><b>${urg ? '⏳' : '🎁'} Teste grátis: ${dias}</b>${urg ? `<span>Quando comprar, tudo o que você cadastrou continua aqui.</span>` : ''}</div>
      <div class="ft-bts">${comprar ? `<a class="btn sm ${urg ? 'primary' : 'ok'}" href="${esc(comprar)}" target="_blank" rel="noopener">Comprar${precoOferta() ? ' · ' + esc(precoOferta()) : ''}</a>` : ''}<button class="btn sm ghost" data-ja-comprei>Já comprei</button></div></div>`;
  }
  if (l.estado === 'ativada' && l.dias_para_expirar != null && l.dias_para_expirar <= 15) {
    const comprar = linkCompra(l);
    return `<div class="faixa-teste ${l.dias_para_expirar <= 3 ? 'urgente' : ''}"><div class="ft-txt"><b>Sua licença vence ${l.dias_para_expirar <= 0 ? 'hoje' : 'em ' + l.dias_para_expirar + ' dia(s)'}</b><span>${dataBR(l.expira)}</span></div><div class="ft-bts">${comprar ? `<a class="btn sm primary" href="${esc(comprar)}" target="_blank" rel="noopener">Renovar</a>` : `<button class="btn sm" data-ja-comprei>Renovar</button>`}</div></div>`;
  }
  return '';
}
// 3.11: Início com os planos — teste (escolha seu plano), atrasada (aviso desde o 1º dia), vencida, licença antiga acabando
function faixaPlano(l) {
  const p = l.plano, ger = pode('gerente');
  const irPlano = ger ? `<button class="btn sm" data-ir-plano>Seu plano</button>` : '';
  const pagar = MPPlanos.linkPagar(l) && ger ? `<a class="btn sm primary" href="${esc(MPPlanos.linkPagar(l))}" target="_blank" rel="noopener">Pagar mensalidade</a>` : '';
  if (p.situacao === 'teste') {
    const n = Number(l.dias_restantes), urg = n <= 2;
    const dias = n <= 0 ? 'termina hoje' : n === 1 ? 'falta 1 dia' : `faltam ${n} dias`;
    return `<div class="faixa-teste ${urg ? 'urgente' : ''}"><div class="ft-txt"><b>${urg ? '⏳' : '🎁'} Teste grátis: ${dias}</b><span>Tudo do plano Master liberado${l.termina_em ? ' até ' + dataBR(l.termina_em) : ''}. Planos a partir de R$ 39,90/mês sem fidelidade, ou até 40% mais barato no anual.</span></div>
      <div class="ft-bts">${ger ? `<button class="btn sm ${urg ? 'primary' : 'ok'}" data-ver-planos>Escolher meu plano</button>` : ''}</div></div>`;
  }
  if (p.situacao === 'em_dia' && p.lembrete) return `<div class="faixa-teste" id="aviso-plano-lembrete"><div class="ft-txt"><b>🔔 Sua mensalidade do plano ${esc(p.nome)} vence ${p.fatura_vence ? 'em ' + dataBR(p.fatura_vence) : 'em breve'}</b><span>Pague pelo link (Pix, boleto ou cartão). Depois do pagamento, o sistema confirma sozinho.</span></div><div class="ft-bts">${pagar}${irPlano}</div></div>`;
  if (p.situacao === 'atrasada') return `<div class="faixa-teste urgente" id="aviso-plano"><div class="ft-txt"><b>⚠ Mensalidade do plano ${esc(p.nome)} atrasada${p.dias_atraso ? ' há ' + p.dias_atraso + ' dia' + (p.dias_atraso > 1 ? 's' : '') : ''}</b><span>${p.tolerancia_offline ? 'Sem internet para conferir o pagamento. ' : ''}O sistema continua funcionando${p.bloqueia_vendas_em ? '; as vendas novas param em ' + dataBR(p.bloqueia_vendas_em) : ''}. Pague para não parar.</span></div><div class="ft-bts">${pagar}${irPlano}</div></div>`;
  if (p.situacao === 'vencida') return `<div class="faixa-teste urgente" id="aviso-plano"><div class="ft-txt"><b>⛔ Vendas novas bloqueadas: ${p.cancelada ? 'a assinatura foi cancelada' : 'a mensalidade venceu'}${p.pago_ate ? ' em ' + dataBR(p.pago_ate) : ''}</b><span>Fechar as contas abertas, fechar o caixa e ver os relatórios continua liberado. Nada do que você cadastrou se perde.</span></div><div class="ft-bts">${p.cancelada ? (ger ? '<button class="btn sm primary" data-ver-planos>Escolher um plano</button>' : '') : pagar}${irPlano}</div></div>`;
  if (p.situacao === 'cancelada' && p.pago_ate) return `<div class="faixa-teste"><div class="ft-txt"><b>Assinatura cancelada</b><span>O plano ${esc(p.nome)} vale até ${dataBR(p.pago_ate)}. Pode assinar de novo quando quiser.</span></div><div class="ft-bts">${ger ? '<button class="btn sm" data-ver-planos>Ver planos</button>' : ''}</div></div>`;
  if (p.situacao === 'legado' && l.dias_para_expirar != null && l.dias_para_expirar <= 15) return `<div class="faixa-teste ${l.dias_para_expirar <= 3 ? 'urgente' : ''}"><div class="ft-txt"><b>Sua licença termina ${l.dias_para_expirar <= 0 ? 'hoje' : 'em ' + l.dias_para_expirar + ' dia(s)'}</b><span>${dataBR(l.expira)}. Para continuar, escolha um plano mensal (a partir de R$ 39,90).</span></div><div class="ft-bts">${ger ? '<button class="btn sm primary" data-ver-planos>Escolher meu plano</button>' : ''}</div></div>`;
  return '';
}
document.addEventListener('click', (e) => { if (e.target.closest('[data-ir-plano]')) { S.abaConfig = 'licenca'; ir('config'); } });
// Windows com compra pela nuvem: procura a licença paga e ativa na hora
async function jaPagueiVerificar() {
  toast('Procurando o seu pagamento…');
  let st = null; try { st = await POST('/api/licenca/buscar'); } catch (e) { return toast(e.message, 'erro'); }
  if (st && st.estado === 'ativada') { S.licenca = st; toast(`🎉 Licença ativada${st.expira ? ' até ' + dataBR(st.expira) : ''}. Obrigado pela compra!`, 'ok', { tempo: 12000 }); return render(); }
  const msg = st && st.busca && st.busca.ok === false ? 'Sem internet para verificar agora. Confira a conexão e tente de novo.' : 'Ainda não encontramos o pagamento. Pix leva alguns segundos; cartão, até 1 minuto. O sistema continua verificando sozinho.';
  toast(msg, 'erro', { tempo: 9000, acao: linkJaComprei() ? { texto: 'WhatsApp', fn: () => window.open(linkJaComprei(), '_blank') } : undefined });
}
document.addEventListener('click', (e) => {
  if (!e.target.closest('[data-ja-comprei]')) return;
  if (S.licenca && !S.licenca.nuvem && S.licenca.compra_automatica) return jaPagueiVerificar();
  if (S.licenca && !S.licenca.nuvem && pode('gerente')) { S.abaConfig = 'licenca'; ir('config'); return; }
  const w = linkJaComprei(); if (w) window.open(w, '_blank');
});
// Avisa quando a licença muda sozinha (compra aprovada pela Kirvano)
let licAnterior = null;
function observarLicenca() {
  const l = S.licenca; if (!l) return;
  if (licAnterior && licAnterior !== 'ativada' && l.estado === 'ativada') {
    toast(`🎉 Licença ativada${l.expira ? ' até ' + dataBR(l.expira) : ''}. Obrigado pela compra!${l.adicionais && l.adicionais.pendentes && l.adicionais.pendentes.length ? ' Falta ativar: ' + l.adicionais.pendentes.map(p => p.nome).join(' e ') + ' (veja no Início).' : ''}`, 'ok', { tempo: 15000 });
    if (S.view === 'inicio') render();
  }
  licAnterior = l.estado;
}

// ---------------------------------------------------------------- "Comece por aqui"
const TEM_TOUR = () => !!(R.mesas && R.cozinha);
// 3.12: um roteiro só no Início (no lugar de "Comece por aqui" + "Primeiros passos" + banner do assistente):
// cada passo é uma ação de 1 clique; impressora, Pix e PINs ficam em "Depois, quando quiser".
const nomeDefinido = () => { const n = (S.cfg.nome_estabelecimento || '').trim(); return !!n && !/^meu (restaurante|neg[oó]cio|pet ?shop|sal[aã]o|oficina)$/i.test(n); };
function itensComece(d) {
  const pp = (d && d.primeirosPassos) || {};
  const it = [
    { id: 'nome', t: `Dê o nome do seu ${R.mesas ? 'restaurante' : 'negócio'}`, sub: 'Aparece no cupom, no cardápio e no celular da equipe', ok: !!pp.nome || nomeDefinido() },
    { id: 'produtos', t: R.mesas ? 'Seus produtos' : `Cadastro de ${T.produtos_plural || 'produtos'}`, sub: 'Use os exemplos ou cadastre os seus (dá para mandar a foto do cardápio)', ok: S.cfg.produtos_ok === '1' || !!pp.produtos },
    TEM_TOUR() ? { id: 'teste', t: 'Faça um pedido de teste', sub: 'Mesa → cozinha → Pix, em 2 minutos', ok: S.cfg.pedido_teste_ok === '1' }
      : { id: 'venda', t: 'Faça um teste: lance e receba', sub: 'Para ver como fica, do começo ao fim', ok: (d && d.vendas_total > 0) || S.cfg.pedido_teste_ok === '1' },
  ];
  if (R.delivery && planoPode('cardapio_online')) it.push({ id: 'cardapio', t: 'Divulgue seu cardápio online', sub: S.cfg.online_ativo === '1' ? 'Já está no ar: copie o link ou mande no WhatsApp' : 'Pedidos no seu link, sem comissão de aplicativo', ok: S.cfg.online_divulgado === '1' });
  if (R.garcom || S.nuvem) it.push({ id: 'celular', t: R.garcom ? 'Abra no celular do garçom' : 'Abra no celular da equipe', sub: 'Aponte a câmera para o QR e pronto', ok: lsGet('mp_celular_visto') === '1' });
  return it;
}
function mostrarComece(d) {
  if (!pode('gerente') || S.cfg.comece_ok === '1') return false;
  const it = itensComece(d);
  if (it.every(x => x.ok)) return false;
  return (d && d.vendas_total || 0) < 10;
}
function cardComece(d) {
  const it = itensComece(d), feitos = it.filter(x => x.ok).length;
  const prox = it.find(x => !x.ok);
  const depois = [...(S.nuvem ? [] : [['impressora', 'impressora']]), ['pix', 'chave Pix'], ['pins', 'PINs da equipe'], ['assistente', 'assistente completo']];
  return `<section class="comece card" id="comece"><div class="cm-cab"><div><span class="mp-page-label">Comece por aqui</span><h2>${feitos ? 'Falta pouco!' : `Comece a usar o ${PR.nome} em 3 minutos`}</h2></div><span class="cm-n">${feitos}/${it.length}</span></div>
    <div class="progresso"><i style="width:${Math.round(feitos / it.length * 100)}%"></i></div>
    <div class="cm-itens">${it.map((x, i) => `<button class="cm-item ${x.ok ? 'ok' : ''} ${x === prox ? 'prox' : ''}" data-comece="${x.id}"><span class="cm-ck">${x.ok ? '✓' : i + 1}</span><span class="cm-t"><b>${esc(x.t)}</b><small>${esc(x.sub)}</small></span><span class="cm-seta">›</span></button>`).join('')}</div>
    <button class="btn primary lg block" data-comece="${prox.id}">${feitos ? 'Continuar' : 'Começar'}: ${esc(prox.t.toLowerCase())}</button>
    <div class="cm-depois small muted">Depois, quando quiser: ${depois.map(([id, t]) => `<button type="button" class="cm-link" data-comece="${id}">${t}</button>`).join(' · ')}</div>
    <button class="btn ghost sm cm-pular" data-comece="pular">Já sei usar, esconder</button></section>`;
}
async function acaoComece(id) {
  if (id === 'pular') { await PUT('/api/config', { comece_ok: '1' }); S.cfg.comece_ok = '1'; return render(); }
  if (id === 'loja' || id === 'assistente') { S.passoAssist = null; return ir('assistente'); }
  if (id === 'nome') {
    const v = await pedirTexto(`Nome do seu ${R.mesas ? 'restaurante' : 'negócio'}`, 'Como ele se chama?', nomeDefinido() ? S.cfg.nome_estabelecimento : '');
    if (!v || !v.trim()) return;
    await tentar(() => PUT('/api/config', { nome_estabelecimento: v.trim() }), 'Nome salvo'); S.cfg.nome_estabelecimento = v.trim();
    const el = $('#mp-estabelecimento'); if (el) el.textContent = v.trim();
    return render();
  }
  if (id === 'produtos') return escolherCaminhoProdutos();
  if (id === 'teste') return Tour.iniciar();
  if (id === 'venda') { const m = itensNavMobile()[1]; return ir(m ? m.id : 'inicio'); }
  if (id === 'cardapio') { if (S.cfg.online_ativo !== '1') return ir('cardapio-online'); return modalLinkCardapio(); }
  if (id === 'celular') return modalCelularEquipe();
  if (id === 'impressora') { S.abaConfig = 'impressora'; return ir('config'); }
  if (id === 'pix') { S.abaConfig = 'pix'; return ir('config'); }
  if (id === 'pins') { S.abaCad = 'usuarios'; return ir('cadastros'); }
}
// link público do cardápio online deste sistema (online: endereço da loja; computador: pela internet quando ligado)
function linkCardapioOnline(info, ol) {
  if (S.cfg.online_ativo !== '1') return '';
  const lg = ol && ol.ligacao;
  const base = info && info.base_url ? info.base_url : (lg && lg.ligado && lg.url) ? lg.url : (info && pelaInternet(info) ? info.internet.url : '');
  return base ? base + '/cardapio-online' : '';
}
// só pelo Wi-Fi do restaurante (computador ainda sem ligação à internet): serve para testar, não para o cliente de fora
function linkCardapioWifi(info) { if (S.cfg.online_ativo !== '1') return ''; const b = baseWifi(info); return b ? b + '/cardapio-online' : ''; }
async function marcarDivulgado() {
  if (S.cfg.online_divulgado === '1') return;
  S.cfg.online_divulgado = '1';
  await PUT('/api/config', { online_divulgado: '1' }).catch(() => {});
  if (S.view === 'inicio') render();
}
function msgDivulgacao(link) { return `Agora você pode pedir pelo nosso cardápio online! 🍔🛵\nEscolha, peça e acompanhe tudo pelo celular:\n${link}`; }
async function modalLinkCardapio() {
  const [info, ol] = await Promise.all([GET('/api/info').catch(() => null), GET('/api/online/resumo').catch(() => null)]);
  const link = linkCardapioOnline(info, ol);
  if (!link) { toast('O link aparece assim que o sistema estiver ligado à internet. Veja em Cardápio online.', 'alerta', { tempo: 7000 }); return ir('cardapio-online'); }
  await modal({ titulo: '🌐 Seu cardápio online', corpo: `<div class="stack" style="align-items:center;text-align:center">
      <div class="qr">${qrImg(link, 4)}</div>
      <div class="on-url" style="width:100%"><input type="text" readonly value="${esc(link)}" id="lk-url"><button type="button" class="btn primary" data-lk="copiar">Copiar</button></div>
      <div class="row wrap" style="justify-content:center;gap:8px"><a class="btn ok" target="_blank" rel="noopener" data-lk="zap" href="https://wa.me/?text=${encodeURIComponent(msgDivulgacao(link))}">💬 Mandar no WhatsApp</a><button type="button" class="btn" data-lk="config">Configurar o cardápio</button></div>
      <div class="small muted">Coloque o link na bio do Instagram, no status do WhatsApp e na embalagem. Quem pedir por aqui não paga comissão de aplicativo.</div></div>`,
    botoes: [{ texto: 'Fechar', classe: 'primary', padrao: true }],
    aoAbrir: (f, fechar) => f.addEventListener('click', async (e) => {
      const b = e.target.closest('[data-lk]'); if (!b) return;
      if (b.dataset.lk === 'copiar') { try { await navigator.clipboard.writeText(link); toast('Link copiado ✓', 'ok'); } catch { $('#lk-url', f).select(); document.execCommand('copy'); toast('Link copiado', 'ok'); } marcarDivulgado(); }
      if (b.dataset.lk === 'zap') marcarDivulgado();
      if (b.dataset.lk === 'config') { fechar(null); ir('cardapio-online'); }
    }) });
}
async function modalCelularEquipe() {
  const info = await GET('/api/info').catch(() => null);
  const caminho = R.garcom ? '/garcom' : '/';
  const link = linkEquipe(info, caminho), wifi = linkEquipe(info, caminho, 'wifi');
  lsSet('mp_celular_visto', '1');
  await modal({ titulo: R.garcom ? '📱 Abrir no celular do garçom' : '📱 Abrir no celular da equipe', corpo: `<div class="stack" style="align-items:center;text-align:center">
      ${link ? `<div class="qr">${qrImg(link, 4)}</div><div class="small">Aponte a câmera do celular para o QR: ele já entra no ${esc(PR.nome)} ${S.cfg.nome_estabelecimento ? 'do ' + esc(S.cfg.nome_estabelecimento) : ''}.</div><div class="small muted" style="word-break:break-all">${esc(link)}</div>` : `<div class="small">Este computador ainda não tem endereço para os celulares. Veja em Configurações › Rede.</div>`}
      ${wifi && wifi !== link ? `<div class="small muted">Sem internet? Pelo Wi-Fi do restaurante: <b>${esc(wifi)}</b></div>` : ''}
      <div class="small muted">Depois é só o garçom entrar com o PIN dele. Mais celulares, TV da cozinha e QR das mesas: Configurações › Rede.</div></div>`,
    botoes: [{ texto: 'Configurações › Rede', acao: () => { setTimeout(() => { S.abaConfig = 'rede'; ir('config'); }, 0); return true; } }, { texto: 'Pronto', classe: 'primary', padrao: true }] });
  if (S.view === 'inicio') render();
}
function linkFotoCardapio() {
  const zap = (S.licenca && S.licenca.vendedor_whatsapp) || '5511981308308';
  return linkWhatsApp(zap, `Oi! Quero que cadastrem o cardápio do ${S.cfg.nome_estabelecimento || 'meu restaurante'} (${location.host}). Segue a foto:`);
}
async function escolherCaminhoProdutos() {
  const n = (S.cardapio && S.cardapio.produtos || []).length;
  let escolha = null;
  await modal({ titulo: `Seus ${T.produtos_plural || 'produtos'}`, corpo: `<div class="stack">
      <p style="margin:0">Seu ${PR.nome} já vem com <b>${n} ${T.produtos_plural || 'produtos'} de exemplo</b> para você testar agora. Como quer seguir?</p>
      <button class="opc-grande" data-v="manter"><b>👍 Testar com os exemplos</b><span>Depois você troca pelos seus, quando quiser.</span></button>
      ${R.mesas ? `<a class="opc-grande" data-v="foto" href="${esc(linkFotoCardapio())}" target="_blank" rel="noopener"><b>📸 Mandar a foto do cardápio no WhatsApp</b><span>A gente cadastra para você, sem custo.</span></a>` : ''}
      <button class="opc-grande" data-v="meus"><b>✏️ Cadastrar os meus agora</b><span>Nome, preço e categoria. Dá para importar planilha.</span></button></div>`,
    aoAbrir: (f) => f.addEventListener('click', (e) => { const b = e.target.closest('.opc-grande[data-v]'); if (!b) return; escolha = b.dataset.v; setTimeout(() => f.querySelector('[data-fechar]')?.click(), escolha === 'foto' ? 300 : 0); }) });
  if (!escolha) return;
  await PUT('/api/config', { produtos_ok: '1' }).catch(() => {}); S.cfg.produtos_ok = '1';
  if (escolha === 'meus') { S.abaCad = 'produtos'; return ir('cadastros'); }
  if (escolha === 'foto') toast('Mande a foto na conversa que abriu. Enquanto isso, teste com os exemplos!', 'ok', { tempo: 8000 });
  if (S.view === 'inicio') render();
}

// ---------------------------------------------------------------- pedido de teste guiado
const Tour = {
  ativo: false, passo: '', pedidoId: null, timer: null, alvo: null, balao: null, ultimoPasso: '', esperaPronto: 0,
  async iniciar() {
    if (!TEM_TOUR()) return;
    this.ativo = true; this.passo = 'mesas'; this.pedidoId = null;
    document.documentElement.classList.add('em-tour');
    if (!S.caixa?.aberto) { try { await POST('/api/caixa/abrir', { fundo: 0 }); await carregarCaixa(); } catch {} }
    if (S.view !== 'mesas' && S.view !== 'editor') await ir('mesas');
    this.timer = setInterval(() => this.tick(), 350);
    this.tick();
  },
  async sair(apagar = true) {
    clearInterval(this.timer); this.timer = null; this.ativo = false; this.limpar();
    document.documentElement.classList.remove('em-tour');
    if (apagar && this.pedidoId) { await POST(`/api/pedidos/${this.pedidoId}/apagar-teste`).catch(() => {}); try { localStorage.removeItem('mp_tour_pedido'); } catch {} if (S.view === 'editor') { S.carrinho = []; ir('inicio'); } }
    this.pedidoId = null;
  },
  limpar() {
    document.querySelectorAll('.tour-alvo').forEach(e => e.classList.remove('tour-alvo'));
    this.balao?.remove(); this.balao = null; this.alvo = null;
  },
  mostrar(alvo, texto, { passo = '', botao = null } = {}) {
    if (alvo === this.alvo && this.balao && this.balao.dataset.txt === texto) { this.posicionar(); return; }
    this.limpar();
    this.alvo = alvo;
    if (alvo) { alvo.classList.add('tour-alvo'); if (this.ultimoPasso !== this.passo) alvo.scrollIntoView({ block: 'center', behavior: 'smooth' }); }
    this.ultimoPasso = this.passo;
    const b = document.createElement('div'); b.className = 'tour-balao'; b.dataset.txt = texto;
    b.innerHTML = `<div class="tb-passo">${esc(passo)}</div><div class="tb-txt">${texto}</div><div class="tb-bts">${botao ? `<button class="btn sm primary" data-tour-ok>${esc(botao)}</button>` : ''}<button class="btn sm ghost" data-tour-sair>Sair do teste</button></div>`;
    b.querySelector('[data-tour-sair]').onclick = () => this.sair(true);
    const ok = b.querySelector('[data-tour-ok]'); if (ok) ok.onclick = () => { this.okClicado = this.passo; };
    document.body.appendChild(b); this.balao = b; this.posicionar();
  },
  posicionar() {
    const b = this.balao; if (!b) return;
    b.classList.remove('topo');
    if (!this.alvo || CELULAR()) {
      b.classList.add('fixo');
      if (this.alvo) { const r = this.alvo.getBoundingClientRect(); if (r.top + r.height / 2 > innerHeight * 0.5) b.classList.add('topo'); }
      return;
    }
    b.classList.remove('fixo');
    const r = this.alvo.getBoundingClientRect(); const w = b.offsetWidth, h = b.offsetHeight;
    let top = r.bottom + 12; if (top + h > innerHeight - 10) top = Math.max(10, r.top - h - 12);
    let left = Math.min(Math.max(10, r.left + r.width / 2 - w / 2), innerWidth - w - 10);
    b.style.top = top + 'px'; b.style.left = left + 'px';
  },
  achar(sel, texto) {
    const els = [...document.querySelectorAll(sel)].filter(e => e.offsetParent !== null || e.getClientRects().length);
    if (!texto) return els[0] || null;
    const t = texto.toLowerCase(); return els.find(e => e.textContent.toLowerCase().includes(t)) || null;
  },
  modalAberto() { return [...document.querySelectorAll('.modal-fundo')].at(-1) || null; },
  async tick() {
    if (!this.ativo) return;
    try { await this.passoAtual(); } catch (e) { console.log('tour', e); }
  },
  async passoAtual() {
    const md = this.modalAberto();
    // 1) ir para as mesas
    if (this.passo === 'mesas') {
      if (S.view === 'mesas') { this.passo = 'mesa'; return; }
      if (S.view === 'editor' && S.pedido?.tipo === 'mesa') { this.passo = 'produto'; return this.marcar(); }
      const nav = this.achar('[data-mobv="mesas"]') || this.achar('#menu [data-v="mesas"]');
      return this.mostrar(nav, 'Vamos atender a primeira mesa. Toque em <b>Mesas</b>.', { passo: 'Pedido de teste · 1 de 5' });
    }
    // 2) abrir a mesa 1
    if (this.passo === 'mesa') {
      if (S.view === 'editor' && S.pedido?.tipo === 'mesa') { this.passo = 'produto'; return this.marcar(); }
      if (S.view !== 'mesas') { this.passo = 'mesas'; return; }
      if (md && /abrir a mesa/i.test(md.querySelector('.modal-cab h2')?.textContent || '')) return this.mostrar(md.querySelector('.modal-rod .btn.primary'), 'Quantas pessoas sentaram? Deixe 2 e toque em <b>Abrir mesa</b>.', { passo: 'Pedido de teste · 1 de 5' });
      const livres = [...document.querySelectorAll('.mesa[data-mp-state="livre"]')];
      const m = livres.find(x => /^\s*(mesa\s*)?0?1\s*$/i.test(x.dataset.mpName || '')) || livres[0];
      return this.mostrar(m, `Um cliente sentou na <b>${esc(m?.dataset.mpName || 'mesa')}</b>. Toque nela para abrir o pedido.`, { passo: 'Pedido de teste · 1 de 5' });
    }
    // 3) escolher o lanche
    if (this.passo === 'produto') {
      if (S.view !== 'editor') { if (!this.pedidoId) this.passo = 'mesas'; return; }
      if (S.carrinho.length) { this.passo = 'enviar'; return; }
      if (md && md.querySelector('#mp-qtd')) {
        const obs = this.achar('#mp-obsr [data-obs]', 'sem cebola');
        if (obs && !obs.classList.contains('on')) return this.mostrar(obs, 'O cliente pediu <b>sem cebola</b>. Toque aqui — a cozinha vai ver o aviso.', { passo: 'Pedido de teste · 2 de 5' });
        const add = md.querySelector('.modal-rod .btn.primary');
        return this.mostrar(add, 'Agora toque em <b>Adicionar</b>.', { passo: 'Pedido de teste · 2 de 5' });
      }
      const prod = this.achar('#prods [data-prod]', 'x-burguer') || this.achar('#prods [data-prod]', 'x-burger');
      if (!prod) {
        const cat = this.achar('#cats [data-cat]', 'lanche') || this.achar('#cats [data-cat]', 'burg');
        if (cat && !cat.classList.contains('on')) return this.mostrar(cat, 'Abra a categoria <b>' + esc(cat.textContent.trim()) + '</b>.', { passo: 'Pedido de teste · 2 de 5' });
      }
      const alvo = prod || this.achar('#prods [data-prod]');
      return this.mostrar(alvo, `Toque no <b>${esc((alvo?.querySelector('b')?.textContent || 'produto').trim())}</b>.`, { passo: 'Pedido de teste · 2 de 5' });
    }
    // 4) mandar para a cozinha
    if (this.passo === 'enviar') {
      if (S.view !== 'editor') return;
      if (!S.carrinho.length && S.pedido?.itens?.some(i => !i.cancelado)) { this.passo = 'cozinha'; this.limpar(); return this.mostrarCozinha(); }
      if (!S.carrinho.length) { this.passo = 'produto'; return; }
      const bt = this.achar('#mob-enviar') || this.achar('#enviar');
      return this.mostrar(bt, 'Pronto! Toque em <b>Enviar para a cozinha</b>.', { passo: 'Pedido de teste · 3 de 5' });
    }
    if (this.passo === 'cozinha') return; // modal da cozinha cuida
    // 5) receber com Pix
    if (this.passo === 'receber') {
      if (!md) {
        const p = this.pedidoId ? await GET('/api/pedidos/' + this.pedidoId).catch(() => null) : null;
        if (p && p.status === 'fechado') { this.passo = 'fim'; this.limpar(); return this.fim(); }
      }
      if (md) {
        const titulo = md.querySelector('.modal-cab h2')?.textContent || '';
        if (/concluído|concluido/i.test(titulo)) { const c = md.querySelector('.modal-rod .btn.primary') || md.querySelector('[data-fechar]'); return this.mostrar(c, 'Recebido! Toque em <b>Concluir</b>.', { passo: 'Pedido de teste · 5 de 5' }); }
        if (/caixa fechado/i.test(titulo)) { const c = md.querySelector('.modal-rod .btn.primary'); return this.mostrar(c, 'Abra o caixa (é só um toque).', { passo: 'Pedido de teste · 5 de 5' }); }
        const pix = this.achar('[data-forma]', 'pix');
        if (pix && !pix.classList.contains('on')) return this.mostrar(pix, 'O cliente vai pagar no <b>Pix</b>. Toque em Pix.', { passo: 'Pedido de teste · 5 de 5' });
        const qr = md.querySelector('#pg-pix');
        if (qr && !this.viuQr) { qr.addEventListener('click', () => { this.viuQr = true; }, { once: true }); return this.mostrar(qr, 'Toque para mostrar o <b>QR do Pix</b> com o valor certinho — o cliente paga lendo a tela.', { passo: 'Pedido de teste · 5 de 5' }); }
        const lanc = md.querySelector('#pg-lancar');
        if (lanc) return this.mostrar(lanc, S.cfg.pix_chave ? 'Depois que o Pix cair, toque em <b>Lançar pagamento</b>.' : 'Toque em <b>Lançar pagamento</b>. (O QR do Pix aparece quando você cadastrar sua chave em Configurações › Pix.)', { passo: 'Pedido de teste · 5 de 5' });
        return;
      }
      if (S.view !== 'editor') return;
      const rc = this.achar('#mob-receber') || this.achar('#receber');
      return this.mostrar(rc, 'O lanche ficou pronto e foi servido. Hora de receber: toque em <b>Receber</b>.', { passo: 'Pedido de teste · 5 de 5' });
    }
  },
  async marcar() {
    if (this.pedidoId || !S.pedido) return;
    this.pedidoId = S.pedido.id;
    try { localStorage.setItem('mp_tour_pedido', String(this.pedidoId)); } catch {}
    await POST(`/api/pedidos/${this.pedidoId}/teste`).catch(() => {});
    S.busca = '';
  },
  async mostrarCozinha() {
    const idPed = this.pedidoId;
    let vigia = null;
    await modal({ titulo: '👨‍🍳 O pedido chegou na cozinha', largo: true, corpo: `<div class="stack">
        <p class="small" style="margin:0">É assim que a cozinha vê, numa TV, tablet ou celular. Repare no <b>“Sem cebola”</b>. Toque em <b>Pronto</b> no cartão quando o lanche ficar pronto.</p>
        <iframe src="/cozinha" class="tour-cozinha" title="Tela da cozinha"></iframe></div>`,
      botoes: [{ texto: 'Continuar', classe: 'primary', padrao: true, valor: true }],
      aoAbrir: (f) => {
        // rola a tela da cozinha até o cartão do pedido (o botão "Pronto")
        const ifr = f.querySelector('iframe');
        const focar = () => { try { const d = ifr.contentDocument; if (d && d.head && !d.getElementById('tour-css')) { const st = d.createElement('style'); st.id = 'tour-css'; st.textContent = '.kpis-c{display:none!important}'; d.head.appendChild(st); } const b = d.querySelector('[data-pronto]'); if (b) { b.scrollIntoView({ block: 'center' }); b.style.outline = '3px solid #ffd166'; b.style.outlineOffset = '3px'; return true; } } catch {} return false; };
        let tent = 0; const t = setInterval(() => { if (focar() || ++tent > 30) clearInterval(t); }, 400);
        vigia = setInterval(async () => {
          const p = await GET('/api/pedidos/' + idPed).catch(() => null);
          if (p && p.itens.filter(i => !i.cancelado).every(i => ['pronto', 'entregue'].includes(i.status))) { clearInterval(vigia); toast('✓ Lanche pronto! O garçom recebe o aviso no celular.', 'ok'); setTimeout(() => f.querySelector('.modal-rod .btn.primary')?.click(), 1400); }
        }, 1500);
      } });
    clearInterval(vigia);
    if (!this.ativo) return;
    // marca pronto caso tenha só tocado em "Continuar"
    const p = await GET('/api/pedidos/' + idPed).catch(() => null);
    const pend = p ? p.itens.filter(i => !i.cancelado && !['pronto', 'entregue'].includes(i.status)).map(i => i.id) : [];
    if (pend.length) await POST('/api/cozinha/status', { item_ids: pend, status: 'pronto' }).catch(() => {});
    if (p) { S.pedido = await GET('/api/pedidos/' + idPed).catch(() => S.pedido); desenharPedido(); }
    this.passo = 'receber'; this.viuQr = false;
  },
  async fim() {
    await this.sair(true);
    await PUT('/api/config', { pedido_teste_ok: '1' }).catch(() => {}); S.cfg.pedido_teste_ok = '1';
    const info = await GET('/api/info').catch(() => ({}));
    const link = linkEquipe(info, R.garcom ? '/garcom' : '/');
    const comprar = linkCompra(S.licenca || {});
    await modal({ titulo: '🎉 Pronto! Seu restaurante funciona assim todo dia', corpo: `<div class="stack">
        <p style="margin:0">Mesa → cozinha → Pix em menos de 2 minutos. <span class="muted">Esse pedido de teste já foi apagado e não entra nos seus relatórios.</span></p>
        ${link ? `<div class="card pad row wrap" style="gap:14px;box-shadow:none;background:var(--surface-2)"><div class="qr">${qrImg(link, 3)}</div><div style="flex:1;min-width:180px"><b>Abra no celular do garçom</b><div class="small muted">Aponte a câmera do celular para o QR: ele já entra no ${esc(PR.nome)} do seu restaurante.</div></div></div>` : ''}
        ${MPPlanos.ativo(S.licenca) && S.licenca.plano.situacao === 'teste' ? `<div class="card pad stack" style="gap:6px;box-shadow:none;background:var(--accent-soft)"><b>Gostou? Escolha seu plano.</b><div class="small muted">A partir de R$ 39,90 por mês, sem fidelidade. Tudo o que você cadastrou continua aqui.</div><button class="btn primary" data-ver-planos>Ver os planos</button></div>` : ''}
        ${!MPPlanos.ativo(S.licenca) && S.licenca && S.licenca.estado === 'teste' && comprar ? `<div class="card pad stack" style="gap:6px;box-shadow:none;background:var(--accent-soft)"><b>Gostou? Garanta o seu${precoOferta() ? ' por ' + esc(precoOferta()) : ''}.</b><div class="small muted">${esc(((S.licenca.oferta && S.licenca.oferta.descricao) || '').replace(/\.?$/, '.'))} Tudo o que você cadastrou continua aqui.</div><a class="btn primary" href="${esc(comprar)}" target="_blank" rel="noopener">Comprar agora</a></div>` : ''}</div>`,
      botoes: [{ texto: 'Voltar ao início', classe: 'primary', padrao: true, valor: true }] });
    ir('inicio');
  },
};
addEventListener('resize', () => Tour.posicionar());
addEventListener('scroll', () => Tour.posicionar(), true);
// pedido de teste largado no meio (fechou o navegador): apaga na próxima abertura
function limparTourAntigo() {
  let id = null; try { id = localStorage.getItem('mp_tour_pedido'); } catch {}
  if (id && !Tour.ativo) { POST(`/api/pedidos/${id}/apagar-teste`).catch(() => {}); try { localStorage.removeItem('mp_tour_pedido'); } catch {} }
}

// ---------------------------------------------------------------- celular: navegação de baixo e menu "Mais"
const NAV_PREFERIDOS = ['inicio', 'mesas', 'os', 'agenda', 'balcao', 'pdv', 'cozinha', 'caixa'];
function itensNavMobile() {
  const vis = MENU.filter(m => pode(m.perfil) && !m.link);
  const ordem = [...NAV_PREFERIDOS.map(id => vis.find(m => m.id === id)).filter(Boolean), ...vis];
  return [...new Set(ordem)].slice(0, 4);
}
function desenharNavMobile() {
  const el = document.getElementById('mob-nav'); if (!el) return;
  const itens = itensNavMobile();
  const naMais = !itens.some(m => m.id === S.view || (S.view === 'editor' && S.voltar === m.id));
  el.innerHTML = itens.map(m => `<button class="mn ${S.view === m.id || (S.view === 'editor' && S.voltar === m.id) ? 'on' : ''}" data-mobv="${m.id}">${mpIcon(m.icone || m.id)}<span>${esc(m.nome.replace(/^Ordens de serviço$/, 'OS').replace(/^Venda de balcão$/, 'Balcão').replace(/^Fechar contas$/, 'Contas'))}</span></button>`).join('')
    + `<button class="mn ${naMais ? 'on' : ''}" data-mobmais>${mpIcon('menu')}<span>Mais</span>${nPend() ? '<i class="mn-b"></i>' : ''}</button>`;
}
function abrirMaisMobile() {
  const itens = MENU.filter(m => pode(m.perfil));
  const sup = linkSuporte();
  const l = S.licenca || {};
  const fundo = document.createElement('div'); fundo.className = 'mob-sheet-fundo';
  fundo.innerHTML = `<div class="mob-sheet" role="dialog" aria-label="Menu"><div class="ms-alca"></div>
    <div class="ms-user"><span class="mp-avatar">${esc(S.usuario.nome.slice(0, 2).toUpperCase())}</span><div><b>${esc(S.usuario.nome)}</b><small>${esc(S.cfg.nome_estabelecimento || '')}</small></div><span class="spacer"></span><button class="btn sm" data-ms="sair">Sair</button></div>
    ${l.estado === 'teste' ? faixaTeste() : ''}
    <div class="ms-grid">${itens.map(m => `<button class="ms-it ${S.view === m.id ? 'on' : ''}" data-ms-v="${m.id}">${mpIcon(m.icone || m.id)}<span>${esc(m.nome)}</span></button>`).join('')}</div>
    <div class="ms-linha">${sup ? `<a class="btn ok" href="${esc(sup)}" target="_blank" rel="noopener">💬 Suporte no WhatsApp</a>` : ''}<button class="btn" data-ms="notif">🔔 Avisos${nPend() ? ' (' + nPend() + ')' : ''}</button><button class="btn" data-ms="tema">🌓 Tema</button></div></div>`;
  const fechar = () => fundo.remove();
  fundo.addEventListener('click', async (e) => {
    if (e.target === fundo) return fechar();
    const v = e.target.closest('[data-ms-v]');
    if (v) { fechar(); const m = MENU.find(x => x.id === v.dataset.msV); if (m.link) return window.open(m.link, '_blank'); return ir(m.id); }
    const a = e.target.closest('[data-ms]'); if (!a) return;
    if (a.dataset.ms === 'sair') { try { await POST('/api/logout'); } catch {} Sessao.limpar(); location.reload(); }
    if (a.dataset.ms === 'tema') Tema.alternar();
    if (a.dataset.ms === 'notif') { fechar(); abrirNotificacoes(); }
  });
  document.body.appendChild(fundo);
}
document.addEventListener('click', (e) => {
  const b = e.target.closest('[data-mobv]'); if (b) { const m = MENU.find(x => x.id === b.dataset.mobv); if (m) ir(m.id); return; }
  if (e.target.closest('[data-mobmais]') || e.target.closest('.mp-avatar.clicavel')) abrirMaisMobile();
});

// ---------------------------------------------------------------- celular: barra do pedido (mesa/balcão)
function barraPedidoHtml(p, totalCarrinho) {
  const ativos = p.itens.filter(i => !i.cancelado && i.status !== 'aguardando');
  const nItens = S.carrinho.reduce((s, i) => s + i.qtd, 0) + ativos.reduce((s, i) => s + i.qtd, 0);
  const total = (p.pago ? p.restante : p.total) + totalCarrinho + (typeof previaServicoCarrinho === 'function' ? previaServicoCarrinho(p, totalCarrinho) : 0);   // 3.11: mesma conta do computador (com o serviço dos novos itens)
  const encerrado = ['fechado', 'cancelado'].includes(p.status);
  let acao = '';
  if (S.carrinho.length) acao = `<button class="btn primary" id="mob-enviar">${R.cozinha ? 'Enviar' : (T.enviar || 'Lançar')} ${S.carrinho.reduce((s, i) => s + i.qtd, 0)}</button>`;
  else if (ativos.length && !encerrado) acao = `<button class="btn ok" id="mob-receber">Receber</button>`;
  return `<div class="mob-barra" id="mob-barra"><button class="mb-ver" id="mob-ver"><span class="mb-n">${nItens} ${nItens === 1 ? 'item' : 'itens'}</span><b class="num">${brl(total)}</b><span class="mb-link">${S.carrinho.length ? 'previsto após enviar ▴' : 'Ver pedido ▴'}</span></button>${acao}</div>`;
}
function ligarBarraPedido() {
  const v = document.getElementById('mob-ver'); if (v) v.onclick = () => document.documentElement.classList.toggle('ver-pedido');
  const en = document.getElementById('mob-enviar'); if (en) en.onclick = () => document.getElementById('enviar')?.click();
  const rc = document.getElementById('mob-receber'); if (rc) rc.onclick = () => { document.documentElement.classList.remove('ver-pedido'); document.getElementById('receber')?.click(); };
}
